# G0 source and mutation audit

The kickoff and authoritative plan are version 2.1. Both the protected
checkout and experiment checkout resolve to
`af71ba43206e124f5ff6419b47ee36c6e9981078`; the experiment branch is
`exp/qwen38-mtp-4090`. Windows paths were resolved with Ubuntu `wslpath`
and checked with `realpath` before evidence creation.

The initial Windows status was clean in both source repositories. WSL git
initially reported the experiment's CRLF files as modified. Read-only
per-command `core.autocrlf=true` and `core.filemode=false` produce an empty
baseline diff and identify only experiment additions. No git configuration
or checked-out files were changed to normalize this difference. The project
has two pre-existing untracked v2.1 plan documents, which are preserved.

The baseline interpreter is
`/home/rba90/.freetoken-qwen38/venv/bin/python` (CPython 3.13.15). Its editable
installation imports the protected checkout. Every probe records dependency
versions, imported source, source diff hash and relevant untracked-source
hashes. Raw failed probe records are retained alongside corrected runs.

The project launcher selects UUID `GPU-67921d1c-ee8e-304f-b562-d6f87617c5a0`,
offload, explicit zero CPU layers, BF16, memory ratio 0.90, automatic MoE
cache, disk PLE, and radix prefix caching. The experiment uses its own port
1929 and one active request. It uses the launcher's Native256K capacity,
with 262144 total tokens and 8192-row prefill chunks. The retained 4041-token
retrieval prompt is preserved. The near-full 261120+1024 shape is separately
labeled a synthetic local-source diagnostic. It is not a recovered primary
held-out code benchmark.

`ft` maps to `freetoken.cli:main`. The equivalent isolated Python invocation
is `python -B -m freetoken.cli serve ...`. The legacy `python -m freetoken`
entry directly invokes the server and does not accept the `serve` command.
The failed initial invocation is preserved, with no model allocation.

The checkpoint is read-only. The inventory reads index and safetensors
headers (including PLE shards) without deserializing tensor data. The
allowlist includes `mtp.*`, the exact raw embedding name
`model.language_model.embed_tokens.weight`, and `lm_head.weight`. Both
embedding and head are independent BF16 tensors, 248320 x 2560; tying is
false. Target wide feature size is 4 x 2560 = 10240, before the final
hyperconnection mixer. The existing target loader drops `mtp.*`.

The target loader reads local NVFP4 expert banks and disk-backed PLE rows.
FTW conversion is an explicit checkpoint command; this runner never invokes
it. Runtime caches are redirected inside `.mtp-exp/caches`, Python bytecode
writing is disabled, and local/offline model resolution is enforced.
No model conversion, full-context target feature export, MTP startup, CPU expert
computation, launcher edit, commit, or upstream action is part of G0.

The baseline public endpoint cannot expose generated IDs or state. The
experiment's diagnostic scheduler now captures raw IDs, logits, short prefill
tails, and first-GDN state. It reproduces the API text hashes exactly. Its
offline I/O and synchronizing observation hooks are explicitly diagnostic.
The opt-in BF16 reduction switch changes only a disposable diagnostic
process; no protected source or project setting is changed. See
`reports/g0-diagnosis.md` for numerical and state evidence.
G1 and later adapters currently return explicit NOT_RUN with a nonzero exit.
Full-context MTP initialization remains BLOCKED_REQUIREMENT independently
of target-only baseline work.
