# Metric provenance

The saved September 2 profile was recovered from
`/home/rba90/.cache/freetoken/benchbw/GPU-67921d1c-ee8e-304f-b562-d6f87617c5a0.json`
and copied verbatim to `environment/historical-benchbw.json`.

| Metric | Evidence | Interpretation |
| --- | --- | --- |
| 26.9 GB/s | SOURCE_REPORTED historical `dtype_kernels.nvfp4.pcie_gather_gbs` | Host-to-GPU expert-cache gather, not CPU-only streaming |
| 73.6 GB/s | SOURCE_REPORTED historical `ceilings.cpu_stream_read_gbs` | Separate CPU streaming diagnostic |
| 28.87 / 28.65 GB/s | SOURCE_REPORTED historical linear H2D / D2H | Separate PCIe transfer diagnostics |
| 26.61 GB/s | SOURCE_REPORTED historical gather with CPU MoE overlap | Historical only; no CPU MoE run authorized here |
| 96 GB/s | DERIVED_ESTIMATE | Two DDR5-6000 channels; not sustained bandwidth |
| 31.507692 / 15.753846 GB/s | DERIVED_ESTIMATE | Gen5 x8 / Gen4 x8 encoding-level per-direction ceilings |

At the protected SHA, `python/freetoken/moe/benchbw.py` builds a synthetic
`OffloadMoeCache`, populates its miss indices, and calls production
`copy_missing()`. The GPU reads mapped pinned host sources and writes GPU
cache banks. The current implementation counts every bank's
`E * elements * dtype.itemsize`, uses decimal GB (`1e9`), warms three copies,
and times repeated completed copies with CUDA events. It bypasses routing
and cache admission and repeatedly refills the declared source working set.
Thus it is a gather-kernel diagnostic, not a full real-layer benchmark.

The saved profile reports 128 synthetic experts and 7,974,912 bytes/expert
(1,020,788,736 logical bytes per full copy if the historical code used the
same bank accounting). This is conditional reconstruction, not a recovered
raw timing. The profile lacks the benchmark source SHA, exact workload,
iteration count, raw event samples, cache/DRAM counters, and loaded PCIe
generation/width. The current source explains the metric's intended path;
it does not establish the exact historical execution. No fresh bandwidth
measurement is claimed. Physical DRAM/PCIe bytes remain unavailable.

Baseline streaming measurements initially record text-chunk arrival times
and API completion-token usage. Their throughput field is explicitly a
text-chunk proxy: empty-text/special tokens and burst emission prevent
claiming exact raw-token timestamps. The unchanged API exposes no generated
token IDs, so output-text equality is partial correctness evidence only.
