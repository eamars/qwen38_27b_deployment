# G0: protected baseline repeatability

Evaluation update: this is the historical cross-condition failure report.
See [g0-matched-protocol.md](g0-matched-protocol.md) for the corrected G0
comparison policy and `.mtp-exp/status.json` for current progress.

Status: **FAIL_CORRECTNESS at G0**. Implementation is partially verified.
The baseline loads and generates, but identical greedy requests differ
between a prefix miss and a prefix hit. No MTP gate has passed.

The design hypothesis was that the unchanged protected target would supply
a stable greedy reference for the frozen corpus. The executable probe used
the real local NVFP4 checkpoint, 5090, offload backend, explicit zero CPU
layers, disk PLE, and production radix prefix caching. It exposed a failure
before adding MTP execution paths.

## What ran

- Header-only inventory of 296,475 tensors; metadata and shard-header hashes.
- Actual baseline package import and CUDA UUID enumeration. P2P was false in
  both directions; a 1 MiB pinned allocation succeeded.
- Protected target load and CUDA graph capture at 262144-token capacity.
- Two 66-token code requests and two retained 4041-token retrieval requests,
  with identical greedy payloads within each pair.
- A 261120-token synthetic target-only prefill began before the mismatch was
  inspected. It was interrupted after the mismatch was established. It has
  no completed generation or performance result; no features were exported.
- Saved-output comparison now detects the mismatch and returns exit 3. The
  runner immediately checks each pair before allowing the next case.

The original generation records are in `probes/20260905T053229.762772Z`.
Raw failed setup probes remain available, including UUID-prefix formatting,
CLI entry-point, tokenizer return-type and unsupported token-ID API input
discoveries. They are not counted as successful model probes.

## Counterexample

Both small-code requests have exactly the same JSON payload, frozen 66 input
IDs, `temperature=0`, `top_k=1`, `top_p=1`, `ignore_eos=false`, and a 128-token
output budget. API usage reported 127 completion tokens in each case.

The first prefill processed 66 tokens. The second restored 64 cached tokens
and processed two. Their output text first differs at character 190:

```text
first:  ... Need maybe mention iterative/recursive. Ensure nonnegative integer. ...
second: ... Need maybe iterative or recursive. Ensure nonnegative integer. ...
```

Output SHA256 values:

```text
first:  7869c52e5111dfd4bdcf67dc6b28b343c7fd83e119a9d9ef03a5839c9e1d9e49
second: d6ac1b063cab366c986eed43c119091e2c96f6a8688b5cd94932fccfb7eae05a
```

The same pair of hashes was reproduced in a fresh public-API process
(`probes/20260905T053904.201753Z`) and through raw-token scheduler diagnostics.
The follow-up isolated shape-dependent BF16 arithmetic in the first mixer
and precision loss in GDN boundary snapshots. Two cache-hit requests are
bitwise stable in captured tokens, logits, and prefill tensors. An explicit
numerical variant removes this prompt's token mismatch but retains state
and logit differences. See [g0-diagnosis.md](g0-diagnosis.md) for the exact
evidence and limits. No tolerance was relaxed, no corpus case was discarded,
and prefix caching was not disabled.

## Identity, hardware and memory

Protected and experiment SHA:
`af71ba43206e124f5ff6419b47ee36c6e9981078`.
Experiment branch: `exp/qwen38-mtp-4090`.
Each run stores its argument array, diff hash, untracked-source hashes,
interpreter/package paths, dependency versions and raw logs.

Target UUID: `GPU-67921d1c-ee8e-304f-b562-d6f87617c5a0`.
Draft-role UUID: `GPU-eed52936-813f-8d68-1654-bfb56cb42bc3`.
CUDA and nvidia-smi enumerate them in different orders; UUIDs are used.

The host reports two 64 GiB DIMMs configured at 6000, a 9950X3D, and B850 AI
TOP (board revision is not established by SMBIOS). WSL is configured for
112 GiB and 32 GiB swap. Both links were x8 at idle; host telemetry observed
the target at Gen5 x8 under load. The 4090 loaded-link state is unmeasured.

Checkpoint MTP tensors occupy 5,214,301,696 bytes. Untied BF16 embedding and
head each occupy 1,271,398,400 bytes; the draft allowlist totals
7,757,098,496 bytes. The wide feature is 10240 BF16 elements. These are
checkpoint storage counts, not measured resident/peak MTP allocations.

The first successful baseline load allocated 4096 KV pages of 64 tokens,
4068 expert slots, and eight Mamba slots. Reported unit costs were 25344
bytes/KV token, 2772480 bytes/expert slot, and 115642376 bytes/Mamba slot.
The 6.19 GiB KV allocation and smaller expert cache explain why the retained
Short4K historical speed is not directly comparable to this Native256K run.

The 26.9 GB/s historical profile was recovered; its field describes PCIe
expert gather, with incomplete source/timing/link provenance. See
`metric-provenance.md`. No fresh expert-gather, bridge or physical DRAM byte
measurement was made.

## Performance limits and next action

There is no accepted fresh baseline B, MTP-off comparison, MTP-on speed,
TTFT equivalence result, or end-to-end speedup. Text-chunk proxy throughput
and request timing are diagnostic only. First-use compilation and different
prefix states make these samples unsuitable for the final paired gate.

The first token/logit/state diagnosis is complete for the bounded case.
Further work must resolve the numerical reference and remaining state
differences before declaring a valid MTP verification oracle. The tested
numerics switch is an opt-in diagnostic, not an adopted baseline change.
G1-G6 remain NOT_RUN until G0 is resolved.

Full-context MTP initialization separately remains BLOCKED_REQUIREMENT.
The complete approximately 5 GiB prompt-feature stream was never captured,
retained or transferred. G7-G8, commits and publishing remain unauthorized.
