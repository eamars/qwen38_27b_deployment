# G2R-A screen: no integration candidate

**HARD_STOP_SCOPE.** The existing-kernel broad batching candidate fails the
unchanged exact numerical contract. Restricting batching to sites that pass
on the captured inputs offers no material reserve. G2R-B was not started.
This is an engineering screen with stated uncertainty, not an unexecuted
full model's measured speed or a universal impossibility result.

## What ran

One real target process used the frozen 261120-token near-full prompt and
the protected cold continuation. Five input rows at positions 261891-261895
were captured at every active dense site. The existing row-ordered width-five
verifier matched ordinary logits, wide features and semantic state exactly;
the preceding 4092-page checksum also matched. This is an input-capture
control, not a new block-projection verifier or a complete G2 pass.

Every site was checked at widths 1/2/3/5. Each of 13 material shape groups
was timed on real weights and inputs, then all 449 sites were replayed in
the captured layer order. Five paired/reordered samples per mode used CUDA
graphs after warmup. Isolated graphs contain 32 operator repetitions to
reduce launch measurement noise. Layer-order graphs contain one replay.
Packing, splits and explicit row-output copies are included. Captured
operator inputs remain an operator diagnostic; state updates, expert fetch,
PLE disk preparation and full target computation are absent from this replay.

| Width | Exact sites / 449 | Broad batching operator delta | Exact-site subset operator delta |
|---:|---:|---:|---:|
| 1 | 449 | -0.690 ms | -0.155 ms |
| 2 | 107 | 4.266 ms (invalid) | 0.723 ms |
| 3 | 99 | 11.922 ms (invalid) | 2.571 ms |
| 5 | 97 | 24.104 ms (invalid) | 2.695 ms |

Deltas are differences of paired-mode median GPU durations, not full-model
speedups. Broad-batching timing is numerically invalid and cannot qualify.
The subset uses batched calls only at locally exact sites and ordinary
one-row calls at the others. It also regroups independent calls by operator,
which may alter weight-cache residency. This remains an optimistic local
screen; exactness on these captured inputs is not general validation of a
full integrated candidate. The width-five exact sites are the 97 HC-up calls.

## First divergence and route impact

At width two the first projection in layer zero differs at output [0,429]:
ordinary 0.349609375, batched 0.34765625. It has 27 differing elements out
of 32960, maximum absolute error 0.015625 and relative RMS error 5.855e-5.
Widths three/five also fail at that first call site. All one-row controls
are exact, and all tested outputs are finite. No tolerance or precision
setting was changed to accept these errors.

A separate bounded 5090 check reconstructed only the 48 BF16 router weights
from their unchanged checkpoint offsets. All 48 five-row ordinary controls
reproduced the captured logits exactly. The actual fused top-k kernel was
then applied to the ordinary and batched projection logits:

| Width | Tested layer/row cases | Changed ordered expert-ID rows | Changed expert-set rows |
|---:|---:|---:|---:|
| 2 | 96 | 19 | 7 |
| 3 | 144 | 28 | 12 |
| 5 | 240 | 57 | 24 |

Route weights change in every layer at every tested multi-row width. These
are direct router-projection comparisons on captured ordinary inputs;
upstream projection errors were not propagated through a new target stack.
The head's local argmax remains the same on these captured inputs despite
non-exact head logits. That does not establish full-candidate greedy equality.
Changed route sets preclude attributing hypothetical traffic changes solely
to batching reuse.

## Reserve screen and sensitivity

Use B_provisional=45.5189, R_screen=54.62268, and the explicit 20% investment
reserve. No final acceptance criterion is relaxed. The following **sensitivity
estimates are not measured new target latencies**: scale the old later-region
width-two complete target cost by m/2, then subtract the measured exact-subset
operator delta. This favors the candidate by omitting new integration costs
and wider-route penalties. It is not a rigorous lower bound.

| Width | Estimated target cost | Perfect cycle allowance | 20% reserve cutoff | H_max at perfect acceptance |
|---:|---:|---:|---:|---:|
| 2 | 42.127 ms | 36.615 ms | 29.292 ms | -5.513 ms |
| 3 | 61.705 ms | 54.922 ms | 43.938 ms | -6.783 ms |
| 5 | 104.432 ms | 91.537 ms | 73.230 ms | -12.895 ms |

The same sensitivity applied to the slower original region estimates
62.113/91.684/154.396 ms at widths 2/3/5. Neither region supports spending
on integration. The conditional B panel at decode indices 35/195/387/579/
771/963 was declared before operator results and is **NOT_RUN** because A
failed. There is no measured new per-region or representative-panel T_v.

H_max for emitted-row efficiency eta on the later-region estimates:

| Width | eta=0.7 | eta=0.8 | eta=0.9 | eta=1.0 |
|---:|---:|---:|---:|---:|
| 2 | -16.497 ms | -12.836 ms | -9.174 ms | -5.513 ms |
| 3 | -23.259 ms | -17.767 ms | -12.275 ms | -6.783 ms |
| 5 | -40.356 ms | -31.202 ms | -22.048 ms | -12.895 ms |

`g2r-sensitivity.csv` contains the full eta={0.7,0.8,0.9,1.0} by
H={0,2,4,8} ms table, including normalized slack, for both regions and all
three widths. All rows are explicitly labelled extrapolations. Acceptance,
draft/catch-up latency and exposed non-target cost have not been measured.
The reserve pays jointly for acceptance loss and overhead; it is not counted
twice. The numerical failure already decides the broad candidate independently
of these timing extrapolations.
