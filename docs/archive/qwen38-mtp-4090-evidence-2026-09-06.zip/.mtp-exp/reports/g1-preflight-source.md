# G1 source preflight (no G1 runtime claim)

Reviewed while G0 target-only references were running. G1 execution remains
conditional on G0. These are source findings, not measured feasibility.

The existing route is `OffloadMoELayer._decode_routed`:
`ensure_experts -> copy_missing -> _expert_gemm(is_prefill=False)`.
It accepts row-major hidden inputs and [rows, top_k] routes. `ensure_experts`
rewrites raw expert IDs to cache slots in place, so a trace must save the raw
IDs first. CPU/hybrid branches must remain inactive.

The selected native `nvfp4` format dispatches to
`fused_experts_decode_nvfp4_marlin`, which launches over `rows * top_k`
routes. Its packed weights, block scales and global scales remain in the
six existing cache banks; no BF16 expert table is materialized.

The existing **prefill** movement path streams complete layers and must not
be selected accidentally for 2/3/5 verification rows. The first real layer
probe should call the existing decode-routed entry point with captured real
inputs/routes and compare against per-row calls from a matched cache state.
This does not yet implement whole-model verification or a new scheduler.

Cache identity is global: `layer * num_experts + expert`. The cache stores
`slot_for_id`, `id_of_slot`, `usage`, and `step`; its implementation delegates
LRU decisions to the installed flashlib slot-cache kernel. A replay must
validate its decisions against those actual arrays and miss lists, including
the initial state left by prefill. Independent per-layer hit-rate sums are
insufficient. Copy bytes must include every registered bank's row stride.

The native expert kernels perform work per route. Multi-row reuse of host
transfers does not itself prove reduced HBM reads or sufficient speedup.
Measure fetch plus expert compute, exact output comparisons, and real global
cache order before drawing an economic conclusion. A separate instrumented
trace must be checked against the protected greedy continuation; its own
latency is not a production throughput result.
