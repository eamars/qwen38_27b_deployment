# G2 target state inventory

Scope: pinned FreeToken af71ba43206e124f5ff6419b47ee36c6e9981078,
native NVFP4 GPU expert offload, QSA page size 64, one request. This is
an inventory and diagnostic restore contract, not a fast transaction.

| State / owner | Actual layout | Mutation and diagnostic treatment |
|---|---|---|
| GDN recurrence / `LinearStatePool` | FP32 [36, slots, 48, 128, 128] | Ordinary ordered decode updates the live slot. Snapshot occupied slots including the padding sink; compare every tensor element. |
| GDN convolution / `LinearStatePool` | BF16 [36, slots, 10240, 3] | Fused decode convolution updates its raw history. Restore with recurrence; neither state alone is sufficient. |
| PLE convolution / slot state | BF16 [1, slots, 10240, 9] | `ple.py` writes the matching history window. Snapshot and compare all occupied slots. |
| PLE n-gram context / slot state | int32 [1, slots, 2] | `commit_ngram_context` advances token history. Verification stages disk rows with a temporary context then commits the real history in row order. Exact integer comparison. |
| QSA K/V / `QSAKVCache` | BF16 [2,12,pages,64,2,256] | `store_kv` writes each row's physical output slot. Save the bounded existing tail page in the current probe. Hash all preceding allocated pages in 16-page read-only chunks before and after the complete probe. |
| QSA compressed keys | BF16 [12,pages*16+scratch,128] | A closing group writes its compressed row; incomplete groups write request scratch. Save the tail page's compressed rows and all scratch. Prefix checksum includes previous pages' compressed keys. |
| QSA pending ring | BF16 [request slots,12,4,128] | `_plan_index_writes` and `_update_index_cache` overwrite carry rows. Save the complete small ring and compare exactly. |
| QSA per-row metadata | lengths, positions, physical block table, index write plans | Each verification row owns its causal metadata. Ordinary graph replay uses a fresh metadata object because `_stage_decode` rebinds fields to shared graph buffers. |
| Page table and free-page list / cache manager | int tensors | Snapshot and require unchanged for the existing-page probe. No speculative allocation adapter yet. Page crossing, shared-prefix COW and refcount rollback remain unverified. |
| Linear slot free list and request lengths | Python list/scalars | Snapshot and require verification itself not to commit scheduler state. Slow boundary reports currently describe the logical retained prefix; they do not implement server publication or termination. |
| Request CPU token history and GPU token pool | int32 buffers | Snapshot for independent replay. Inputs are copied from the real ordinary scheduler and checked against the frozen protected continuation. |
| Wide target features / probe scratch | BF16 [rows,10240] | Tap the residual before the final hyper-connection mixer. Export selected oracle rows and one preceding seed only; never collect a complete prompt stream. |
| Expert cache / `OffloadMoeCache` | Native immutable weights plus GPU mappings/LRU | Not semantic rollback state. Rejection diagnostics preserve speculative cache pollution. Matched timing restores both weights and mappings outside the timing window to compare identical starting conditions. |
| PLE disk staging / `DiskRowTable` | Existing pinned buffers plus bounded row embeddings | Completion event protects reused staging. Fixed-oracle capture binds explicit staged embeddings; fresh disk preparation remains part of verification wall time. |

Snapshot CPU copies and full ordinary replay are diagnostic overhead. They
are excluded from target block timing and cannot establish G4 or G6 speed.
No draft, parser, sampling RNG, prefix sidecar, cancellation or server
transaction has been implemented at G2. No gate pass is inferred for those
components from these state comparisons.
