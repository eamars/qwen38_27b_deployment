# G2R final disposition

**G2R outcome: HARD_STOP_SCOPE. Experiment closed under the current
checkpoint, hardware allocation, numerical policy and performance requirements.**

The current verifier remains **FAIL_ECONOMICS**. Its original report and
failed status are preserved. G2 is not complete; G3-G6 remain NOT_RUN.

G2R-A tested real BF16 dense operators at widths 1/2/3/5, identified their
actual CUDA dispatch, and measured isolated and layer-order operator replay.
The broad batching change is faster as an operator diagnostic but fails the
exact contract at the first GDN projection and changes downstream router
expert sets. The locally exact subset saves only 0.723/2.571/2.695 ms at
widths 2/3/5 and does not support a credible reserve. No candidate was
integrated into a new target verifier. G2R-B and its conditional timing panel
were therefore not run.

The loaded target has 449 BF16 dense sites and no NVFP4 dense instances.
Its routed NVFP4 experts and 4068-slot GPU expert cache retain the original
offload policy. No dense gain is claimed as a PCIe-byte reduction. Existing
G1 global-cache replay at wider widths shows no useful expert-byte saving;
the new invalid batching also changes routes, so any future traffic claim
would require separate evidence.

The A process's observed peaks are 30,769,590,784 allocated and
31,012,683,776 reserved GPU bytes, including loading/prefill and diagnostic
graphs. These are process peaks, not incremental deployment costs. Captured
operator inputs/outputs occupy a 42,701,149-byte artifact. No expert-cache
capacity reduction was configured. There is no deployed candidate whose
persistent memory effect could be measured.

The width-five capture control and ordinary continuation checks pass their
reported scope. New allocator/COW/refcount behavior, terminal publication,
fast rollback, candidate full-stack greedy behavior, MTP equations,
canonical catch-up and actual acceptance remain unverified. Full-context
initialization remains **BLOCKED_REQUIREMENT** and
`full_context_feature_stream_authorized=false`. No MTP model, daemon,
serving adapter or hidden prompt-feature stream was created.

Evidence:

- `g2r-dispatch-audit.md`: loaded shapes/classes and attribution of both
  original dense GEMV groups.
- `g2r-operator-results.jsonl`: exact/error checks and all paired samples.
- `g2r-wider-cache-replay.json`: recovered real-trace cache results.
- `g2r-screen.md`, `g2r-screen-results.json`, `g2r-sensitivity.csv`: measured
  operator opportunity and explicitly unmeasured target-cost scenarios.
- `g2r-router-check-evidence.json`: direct real fused-router comparisons.
- `g2r-final-audit.json`: source/checkpoint checks, command/source identities
  and owned-process cleanup.

Raw A evidence: `.mtp-exp/probes/20260905T120221.607636Z`.
Router evidence: `.mtp-exp/probes/20260905T121225.518639Z`.
The retained `g2r-directive-v2_2.md` and `g2r-predeclared-protocol.json`
record the authorization and predeclared conditions.

**Next action: STOP.** No dependent implementation or automatic request to
broaden optimization scope follows. A changed numerical contract, new
kernels, different hardware/placement or relaxed objective would be a new
experiment requiring separate review. The correctness harness is retained.
