# G1 result: mechanism passes; performance margin is tight

G1 is PASS for proceeding to the target-only G2 oracle. This is not an MTP
speed or final acceptance result. No MTP model has run.

The experiment environment originally omitted installed dependency startup
hooks. The untraced experiment and both capture variants diverged at output
row 36. Processing the existing dependency directory with `site.addsitedir`
corrected this setup difference. The graph observer then reproduced all 127
protected output IDs. No target math, source, or checkpoint was changed to
obtain that match. The precise downstream kernel affected by the startup
hook was not independently localized.

The corrected observer captured 120 real decode rows through all 48 layers,
including raw routes, weights, inputs, outputs, miss IDs and initial global
cache metadata. The cache has 4068 slots and six native NVFP4 banks totaling
2,772,480 bytes/expert. No CPU expert execution or full-layer verification
materialization was used.

All 36 representative multi-row comparisons passed exactly. Cold copies
matched each block's unique expert union; warm repeats fetched zero experts.
The ordinary global replay reproduced all 5760 recorded miss lists. Total
expert counts were 15363 / 15315 / 15585 / 15389 for widths 1 / 2 / 3 / 5.
Thus block order changed bytes by -0.31%, +1.45%, and +0.17%. Ordinary caching
already retains much of the apparent cross-row reuse.

The full MoE-only graph replay restored both initial slot contents and maps,
then ran the actual captured workload. Every output matched the ordinary
trace. Median costs were 14.99 / 14.44 / 14.56 / 14.29 ms/input row for widths
1 / 2 / 3 / 5. These omit router, dense, attention, head, draft and catch-up.
Restore work is diagnostic and excluded from those component timings.

The two-process socket bridge uses two persistent local pinned and GPU slots
per process, completion events and checked generation/request/round/slot
sequences. Only one slot is in flight in this initial transport. Decode
payloads cover 20/40/60/100 KiB; bounded prompt slots hold 256 rows (5 MiB).
GPU payload checks passed. No actual target features were exported.

Consumer-ready medians under expert fetch were approximately 0.27-0.30 ms,
with p99 below 0.46 ms in the first loaded run. Target fetch slowdown was
below 0.2%. Sustained reset/plan/copy work delivered about 26.6-26.8 decimal
GB/s. Preserve the slower first copy-only samples as a startup/clock
transition diagnostic; do not substitute them for the sustained result.

The bounded prompt test sent four synthetic 256-row chunks during each
loaded request. Six identical prefix-hit requests retained 960/1024 tokens
and produced equal IDs/finish reasons. Median request times were about
2390.7 ms alone and 2390.1 ms with transport. This small diagnostic does not
predict full-context feature-stream contention or initialization debt.

A separate native CPU diagnostic used a 1.42 GB source and captured layer-23
indices. Checks passed with no major faults. Median streaming reads were
42.8 GB/s at one thread and 68.7 GB/s at 16 threads. Copy/gather accounting
counts reads plus writes; indexed reuse is cache-sensitive. These are not
PCIe measurements and do not authorize CPU MoE.

The provisional near-full baseline of 45.52 token/s implies an 18.31 ms
whole-cycle allowance per emitted token. Even perfect acceptance leaves only
about 4 ms/token after MoE. At hypothetical independent 80% acceptance,
depth four exceeds the budget from MoE alone. At 90%, it leaves about 3.2 ms
per round for all other work. Acceptance is not yet observed. G2 must
measure the remaining target work before any MTP integration or speed claim.

Raw evidence: `20260905T071234.797455Z` (first corrected capture),
`20260905T071742.093058Z` (120-row cache and loaded bridge),
`20260905T072504.484041Z` (full MoE replay and hardware samples),
`20260905T072152.380641Z` (CPU), and `20260905T073438.992894Z` (bounded prompt).
Machine-readable decision and budget: `g1-summary.json`, `g1-cycle-budget.json`.
The protected source remains clean. Full-context MTP initialization remains
`BLOCKED_REQUIREMENT`; `full_context_feature_stream_authorized=false`.
