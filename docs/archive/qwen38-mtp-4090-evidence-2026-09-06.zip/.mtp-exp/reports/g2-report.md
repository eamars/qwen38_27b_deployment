# G2 stopped: current verification path fails the cycle budget

Status: **PARTIALLY_VERIFIED / FAIL_ECONOMICS**, 2026-09-05. G0 and G1
passed their scoped gates. G2 has not passed. Dependent G3-G6 work is stopped
for user review under plan 2.1's prerequisite rule and the user's explicit
instruction to stop and ask for help when the path is infeasible.

The implemented target path passes the tested numerical and semantic-state
comparisons. Its measured near-full verification cost leaves no credible
budget for the requested MTP speed improvement. This is a decision about
the implemented path; it is not a proof that every possible MTP design is
impossible on this hardware.

## Hypothesis and implementation

Group the native NVFP4 routed experts across two causal rows while retaining
ordinary per-row dense, QSA, GDN and PLE arithmetic inside one decoder-stack
traversal. Remove measured host launch gaps with one fixed-oracle CUDA
capture experiment. Ordinary model forwards do not import the new module.

Production addition: `python/freetoken/models/qwen4_exp/verify.py` contains
`VerifyRows`, bounded PLE preparation, wide feature/logit exports, and the
single traversal. `benchmarks/qwen38_mtp_verify.py` supplies the independent
ordinary-target oracle, snapshots, future-row perturbation, forced semantic
boundaries and capture timing. `qwen38_mtp_offload.py` launches it in the
isolated experiment interpreter. Source hashes, exact argv and raw logs are
preserved per run; `g2-final-audit.json` records the final source inventory.

## Executed evidence

| Frozen case / positions | Run under `.mtp-exp/probes` | Ordinary two-row median | Captured verify median, including PLE preparation |
|---|---|---:|---:|
| Short / 101-102 | `20260905T083100.134529Z` | 31.510 ms | 32.527 ms |
| Near-full / 261155-261156 | `20260905T083752.067792Z` | 62.677 ms | 62.836 ms |
| Near-full / 261891-261892 | `20260905T084341.141528Z` | 42.259 ms | 42.850 ms |

Each mode has three timed samples in paired/reordered execution. Initial
semantic state and both expert-cache contents and mappings match between
modes. Restoring those conditions, CPU snapshots and ordinary target replay
are outside the timed verification path. Fresh disk PLE preparation is
included. Sampler, commit, output, MTP proposal, catch-up and bridge costs
are absent. These are selected fixed-oracle block diagnostics, not complete
client requests or G6 acceptance samples.

The short run preceded the metadata-isolation refinement. Near-full runs
use fresh ordinary-replay metadata so the graph's shared staging cannot
replace the verification rows' independent causal lengths. Intermediate
prefill chunks are also explicitly excluded from output-token comparisons.
Both fixes were exercised on the real target after the relevant harness
failures; failed runs and their logs remain preserved.

The near-full prompt contains 261120 frozen tokens with 1024 output capacity.
The later probe checks 780 ordinary raw output IDs against the protected
cold reference before and through its selected window. At both near-full
frontiers, wide BF16 features, full FP32 logits, greedy IDs, GDN recurrence
and convolution, PLE history, and QSA tail/compressed/ring state match
exactly. Changing only the future candidate leaves earlier features/logits
unchanged. Both depth-one accepted-count cases pass independent semantic
restore/replay and six or seven subsequent ordinary rows. Checksums of
4080 and 4092 preceding allocated pages remain unchanged.

Every verification call traverses 48 layers once and makes 48 block routed
expert calls. No whole-target replay occurs inside verification. No CPU
expert execution or whole-layer prefill materialization is used there.
The slow diagnostic oracle explicitly performs eight complete ordinary
forwards per forced-boundary case and is not speed evidence.

## Why the economics gate fails

The later frontier is materially faster than the early frontier, but its
verification samples are **43.835, 42.608 and 42.850 ms** for two rows. Even
the fastest measured sample provides only **46.94 hypothetical emitted
tokens/s at perfect acceptance**, with zero MTP overhead. The absolute
48 tokens/s requirement permits at most 41.667 ms for the entire two-token
cycle.

The existing provisional near-full protected baseline is 45.5189 tokens/s,
so the 20% requirement is 54.6227 tokens/s and permits 36.6148 ms per
two-token cycle. The later median therefore needs **6.2357 ms less target
time before paying any actual MTP cost**. That baseline uses offline
synthetic scheduler timing; it is not a final client benchmark. The measured
samples already miss the independent absolute 48 tokens/s budget.

Capture removed the demonstrated host launch gap: later prepared eager
execution was 56.754 ms, while captured GPU samples were 39.995-41.279 ms.
The separate profile contains 3523 kernels totaling 38.923 ms. Expert fetch
accounts for 20.364 ms, the two dominant dense matrix-vector kernel groups
for 10.330 ms, and native NVFP4 expert kernels for 1.901 ms. Early-frontier
expert fetch alone was 36.506 ms. Profile durations are instrumented GPU
intervals, not physical PCIe byte counters or additive cross-process wall
measurements. Raw traces and grouped durations are retained per run.

G1's 120-row real-route replay already found only a 0.31% expert-byte
reduction at width two. The current implementation has no demonstrated
remaining change sufficient to close the target deficit and pay drafting,
canonical catch-up, transport and commit. Larger depths, a donor framework,
or server integration do not follow from this failed G2 prerequisite.

## Verification limits and retained constraints

- The probe uses existing tail pages. New page allocation, shared-prefix
  COW/refcounts and page-crossing rollback remain unverified.
- Forced boundaries validate semantic restore/replay. They do not implement
  actual scheduler publication, terminal truncation or a fast transaction.
- Only width two has target-model coverage. No MTP model, MTP equations,
  canonical draft cache, acceptance distribution or two-GPU token loop exists.
- The complete G2 probe corpus and G6 statistical protocol were not run after
  this feasibility failure. No complete runtime or universal hardware speed
  ceiling is claimed.
- Full-context MTP initialization remains `BLOCKED_REQUIREMENT` with
  `full_context_feature_stream_authorized=false`. Only nine selected target
  feature rows are exported per near-full probe; no full prompt stream or
  hidden draft sidecar is constructed.

Loaded Windows telemetry confirms the target at Gen5 x8; the 4090 is idle.
WSL swap use was zero during the later run. All owned model and telemetry
workers exited. The final audit found unchanged protected source, checkpoint
metadata/header/size/mtime records, and matching native-extension hashes.
Eight Python source files passed `ast.parse`; hardware probes provide the
behavioral evidence. No commit, launcher edit, weight conversion or download
was performed.

## Required help / next action

Stop dependent implementation and review the approach with the user. A new
target verification design would need to demonstrate at least the measured
target deficit plus real MTP overhead in savings while preserving greedy
outputs. The alternative is a deliberate revision of the performance
requirement. Neither is silently adopted by this report.

See `g2-summary.json` for the gate decision, `g2-completed-components.json`
for exact commands and numbers, `g2-state-inventory.md` for ownership and
restore scope, and `frontier-contract.md` for target row alignment.
