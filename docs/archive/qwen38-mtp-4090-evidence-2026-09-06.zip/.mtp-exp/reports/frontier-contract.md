# G2 initial oracle contract (declared before execution)

The first probe uses width two: pending anchor u at processed length f, then
one known ordinary-target candidate d1 at f+1. Row-zero logits predict d1;
row-one logits predict correction/bonus z. A full acceptance retains two
processed rows, advances processed length to f+2, and leaves z pending.
Zero acceptance retains only row zero and leaves its prediction pending.

`VerifyRows` is the explicit verification intent. It holds ordinary per-row
decode metadata for one request at consecutive frontiers. `forward_verify`
walks the decoder layers once, preserves per-row GDN/QSA/PLE and dense math,
and groups the routed experts once per layer. It does not call full-model
forward per row. Scheduler lengths, page ownership, sampling and output
publication are deliberately outside this initial math probe.

The wide feature is the final decoder residual before
`model.hyper_connection_mixer.mix`: BF16 [rows,10240]. LM-head input is
[rows,2560] and is not the recursive wide feature. Every row's logits are
retained. No complete prompt features are captured or transferred.

Initial numerical policy: exact tensors and exact greedy IDs, since this
slice retains the same per-row arithmetic and G1 proved exact grouped
expert output. Record finite status, max absolute error and relative RMS
separately. Any mismatch fails this probe; no post-result tolerance waiver.
Future arithmetic variants require a separately declared policy before run.

Reference snapshots cover recurrent and convolution pools, PLE convolution
and n-gram slots, allocated QSA KV pages, compressed rows and scratch/ring,
page-table/free-list records, and per-request frontiers. Expert LRU and bank
contents are performance state, not semantic rollback data. CPU snapshots
and ordinary replay are diagnostic only and excluded from speed claims.

Subsequent probes passed future-candidate perturbation and both depth-one
semantic restore/replay boundaries, followed by six or seven ordinary rows.
Near-full probes at positions 261155/261156 and 261891/261892 also passed
bit-exact comparisons and unchanged immutable-prefix checksums. The saved
oracle fixture includes h_prev at f-1 and every tested row's wide feature.

The slow oracle does not publish output or apply a scheduler transaction;
its retained-prefix/frontier counts are reported explicitly. Page allocation,
shared-prefix COW/refcounts, terminal truncation and fast boundary selection
remain unverified. G2 is stopped for the current path's measured economics;
see g2-report.md. No G3 or later implementation is authorized by a G2 pass.
