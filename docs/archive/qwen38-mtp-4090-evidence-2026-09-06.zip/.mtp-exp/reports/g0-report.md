# G0: PASS for target identity and matched repeatability

The protected target loads, runs at native 262144-token capacity, and
reproduces raw greedy output under matched prefix conditions. This passes
G0 and permits the first G1 offload probe. It is not a final performance or
MTP correctness result.

## Evidence

- Protected SHA: `af71ba43206e124f5ff6419b47ee36c6e9981078`.
- Target: 5090 UUID `GPU-67921d1c-ee8e-304f-b562-d6f87617c5a0`.
- Unchanged original BF16 numerics, offload backend, zero CPU expert layers,
  disk PLE, hybrid radix caching, and native capacity.
- Short prompt: identical cold raw IDs across fresh processes, and identical
  cache-hit repeats. See `g0-short-matched.json`.
- Near-full framed code prompt: 261120 frozen input IDs plus a 1024-token
  budget. Two fresh processes each emitted 1023 IDs per request, finishing
  by length. All cold IDs/finish reasons matched across the processes; both
  pairs of cache-hit IDs/finish reasons matched within their processes.
- Actual cached-token counts in both processes: 0, 261056, 261056.
- Near-full runs: `20260905T063512.314677Z` and `20260905T064122.954190Z`.
- All checkpoint metadata hashes and shard size/mtime records remained
  unchanged; the protected source status was empty after both runs.

The offline scheduler supplied requests and saved token replies without
model/sampler/state hooks or hidden-feature export. Source paths, arguments,
resolved configuration, timings and raw results are stored with each run.
The two resolved configurations differ only in their process identifier.

## Corrected comparison and benchmark framing

The earlier G0 failure report compared a cold request against a cache hit.
Those are separate execution conditions in plan section 9.3. Their numerical
and token differences remain documented in `g0-diagnosis.md`; they do not
by themselves establish failure to repeat an identical execution condition.
The corrected policy was frozen in `g0-matched-protocol.md` before inspecting
the new near-full results. Future MTP comparisons must use the corresponding
prefix/frontier and retain exact greedy-token equality.

The original raw-text near-full case completed all prefill, but emitted only
an end-of-turn ID. It remains a capacity/EOS result, with no decode-throughput
sample. The separately frozen `near-full-chat-code` case uses the same code
question with the checkpoint's chat template. No EOS suppression was used.
Both cases remain in the corpus manifest with their identities and labels.

## Timing and verification limits

The six framed near-full requests measured 42.9-45.5 token/s using offline
scheduler reply arrival. Cold time to first token varied from 84.8 to 209.7
seconds, while cache-hit values were 2.40-2.61 seconds. These are diagnostic
measurements, not accepted baseline B, client end-to-end latency, or evidence
that the 1%/3% final equivalence margins have been resolved.

The near-full code workload is synthetic. Final held-out primary acceptance
is still pending. Cold/hit floating-state differences and the diagnosed BF16
boundary rounding remain relevant to G2's same-frontier oracle checks.
No MTP feature stream was exported. Full-context MTP initialization remains
`BLOCKED_REQUIREMENT`; G0 does not change that authorization boundary.

## Next action

G1 is running the existing native NVFP4 offload path with real captured
inputs/routes at 2/3/5 rows. It must establish output correctness, real cache
and byte behavior, layer latency, bridge costs and target contention before
the full G1 gate can pass. The experiment now has its own interpreter prefix,
matching existing dependencies reused read-only, and hash-identical copies
of the three existing native extensions. No packages were upgraded.
