Qwen3.8 / FreeToken MTP — G2 disposition and final target-only feasibility check

Version: 2.2 (narrow addendum to plan 2.1, not a replacement implementation plan)
Date: 2026-09-05
Decision: accept the current G2 economics failure; authorize only the bounded G2R investigation below.

Agent kickoff

Read this directive together with Qwen38_FreeToken_MTP_Agent_Plan_v2_1.md. Preserve the existing G2 report and failed status. Do not mark G2 complete, resume G3–G6, load the MTP model, build a daemon, implement serving, or alter the acceptance criteria.

Investigate one remaining target-side hypothesis: the verifier leaves reusable dense projections as independent one-row operations, whereas the pinned implementation has existing multi-row dense paths. Determine whether exposing those paths at verification widths 2, 3, and 5 creates meaningful target-only headroom. Preserve ordinary row-ordered GDN/convolution/PLE/QSA state updates. Width two is a control, not a required profitability prerequisite for testing widths three and five.

First audit the actual local dispatch and microbenchmark the real expensive operators. Integrate only a candidate supported by those measurements. Use existing kernels; this directive does not authorize a new kernel-development program. Stop at the end of G2R regardless of outcome. Insufficient economics means close this MTP experiment under its current constraints, not repeatedly ask to broaden the optimization scope.

1. Evidence and what has failed

The evidence below is reported by the implementation agent in the user's pasted execution report, dated 2026-09-05. The reviewer has not inspected its local raw logs, new verify.py, checkpoint, or GPUs. The agent must inspect the actual local artifacts before running new work. Do not replace local evidence with this summary.

Case

Ordinary two-row median

Captured verification median, including PLE preparation

Short, positions 101–102

31.510 ms

32.527 ms

Near-full, positions 261155–261156

62.677 ms

62.836 ms

Near-full, positions 261891–261892

42.259 ms

42.850 ms

The later verifier's fastest reported sample is 42.608 ms. At perfect acceptance and with zero omitted overhead, its hypothetical ceiling is 2000 / 42.608 = 46.9395 token/s. The median corresponds to 46.6744 token/s. These are fixed-oracle diagnostic rates, not measured MTP output rates or universal hardware ceilings.

The provisional protected baseline is 45.5189 token/s, measured with offline synthetic scheduler timing. For this investigation, use:

B_provisional = 45.5189 token/s
R_screen = max(48, 1.20 * B_provisional) = 54.62268 token/s
required full-cycle cost = 1000 / R_screen = 18.307414 ms/emitted token
perfect-acceptance width-two full-cycle budget = 36.614827 ms
current later width-two target deficit = 42.850 - 36.614827 = 6.235173 ms

The definitive G6 baseline must still be measured under the original comparable client/workload protocol. Do not substitute the historical approximately 40 token/s figure merely to lower this screening hurdle. Neither the provisional baseline nor three samples establishes final G6 statistics.

Reported profile: expert fetch 20.364 ms; two dominant dense matrix-vector kernel groups 10.330 ms; native routed NVFP4 expert kernels 1.901 ms; all 3523 profiled kernels total 38.923 ms. The early frontier's expert-fetch group was 36.506 ms. These are instrumented GPU durations, not independently additive production wall-clock components or physical byte measurements.

The G1 route replay's 0.31% marginal expert-byte reduction applies to its width-two trace/cache comparison. It does not establish raw expert intersection, width-three/five behavior, or the routes of rejected drafts.

Retain these findings:

Current width-two, row-wise-dense verifier: FAIL_ECONOMICS.

Tested numerical/semantic equivalence: retain exactly its reported scope; not complete transaction correctness.

MTP equations, acceptance, canonical draft cache, bridge loop and production rollback: NOT_RUN.

Full-context MTP initialization: BLOCKED_REQUIREMENT.

2. The sole new hypothesis

Move independent dense projections outside the per-row state-update loops and invoke existing small-row kernels on contiguous row blocks. Leave causally stateful operations ordered. Test widths 3 and 5 as target-only oracle designs, not as a premature deeper MTP implementation.

This changes the proposed mechanism. Width-two expert-byte amortization is not supported by the report. The new hypothesis is primarily dense-weight/dispatch reuse; any expert-byte improvement at wider widths must be separately demonstrated.

Public source inspection at baseline SHA af71ba43206e124f5ff6419b47ee36c6e9981078 found:

layers/linear.py: ordinary dense forwarding calls F.linear.

kernel/triton/nvfp4_linear.py: _linear_impl dispatches one row to _gemv and multiple rows to _gemm; the small-row path uses an in-kernel packed-weight GEMM rather than the large-prefill scratch path.

models/qwen4_exp/gdn.py: input projections precede convolution/recurrence; output projection follows recurrence/norm/gating. This provides a candidate separation seam.

models/qwen4_exp/attention.py: QKV/index projections and output projection are separate from the stateful QSA backend.

These are source-supported seams, not proof that the actual local verifier can use them correctly or efficiently. Audit local changes, loaded tensor representations and dispatch before relying on them. The dense profile groups' actual call sites are currently unknown to the reviewer.

Mathematically, stacking inputs to a shared linear map allows Y = X W^T. It does not justify batching multiple sequential updates to the same mutable state as if they were independent requests. It also does not guarantee bitwise-equivalent floating-point evaluation or a speedup at very small row counts.

3. Unchanged boundaries

All plan 2.1 isolation, hardware, checkpoint, precision, target-cache accounting, offline loading, logging and owned-process cleanup rules remain.

In particular: target stays on the 5090; CPU-resident routed experts retain the same offload policy; moe_cpu_layers=0; no target experts on the 4090; no full target duplication; no P2P/driver/BIOS/topology changes; no weight conversion or new checkpoint; no commits, pushes, launcher edits or upstream publication.

full_context_feature_stream_authorized=false remains in force. Use only bounded selected feature rows. No full-context MTP prompt stream, hidden warmup or sidecar construction is needed for G2R and none is authorized.

No general kernel autotuning campaign, new CUDA/Triton matrix-multiplication implementation, new GDN chunk recurrence, QSA algorithm replacement, PLE backend change, CPU-MoE port, transport rewrite, donor framework merge or serving integration.

4. G2R-A — Audit and real-operator screen before integration

A1. Read existing evidence

Read g2-summary.json, g2-completed-components.json, g2-final-audit.json, g2-state-inventory.md, frontier-contract.md, actual verify.py, and the recorded profiler groups. Locate these from the existing manifest; do not invent their absolute paths.

Recover G1 width-three/five route/cache results if they already exist. Otherwise replay the existing real trace at widths three and five with the validated global cache simulator. Do not substitute independent per-layer hit rates or assume that a larger union saves bytes. This is an offline diagnostic, not a target-speed result.

Identify the two dense kernel groups by symbol, loaded class, call site, tensor shape/dtype/layout, calls per layer/block, and time. Separate invariant per-row projections from genuine causal state dependencies. Check whether the proposed multi-row paths were already tested and rejected; do not repeat an identical failed experiment under a new name.

A2. Microbenchmark the existing paths on real weights and inputs

Capture a bounded selection of actual operator inputs at the expensive call sites. For each material unique shape, compare:

reference: m separate ordinary one-row calls
candidate: one existing operator call with X shaped [m, K]
m in {2, 3, 5}; m=1 is a control

For BF16 operators, retain the resolved F.linear backend. For native NVFP4 dense operators, exercise the existing small-M packed-weight dispatch. Do not force large-prefill dequantization or change the checkpoint representation.

Include packing, splits and required output copies in the candidate cost. Reuse ordinary dependency/environment settings and buffers. Record actual kernel dispatch; a batched Python tensor that still launches independent GEMVs is not evidence of weight reuse.

Warm kernels consistently. Use repeated paired/reordered timings. Test both isolated operator timing and a representative layer-order replay when weight-cache residency makes an isolated hot-weight benchmark optimistic. Account for all affected call sites, not only the fastest shape.

Validate outputs under the already declared numerical policy before treating timing as useful. Record maximum/RMS error, nonfinite checks and any changes in following router decisions. The existing small-M NVFP4 path changes its arithmetic organization; do not assume it reproduces the GEMV reduction order. Do not enable reduced precision or relax tolerances to make a failed candidate pass.

A3. Decide whether to integrate

Estimate the whole-block opportunity using measured operator deltas, actual call counts, wider route/cache replay, and explicitly labelled assumptions about the unchanged work. A subtraction of profiler group durations from wall time is a sensitivity model, not a measured latency or rigorous hardware lower bound.

For scale: merely halving the reported 10.330 ms dense group would predict 37.685 ms for width two if everything else stayed unchanged. That would still exceed the 36.614827 ms perfect-acceptance budget before MTP overhead. This is an illustration, not a universal limit on dense optimization.

Proceed to B only if existing operator measurements and the wider-row screen identify a concrete candidate with material room for the reserve in section 6. If operators are already batched, show no material savings, fail the numerical contract, or offer only an obviously inadequate gain with unchanged fetch work, stop. Do not build B merely to complete a checklist.

A screen-based no-go is an engineering decision with uncertainty, not a claim that an unexecuted full model has a measured speed.

Required outputs: g2r-dispatch-audit.md, g2r-operator-results.jsonl, wider route/cache replay, and g2r-screen.md.

5. G2R-B — One narrow blockwise-projection verifier

Only after A identifies a viable candidate, adapt the existing verifier to expose the measured independent dense operations. Reuse existing kernels. Retain row loops for everything whose batching has not been validated.

Conceptual ordering for a GDN layer:

all row inputs at this layer are available
  -> existing per-row PLE/hyper-connection input handling
  -> block input projection(s)
  -> ordered convolution + recurrence for each row
       with that row's original metadata and intermediate boundary state
  -> existing per-row norm/gate handling
  -> block output projection
  -> existing hyper-connection combination
  -> block MoE using the validated on-demand cache path

For QSA, batch only demonstrated independent projections; retain per-row norm/position operations and causal backend updates unless they already have a separately validated block implementation. Producing a future row's Q/K projection must not publish its KV/index data to an earlier row.

At most widths 2, 3 and 5 are allowed. Exercise all three in operator tests; integrate full-stack widths supported by A. A failing width-two speed screen does not prohibit a justified width-three/five test. Still validate state correctness at width two as a reference/control.

B1. Required correctness before timing

Use independent ordinary-target replay, fresh per-mode metadata and identical logical prefixes. Preserve the existing harness fixes. Check all valid row outputs, greedy IDs, numerical state policy, exact discrete frontiers, future-candidate perturbation, and unchanged preceding pages. Record route-ID changes and do not misattribute a different routing computation's traffic to pure batching reuse.

Cover a=0..m-1 with the existing slow restore/replay oracle, plus subsequent ordinary continuation, at the supported boundaries. This is diagnostic correctness, not implementation of fast commit. New allocations, COW, refcounts, terminal publication and untested boundary behavior remain explicitly unverified.

A greedy mismatch is a failure. Isolate the first divergence; do not expand the kernel scope or quietly loosen equality requirements. A numerically invalid faster candidate is not a speed result.

B2. Timing and representativeness

Keep PLE preparation and every new packing/buffer step inside measured verification cost. Do not subtract preparation because it might be overlapped by a future drafter. Graph timing alone is not complete verification timing.

The full-stack oracle supplies candidate token IDs only. Compute projections, routing, expert fetch, state updates and outputs in the measured implementation; do not replay precomputed operator outputs or hardcode oracle routes. Captured graphs must consume the tested runtime inputs and independent causal metadata. Captured-input operator microbenchmarks remain separately labelled operator diagnostics.

Use both original near-full regions and a predeclared position-stratified panel from the same frozen continuation, including early/middle/later portions. Select positions before observing new timings. Preserve exact context/output limits. Unsupported page-crossing windows are recorded, not silently shifted to more favorable positions.

Use at least five paired/reordered samples per final diagnostic condition, after matching semantic state and expert-cache contents/mappings. Perform profiler collection separately. Do not require an entire G6 matrix for this screen. If uncertainty crosses a decision boundary, allow one predeclared repeat increase, then report INCONCLUSIVE and stop.

Report each region and a fixed-weight panel cost per verified row. Do not average reciprocal token/s values. For totals, use total oracle rows divided by total wall time. A fixed-oracle, all-accepted diagnostic is not a measured output-token benchmark.

If a representative contiguous oracle run is feasible without a new allocator/transaction implementation, prefer it for verifying persistent cache behavior. Otherwise state that the selected-window panel is only a feasibility screen. Do not hide the early slow region or claim a final workload gain from the later fast region.

Fallback/adaptive operation is not implemented in G2R. A hypothetical fallback curve may be shown separately, with all baseline fallback time included; it cannot pass this fixed-design screen by deleting slow windows.

Required outputs: g2r-verify-results.jsonl, comparisons, timing panel, source/command hashes and g2r-decision.md.

6. Quantitative decision and stop rules

For width m = k+1, let T_v be measured complete target verification milliseconds. Let L=A+1 be actual emitted tokens in a normal MTP round, and H be the additional exposed wall-time cost of drafting, bridge, catch-up, commit and output. These quantities are not measured by G2R except T_v.

E[L] = 1 + sum(j=1..k) P(A >= j)
required: E[T_v + H] <= 1000 * E[L] / R_screen
perfect-oracle allowance: 1000 * m / R_screen
H_max(E[L]) = 1000 * E[L] / R_screen - E[T_v]

The dependence between acceptance, target routes and time matters. A positive H_max calculated on oracle candidates is opportunity, not a guarantee for real rejected routes.

Report a sensitivity table for emitted-row efficiency eta=E[L]/m in {0.7, 0.8, 0.9, 1.0} and added cost H in {0, 2, 4, 8} milliseconds/round. These are scenarios, not acceptance or latency measurements. Also report H_max directly so a future measured drafter can be compared without inventing acceptance.

Practical continuation reserve

For this final rescue investigation, use a proposed investment cutoff of 20% unused perfect-oracle cycle budget:

T_v <= 0.80 * 1000 * m / R_screen

This reserve is a new explicit engineering spending rule, NOT a change to the user's final speed requirement, NOT an observed acceptance rate, and NOT a mathematical necessity for every successful MTP design. It intentionally declines to fund designs that work only with almost perfect acceptance and negligible omitted cost. A design with less reserve could theoretically succeed with an exceptionally good drafter; that has not been measured here.

At the current provisional baseline:

Width m

Draft depth k

Perfect-acceptance total-cycle allowance

Target-only continuation cutoff (20% reserve)

2

1

36.6148 ms

29.2919 ms

3

2

54.9222 ms

43.9378 ms

5

4

91.5371 ms

73.2297 ms

The reserve pays jointly for acceptance loss and exposed non-target work; it cannot be counted twice. For a single representative condition, the remaining normalized slack is:

eta - (R_screen * (T_v + H) / (1000 * m))

Passing the 20% screen does not prove that actual MTP acceptance/cost fits. Evaluate the predeclared representative panel and show region-specific reserve; do not qualify from one cherry-picked block.

Outcomes

HARD_STOP_ECONOMICS: tested candidate designs fail the perfect-oracle allowance on the representative screen; no dependent work. State the tested scope, not universal impossibility.

HARD_STOP_SCOPE: no correct, materially useful existing-kernel candidate, or success would require an excluded redesign. Preserve first-divergence evidence.

NO_GO_INSUFFICIENT_RESERVE: a target-only candidate may beat the mathematical hurdle but fails the proposed 20% investment reserve. Close this scope on engineering grounds; do not label it a proof of impossibility.

TARGET_OPPORTUNITY_FOUND: correct, measured target-side headroom meets the reserve and is explained by actual operator/traffic evidence. This is not G2 completion, MTP feasibility, or permission to resume G3–G6.

INCONCLUSIVE / BLOCKED_ENVIRONMENT: unresolved evidence or execution access; no fabricated failure/pass and no dependent work.

Stop after any outcome. For TARGET_OPPORTUNITY_FOUND, the next separately reviewed action is completion of remaining G2 correctness requirements followed by the smallest authorized MTP cost/alignment/acceptance measurement. Full-context MTP remains blocked by initialization authorization; short-context measurements cannot certify near-full-context performance.

7. Closeout and mechanism reporting

Preserve the existing baseline, experiment sources, all failure logs, exact commands, source hashes and the new bounded evidence package. Do not delete failed experiments or create a commit as a cleanup step.

Report:

Current verifier disposition: FAIL_ECONOMICS (unchanged)
G2R outcome:
What actually ran:
Existing dense dispatch before/after:
Correctness and unverified boundaries:
Per-region and representative-panel target times:
Actual/logical expert traffic provenance:
Reserve and acceptance/overhead sensitivity:
Memory/cache-capacity effect:
Full-context initialization status: BLOCKED_REQUIREMENT
Protected-source audit:
Next action: STOP / separately reviewed measurement

A dense-compute gain is not an expert-PCIe-byte-reduction claim. Report both mechanisms separately under plan 2.1 section 2.3. A general improvement also available to ordinary decoding is a target-only optimization, not automatically an MTP benefit.

If the rescue fails, close this experiment under the current checkpoint, hardware allocation and performance requirements. Retain the correctness harness for future use. New hardware, target-expert placement, CPU execution, a different drafter or a relaxed objective would be new experiments, not automatic continuations of this one.

8. Review sources

S1: the user's pasted G2 execution report dated 2026-09-05 (all local measurements above are source-reported to the reviewer).
S2: Qwen38_FreeToken_MTP_Agent_Plan_v2_1.md (read in this conversation).

Public primary sources checked during this review support the candidate seams and numerical caveats, not the local runtime outcome. Reuse the pinned baseline, not moving main branches. No model or dependency downloads are authorized.

Dense BF16 forwarding:
https://raw.githubusercontent.com/FlashML-org/FreeToken/af71ba43206e124f5ff6419b47ee36c6e9981078/python/freetoken/layers/linear.py

Native NVFP4 dense single-row / multi-row dispatch:
https://raw.githubusercontent.com/FlashML-org/FreeToken/af71ba43206e124f5ff6419b47ee36c6e9981078/python/freetoken/kernel/triton/nvfp4_linear.py

GDN input/core/output separation:
https://raw.githubusercontent.com/FlashML-org/FreeToken/af71ba43206e124f5ff6419b47ee36c6e9981078/python/freetoken/models/qwen4_exp/gdn.py

QSA projection/backend separation:
https://raw.githubusercontent.com/FlashML-org/FreeToken/af71ba43206e124f5ff6419b47ee36c6e9981078/python/freetoken/models/qwen4_exp/attention.py

Matrix multiplication memory reuse and small-shape limitations:
https://docs.nvidia.com/deeplearning/performance/dl-performance-matrix-multiplication/index.html

Batched versus sliced numerical accuracy:
https://docs.pytorch.org/docs/2.14/notes/numerical_accuracy.html