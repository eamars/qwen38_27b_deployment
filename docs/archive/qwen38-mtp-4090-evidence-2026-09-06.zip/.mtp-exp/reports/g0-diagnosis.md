# G0 numerical diagnosis

Evaluation update: the earlier blanket G0 failure classification below is
being reassessed under [g0-matched-protocol.md](g0-matched-protocol.md).
The measurements remain valid. Cold/hit comparisons and repeatability under
matching prefix conditions are now explicitly separated.

Status: **FAIL_CORRECTNESS retained; MTP implementation remains gated.**
The diagnostic instrumentation is partially verified on the real 5090 target.
The observed failure is a difference between prefix conditions. Two repeated
cache-hit requests are bitwise stable in the observations below; the evidence
does not show random variation between those identical execution conditions.

## Reproduction

`benchmarks/qwen38_mtp_diagnose.py` runs the protected scheduler with offline
request/reply I/O and observation hooks. It retains the actual checkpoint,
offload backend, zero CPU expert layers, PLE, hybrid radix cache, capacity,
overlap scheduling, and captured decode graphs. CPU tensor copies synchronize
the diagnostic path, so none of its timings is a performance result.

The frozen prompt has 66 input tokens and a 128-token output budget. The
default diagnostic issues a cold request and then two cache-hit requests,
waiting for the overlapped scheduler to drain between them. Each returns 127
raw output IDs. Admission records show 0, 64, and 64 cached prompt tokens.

Records:

- `probes/20260905T055016.241302Z`: initial two-request instrumentation.
- `probes/20260905T055655.984880Z`: cold/hit/hit control and component probes.
- `probes/20260905T060215.263830Z`: isolated first-layer mixer replay.
- `probes/20260905T060333.417587Z`: full-target reduced-precision-reduction-disabled variant.

The cold/hit pair diverges at zero-based output row 36:

| Condition | Chosen token | Text | Logit of 6088 | Logit of 83876 |
|---|---:|---|---:|---:|
| Cold | 6088 | ` mention` | 20.75 | 20.75 |
| Hit | 83876 | ` iterative` | 20.75 | 20.875 |

The cold row has a top tie; argmax chooses the lower token ID. The warm row
has a 0.125 top margin. Decoding the captured raw IDs reproduces exactly the
two SHA256 text hashes from the public-API runs. The two warm requests match
in every raw ID, full recorded logit vector, and captured prefill tensor.
This is a measured control, not an exemption for the cold/hit mismatch.

## First numerical difference: hyper-connection down projection

The first layer receives identical residual-stream input for the final two
prompt tokens. Its hyper-connection mixer produces different GDN inputs.
Replaying only the actual first-layer mixer weights and the 66 selected
embedding rows reproduces both observed mixer outputs exactly. No expert
bank or complete embedding table is loaded by this replay.

| Component, 66-row call versus identical final 2 rows | Maximum absolute difference |
|---|---:|
| Grouped normalization | 0 |
| Mixer down projection | 0.5 |
| Mixer gate projection | 0.125 |
| Mixer output / GDN input | 0.015625 |

The baseline has `torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction=True`.
Disabling that option in the isolated replay makes all compared mixer
components exact across the two shapes. FP32 GEMMs followed by BF16 stores
also produce equal final mixer outputs for this case, with a small internal
gate difference. These are explicit numerical variants, not changes to the
protected source or baseline configuration. Their outputs also differ from
the original baseline; this is not an established serving fix.

The separate GDN projection probe produces exactly equal results for the
same input evaluated at 66 and 2 rows. Its observed cold/hit difference
comes from the already different mixer inputs in this example.

## Independent recurrent-state precision loss

The first GDN's boundary-64 chunk state `h` is BF16, while the live recurrent
pool is FP32. `_write_track_snapshot` converts the rounded `h` back to FP32.
The restored warm state matches that saved snapshot exactly. The tested
restore copy is therefore faithful to its input, which has already lost
precision.

Using captured real first-layer q/k/v/g/beta inputs:

| Comparison | Maximum absolute difference | Relative RMS |
|---|---:|---:|
| Boundary-64 BF16 snapshot versus FP32 state after 64 tokens | 0.0068757534 | 0.0015870879 |
| Full 66-token final state versus 64+2 with FP32 intermediate | 0 | 0 |
| Full final state versus 64+2 restored from the rounded snapshot | 0.0067391396 | 0.0012336746 |

The final two BF16 core output rows match in both split probes. The
recurrent-state difference remains available to affect subsequent decode.
This establishes precision loss and its persistence, not that it alone
causes the first full-model token mismatch. No blanket tolerance was adopted.

Source locations in the unchanged protected checkout:

- `python/freetoken/models/qwen4_exp/hc.py`: `_down`, `_mix_kernel`.
- `python/freetoken/kernel/fla/chunk_delta_h.py`: `h = k.new_empty(...)`.
- `python/freetoken/models/qwen4_exp/gdn.py`: `_write_track_snapshot`.

## Full-target numerical variant

The opt-in `--disable-bf16-reduction` diagnostic sets the BF16 reduction
option to false before model initialization and graph capture. The recorded
resolved runtime confirms the option is false and labels the run as modified
numerics. No protected file or default runtime setting is changed.

All three requests produce exactly the same 127 raw output IDs. The two
cache-hit requests also match in all recorded logits and prefill tensors.
The first GDN projection, convolution, and core output now match between
the cold and warm requests. This corrects the observed short-prompt token
counterexample within this variant.

It does not establish complete numerical equivalence: the first GDN final
state still differs (maximum absolute error 0.0073666573, relative RMS
0.0012508397), the first layer output differs, and subsequent logits differ.
The original protected-baseline outputs are not replaced by this result.
The variant differs from both original sequences at zero-based output row
32, so adopting it would change the frozen reference. Across its 127 emitted
rows, the cold/hit logit maximum absolute difference reaches 1.5625 despite
matching selected tokens.
Only one short prompt was checked in the variant; no performance acceptance
or near-full-context claim follows from it.

## Limits and next permitted action

The first mismatch is now localized, and raw IDs/logit margins replace the
earlier text-only diagnosis. This is not a complete attribution across all
48 layers, a validated numerical correction, or a near-full-context result.
The exact greedy mismatch remains recorded, and G1-G6 have not started.
The protected source, launchers, and checkpoint remain read-only. Full-context
MTP feature streaming is still `BLOCKED_REQUIREMENT`.

The concrete numerical correction to review is disabling reduced BF16
accumulation, together with preserving FP32 boundary snapshots and checking
remaining layer differences. Only the first part has been exercised as a
full-target diagnostic. Adopting different reference numerics requires an
explicit revision of the frozen-reference contract; it cannot silently
replace the protected baseline. Further independent state diagnosis is
allowed, but dependent MTP implementation/performance gates remain stopped
under plan sections 2.2, 8/G0, and 12.
