# G0 matched-condition reference protocol

This corrects the earlier G0 evaluation, which used a cold request and a
cache-hit request as if they had identical execution state. Plan section 9.3
separates those conditions. The cold/hit numerical differences in
`g0-diagnosis.md` remain evidence; no result or counterexample is discarded.

The hypothesis is that ordinary target decoding supplies a stable reference
within each declared prefix condition. MTP comparisons must subsequently
start from the corresponding target prefix/frontier. A token mismatch there
remains a correctness failure even when floating errors are small.

The following policy is frozen before inspecting the new near-full results:

1. Use the exact protected SHA, checkpoint, discovered argv, GPU UUID,
   original BF16 settings, offload backend, zero CPU expert layers, disk PLE,
   native 262144-token capacity, and enabled production prefix cache.
2. Supply the existing frozen IDs through the protected offline scheduler.
   No model/sampler/state hooks, numerical overrides, or hidden-feature
   capture are installed. The only adapter supplies requests and saves replies.
3. In each fresh process, issue one cold request and two subsequent identical
   requests after the previous overlapped forward has drained. Confirm the
   actual cached-token counts from PromptAdmittedMsg, not the request order.
4. Compare raw IDs, emitted lengths, and finish reasons between the two hits.
   Their cached-token counts must be equal and nonzero.
5. Repeat in a new process. Compare its cold request against the previous
   cold request, requiring zero cached tokens and matching identity/settings.
6. Preserve the cold/hit comparison as a separately labeled numerical
   diagnostic. It does not establish matched-state repeatability by itself.
7. Stop dependent work on a mismatch under the matched conditions. Do not
   suppress EOS, replace corpus cases, change numerical settings, or loosen
   greedy equivalence to obtain a pass.

Short-context raw-ID evidence already exists in the two unchanged-math
diagnostic runs `20260905T055016.241302Z` and `20260905T055655.984880Z`.
The new target-only reference runner performs the near-full shape with
261120 input tokens and a 1024-token output budget. The prompt remains
labeled SYNTHETIC_LOCAL_SOURCE_DIAGNOSTIC. It does not replace the final
held-out code benchmark or establish a G6 performance result.

Scheduler reply timestamps are recorded with exact output-ID counts. They
are offline diagnostic timing, not client end-to-end latency or an accepted
fresh baseline B. Model loading, graph capture, and source identity are
retained in the run logs. Full-context MTP feature streaming is not involved.

## Prompt framing correction

Run `20260905T062246.968025Z` completed the entire original raw-text capacity
case. All three requests emitted only token 248046 (`<|im_end|>`) and stopped.
The warm IDs and finish reasons matched, but N=1 yields no decode-throughput
sample. The run remains recorded as a capacity/EOS diagnostic; no forced
length or EOS suppression is introduced.

Before any further generation, `corpus/build_chat_case.py` froze the same
code question with the checkpoint's user/assistant chat template and adjusted
only the repeated source body to retain exactly 261120 input tokens. This is
the separately named `near-full-chat-code` case. Its IDs, text, builder, and
template hashes are in the corpus manifest. The original case is retained.
The new case uses the same matched-condition protocol and natural EOS.
