"""G2R-A follow-up: actual fused router IDs after local BF16 projection batching."""
import json
from pathlib import Path
import sys

import torch
from freetoken.moe.fused import fused_topk

root, records, output, target_uuid = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
assert torch.cuda.device_count() == 1
assert 'GPU-' + str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') == target_uuid
inventory = json.loads((root/'.mtp-exp/checkpoint-map.json').read_text())
model = Path(inventory['model'])
captured = torch.load(records/'real-operator-inputs-outputs.pt', weights_only=True, map_location='cpu')
results = []
with torch.inference_mode():
    for layer in range(48):
        name = f'model.layers.op_list.{layer}.mlp.gate'
        info = inventory['tensors'][f'model.language_model.layers.{layer}.mlp.gate.weight']
        assert info['dtype'] == 'BF16' and info['shape'] == [512,2560]
        with (model/info['shard']).open('rb') as handle:
            handle.seek(info['file_offset'])
            raw = bytearray(handle.read(info['storage_bytes']))
        weight = torch.frombuffer(raw,dtype=torch.bfloat16).reshape(info['shape']).to('cuda')
        entry = captured[name]
        inputs = [x.to('cuda') for x in entry['inputs']]
        reference = torch.cat([x.to('cuda') for x in entry['outputs']])
        control = torch.cat([torch.nn.functional.linear(x,weight) for x in inputs])
        assert torch.equal(control,reference), f'reconstructed router control differs at layer {layer}'
        for width in (2,3,5):
            x = torch.cat(inputs[:width])
            candidate = torch.nn.functional.linear(x,weight)
            rw, ri = fused_topk(x,reference[:width],10,True)
            cw, ci = fused_topk(x,candidate,10,True)
            row = {'layer':layer,'width':width,'one_row_control_exact':True,
                   'projection_logits_exact':torch.equal(reference[:width],candidate),
                   'router_ids_exact':torch.equal(ri,ci),
                   'router_weights_exact':torch.equal(rw,cw),
                   'changed_id_rows':int((ri!=ci).any(-1).sum()),
                   'reference_ids':ri.cpu().tolist(),'candidate_ids':ci.cpu().tolist(),
                   'maximum_route_weight_error':float((rw-cw).abs().max()),
                   'scope':'direct router-projection perturbation on captured ordinary inputs; no upstream candidate propagation'}
            results.append(row)
output.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({str(width):{'layers_with_changed_ids':sum(not r['router_ids_exact'] for r in results if r['width']==width),
                             'layers_with_changed_weights':sum(not r['router_weights_exact'] for r in results if r['width']==width)} for width in (2,3,5)}))
