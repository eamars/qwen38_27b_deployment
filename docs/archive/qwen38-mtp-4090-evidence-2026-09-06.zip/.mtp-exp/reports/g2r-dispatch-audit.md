# G2R-A loaded dense dispatch audit

Directive 2.2; run `20260905T120221.607636Z`. The audit uses local source,
checkpoint metadata, loaded instances, captured real inputs, and CUDA kernel
traces. It does not infer loaded dispatch from the public source summary.

The actual target has **449 active dense call sites, 13 distinct class/shape/
layout combinations, all BF16**, and **zero native NVFP4 dense instances**.
The routed experts remain native NVFP4 with the unchanged GPU offload policy.
The checkpoint's GDN/QSA projections, shared experts, and untied LM head are
BF16. Exercising `nvfp4_linear._linear_impl` on these weights would require
an unauthorized representation change, so that branch is not applicable.

The loaded classes are 304 `LinearReplicated`, 96 `LinearColParallelMerged`,
48 `LinearRowParallel`, and one `ParallelLMHead`. All use their existing
`F.linear` path at TP=1. Weight dtype is BF16, storage is contiguous [N,K],
and captured inputs are [1,K]. No precision switch, backend replacement,
weight conversion or new matrix multiplication kernel was used.

| Family | Sites / row | Loaded weight [N,K] | Dependency boundary |
|---|---:|---|---|
| GDN merged input | 36 | [16480,2560] | Before ordered convolution/recurrence |
| GDN output | 36 | [2560,6144] | After each row's recurrence, norm and gate |
| QSA merged QKV | 12 | [13312,2560] | Projection may precede ordered KV/index publication |
| QSA output | 12 | [2560,6144] | After causal attention and row gate |
| QSA index Q/K | 12 | [640,2560] | Raw projection only; index pooling/publication stays ordered |
| MoE router | 48 | [512,2560] | Independent projection, but route IDs/weights must remain canonical |
| Shared gate/up | 48 | [1280,2560] | Before row SwiGLU activation |
| Shared down | 48 | [2560,640] | After row SwiGLU activation |
| Layer HC down/inject | 96 | [336,10240] | Per-row normalized wide input; exactness still required |
| HC up, including final mixer | 97 | [10240,320] | After per-row HC activation |
| Final HC down | 1 | [320,10240] | Before final HC activation |
| PLE key / value | 1 each | [10240,2560] / [2560,2560] | After real row-specific disk staging; convolution remains ordered |
| LM head | 1 | [248320,2560] | After final row mixer |

## Attribution of the original two dominant GEMV groups

The exact full CUDA symbols and every loaded call site are saved in
`g2r-dense-group-attribution.json` and the run's `dense-dispatch-summary.json`.
The original G2 symbols contain `internal::gemvx::kernel`, BF16 inputs and
outputs, FP32 accumulator, and specialization parameter 7 or 6.

- Specialization 7: GDN input (36), router (48), shared down (48), QSA QKV
  (12), and QSA index (12): **156 calls per row, 312 per width-two block**.
  Original later G2 duration: 5.702088 ms.
- Specialization 6: GDN output (36), QSA output (12), shared gate/up (48),
  PLE key/value (2), and head (1): **99 calls per row, 198 per width-two
  block**. Original later G2 duration: 4.627774 ms.

The 194 HC sites already select cuBLAS/CUTLASS matrix-multiplication paths
for one row; they are not members of those GEMV groups. Multi-row F.linear
does select matrix-multiplication kernels at the other sites. Thus the
dispatch change is real, but its arithmetic changes must pass the numerical
contract. Kernel symbols for widths 1/2/3/5 were collected separately from
timing. CPU launch correlation maps all profiled kernels to their operator
annotations; a parser refinement excludes GPU annotations from CPU interval
matching. The raw trace is retained, with zero unassigned kernels after
that correction.

## Prior work and scope

The previous verifier loops over ordinary dense calls per row and only
groups routed experts. The G1 probe covered grouped routed expert kernels;
it did not test dense projection batching. Previous HC diagnostics examined
cold/prefix-hit arithmetic, not this real continuation width sweep. This is
the first recorded G2R dense batching screen in the experiment.

G1's wider cache results already exist and were recovered without rerunning
or substituting independent per-layer rates. At widths 1/2/3/5, the 120-row
global replay fetched 15363/15315/15585/15389 experts. Logical bytes are
42593610240/42460531200/43209100800/42665694720. Width three and five changes
versus ordinary are +1.445% and +0.169%. These are actual-trace GPU cache-map
replays multiplied by the validated native expert size, not physical DRAM
counters or full target timings. No new expert-byte reduction is claimed.
