"""G2R-A: bounded real-input screen of existing dense operator dispatch."""
import argparse
import bisect
from collections import defaultdict
import gc
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import time
import traceback

from qwen38_mtp_probe import Evidence, Manifest, CorrectnessFailure, digest, write_json

WIDTHS = (1, 2, 3, 5)
ORDER = ("row", "block", "block", "row", "row", "block", "block", "row", "row", "block")


def walk_ops(model):
    from freetoken.layers.base import BaseOP
    seen = set()
    def visit(name, value):
        if isinstance(value, BaseOP):
            if id(value) in seen:
                return
            seen.add(id(value))
            yield name, value
            for key, child in vars(value).items():
                if not key.startswith("_"):
                    yield from visit(f"{name}.{key}" if name else key, child)
        elif isinstance(value, (list, tuple)):
            for index, child in enumerate(value):
                yield from visit(f"{name}.{index}", child)
    yield from visit("", model)


def errors(reference, candidate):
    import torch
    a, b = reference.detach().cpu(), candidate.detach().cpu()
    assert a.shape == b.shape and a.dtype == b.dtype
    af, bf = a.float(), b.float()
    delta = bf-af
    finite = bool(torch.isfinite(af).all() and torch.isfinite(bf).all())
    rms = float(delta.square().mean().sqrt())
    ref_rms = float(af.square().mean().sqrt())
    differing = (a != b).nonzero()
    first = None
    if differing.numel():
        index = tuple(differing[0].tolist())
        first = {"index": list(index), "reference": float(a[index]), "candidate": float(b[index])}
    return {"exact": torch.equal(a, b), "finite": finite,
            "max_abs": float(delta.abs().max()), "rms": rms,
            "relative_rms": rms/max(ref_rms, 1e-30), "differing_elements": len(differing),
            "elements": a.numel(), "first_difference": first}


def paired_graphs(functions, stream, repetitions):
    import torch
    graphs = {}
    for mode, function in functions.items():
        function()
        function()
        stream.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph, stream=stream):
            for _ in range(repetitions):
                function()
        graphs[mode] = graph
        for _ in range(3):
            graph.replay()
    stream.synchronize()
    results = []
    for mode in ORDER:
        begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        started = time.monotonic_ns()
        begin.record()
        graphs[mode].replay()
        end.record()
        end.synchronize()
        results.append({"mode": mode, "CUDA_ms": begin.elapsed_time(end)/repetitions,
                        "wall_ms": (time.monotonic_ns()-started)/1e6/repetitions,
                        "operations_per_graph": repetitions})
    del graphs
    gc.collect()
    return results


def summarize_dispatch(path):
    events = json.loads(path.read_text())["traceEvents"]
    spans = sorted([x for x in events if x.get("ph") == "X" and x.get("cat") == "user_annotation"
                    and x.get("name", "").startswith("dense::")], key=lambda x:x["ts"])
    starts = [x["ts"] for x in spans]
    launches = {x["args"]["correlation"]: x for x in events
                if x.get("cat") in ("cuda_runtime", "cuda_driver") and "correlation" in x.get("args", {})}
    groups = defaultdict(lambda: defaultdict(lambda: [0, 0.0]))
    unmapped = 0
    for event in events:
        if event.get("cat") != "kernel" or event.get("ph") != "X":
            continue
        launch = launches.get(event.get("args", {}).get("correlation"))
        index = bisect.bisect_right(starts, launch["ts"])-1 if launch else -1
        if index < 0 or launch["ts"] > spans[index]["ts"]+spans[index]["dur"]:
            unmapped += 1
            continue
        item = groups[spans[index]["name"]][event["name"]]
        item[0] += 1
        item[1] += event.get("dur", 0)/1000
    return {"groups": {label: [{"kernel": k, "calls": v[0], "GPU_ms": v[1]} for k,v in group.items()]
                       for label,group in groups.items()}, "unmapped_kernels": unmapped}


def operator_probe(scheduler, output):
    import torch
    from freetoken.layers.linear import _LinearTPImpl
    from freetoken.layers.embedding import ParallelLMHead
    from freetoken.kernel.triton.nvfp4_linear import Nvfp4DenseLinear, Nvfp4LMHead
    from freetoken.models.qwen4_exp.verify import VerifyRows, forward_verify
    from qwen38_mtp_verify import Snapshot, comparison, immutable_prefix_digest, ordinary_rows, state_check

    seed, engine = scheduler.seed, scheduler.engine
    stream, model = engine.stream, engine.model
    eligible = (_LinearTPImpl, ParallelLMHead, Nvfp4DenseLinear, Nvfp4LMHead)
    operators = {name: op for name, op in walk_ops(model) if isinstance(op, eligible)}
    captured = {name: {"inputs": [], "outputs": []} for name in operators}
    call_order, originals = [], {}
    with torch.cuda.stream(stream):
        seed.restore(scheduler)
        seed.restore_expert_conditions(scheduler)
        stream.synchronize()
        try:
            for name, op in operators.items():
                original = op.forward
                originals[name] = original
                def observe(x, original=original, name=name):
                    assert x.ndim == 2 and x.shape[0] == 1
                    entry = captured[name]
                    call_order.append((name, len(entry["inputs"])))
                    entry["inputs"].append(x.clone())
                    y = original(x)
                    entry["outputs"].append(y.clone())
                    return y
                op.forward = observe
            wide, logits, counters = forward_verify(model, VerifyRows(tuple(scheduler.rows[:5])))
            stream.synchronize()
        finally:
            for name, original in originals.items():
                operators[name].forward = original
        captured = {name: entry for name,entry in captured.items() if entry["inputs"]}
        operators = {name: operators[name] for name in captured}
        assert all(len(entry["inputs"]) == 5 for entry in captured.values())
        actual_state = Snapshot(scheduler, seed.req, seed.layout)
        checks = {"wide": comparison(torch.cat([x["wide"] for x in scheduler.reference[:5]]), wide.cpu()),
                  "logits": comparison(torch.cat([x["logits"] for x in scheduler.reference[:5]]), logits.cpu())}
        seed.restore(scheduler)
        ordinary_rows(scheduler, scheduler.rows[:5])
        reference_state = Snapshot(scheduler, seed.req, seed.layout)
        checks["state"] = state_check(reference_state, actual_state)
        checks["counters"] = counters
        write_json(output / "capture-control-comparison.json", checks)
        if not all(checks[k]["exact"] for k in ("wide", "logits")) or not all(x["exact"] for x in checks["state"].values()):
            raise CorrectnessFailure("existing row-ordered width-five input-capture control differs")
        del actual_state, reference_state
        print(f"Captured five real rows at {len(captured)} dense call sites; existing width-five control is exact", flush=True)

        inventory = []
        for name, entry in captured.items():
            op = operators[name]
            entry["packed"] = torch.cat(entry["inputs"])
            entry["destination"] = torch.empty_like(torch.cat(entry["outputs"]))
            weight = op.weight
            inventory.append({"name": name, "class": f"{type(op).__module__}.{type(op).__name__}",
                "input_shape": list(entry["inputs"][0].shape), "input_stride": list(entry["inputs"][0].stride()),
                "output_shape": list(entry["outputs"][0].shape), "weight_shape": list(weight.shape),
                "weight_stride": list(weight.stride()), "weight_dtype": str(weight.dtype),
                "weight_bytes": weight.numel()*weight.element_size(), "bias": op.bias is not None,
                "transposed_native_layout": getattr(op, "_transposed", None), "calls_per_row": 1})
        write_json(output / "loaded-dense-inventory.json", inventory)
        write_json(output / "dense-call-order.json", call_order)
        torch.save({name:{key:[x.cpu() for x in entry[key]] for key in ("inputs", "outputs")}
                    for name,entry in captured.items()}, output / "real-operator-inputs-outputs.pt")

        def invoke(name, width, mode):
            entry, op = captured[name], operators[name]
            if mode == "row":
                for index, x in enumerate(entry["inputs"][:width]):
                    entry["destination"][index:index+1].copy_(op.forward(x))
            else:
                # Packing and explicit row-output copies are charged in the graph.
                x = torch.cat(entry["inputs"][:width])
                y = op.forward(x)
                for index, row in enumerate(y.split(1)):
                    entry["destination"][index:index+1].copy_(row)
            return entry["destination"][:width]

        results, valid = [], {}
        out_file = output / "g2r-operator-results.jsonl"
        with engine.ctx.forward_batch(scheduler.rows[0]):
            for width in WIDTHS:
                valid[width] = []
                for name, entry in captured.items():
                    reference = torch.cat(entry["outputs"][:width])
                    check = errors(reference, invoke(name, width, "block"))
                    row = {"kind": "correctness", "operator": name, "width": width, **check,
                           "policy": "exact", "following_router_decisions": "NOT_RUN: local operator screen; no full candidate integration"}
                    if name == "lm_head":
                        row["head_greedy_ids_exact"] = torch.equal(reference.argmax(-1), entry["destination"][:width].argmax(-1))
                    results.append(row)
                    with out_file.open("a") as handle:
                        handle.write(json.dumps(row)+"\n")
                    if check["exact"] and check["finite"]:
                        valid[width].append(name)
                print(f"width {width}: {len(valid[width])}/{len(captured)} dense sites satisfy exact output policy", flush=True)
            assert len(valid[1]) == len(captured), "ordinary m=1 control must reproduce captured outputs"

            unique = {}
            for row in inventory:
                key = (row["class"], tuple(row["input_shape"]), tuple(row["weight_shape"]), row["weight_dtype"], tuple(row["weight_stride"]))
                unique.setdefault(key, []).append(row["name"])
            for names in unique.values():
                name = names[0]
                for width in WIDTHS:
                    functions = {mode:(lambda mode=mode: invoke(name, width, mode)) for mode in ("row", "block")}
                    samples = paired_graphs(functions, stream, repetitions=32)
                    row = {"kind": "isolated_shape_timing", "representative": name, "matching_call_sites": names,
                           "width": width, "samples": samples, "hot_weight_diagnostic": True,
                           "all_sites_correct": all(x in valid[width] for x in names),
                           "packing_splits_output_copies_included": True}
                    with out_file.open("a") as handle:
                        handle.write(json.dumps(row)+"\n")
                print(f"Isolated operator shape complete: {name} ({len(names)} sites)", flush=True)

            ordered_names = list(dict.fromkeys(name for name,_ in call_order))
            layer_results = []
            for width in WIDTHS:
                def replay(mode, safe_only=False):
                    if mode == "row":
                        for name, index in call_order:
                            if index < width:
                                entry = captured[name]
                                entry["destination"][index:index+1].copy_(operators[name].forward(entry["inputs"][index]))
                    else:
                        for name in ordered_names:
                            invoke(name, width, "block" if not safe_only or name in valid[width] else "row")
                for candidate in ("all_batched", "exact_sites_only"):
                    functions = {"row":lambda:replay("row"), "block":lambda:replay("block", candidate == "exact_sites_only")}
                    samples = paired_graphs(functions, stream, repetitions=1)
                    row = {"kind":"layer_order_operator_replay", "width":width, "candidate":candidate,
                           "samples":samples, "all_sites_correct": candidate == "exact_sites_only" or len(valid[width]) == len(captured),
                           "changed_sites":len(valid[width]) if candidate == "exact_sites_only" else len(captured),
                           "scope":"captured independent operator inputs across actual layer weights; excludes all state updates, experts and full target computation"}
                    layer_results.append(row)
                    with out_file.open("a") as handle:
                        handle.write(json.dumps(row)+"\n")
            write_json(output / "layer-order-results.json", layer_results)

            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]) as profile:
                for width in WIDTHS:
                    for name in ordered_names:
                        with torch.profiler.record_function(f"dense::{width}::{name}"):
                            invoke(name, width, "block")
                stream.synchronize()
            profile_path = output / "dense-dispatch-profile.json"
            profile.export_chrome_trace(str(profile_path))
            write_json(output / "dense-dispatch-summary.json", summarize_dispatch(profile_path))
        prefix = immutable_prefix_digest(scheduler)
        write_json(output / "immutable-prefix-comparison.json", {"before":scheduler.prefix_digest,"after":prefix,"exact":prefix==scheduler.prefix_digest})
        assert prefix == scheduler.prefix_digest
        write_json(output / "A-component-completion.json", {"decision":"COMPLETED_OPERATOR_SCREEN; inspect before any integration",
            "correct_sites":{str(k):v for k,v in valid.items()}, "site_count":len(captured),
            "unique_shapes":len(unique), "native_NVFP4_sites":sum(isinstance(op,(Nvfp4DenseLinear,Nvfp4LMHead)) for op in operators.values()),
            "capture_rows":5,"full_context_feature_stream_authorized":False,
            "allocated_GPU_peak_bytes":torch.cuda.max_memory_allocated(),"reserved_GPU_peak_bytes":torch.cuda.max_memory_reserved()})
        print("G2R-A operator correctness, paired timing, layer-order replay and dispatch profiling completed", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--worker-output", type=Path)
    args = parser.parse_args()
    cfg = Manifest.read(args.manifest)
    root = cfg.experiment / ".mtp-exp"
    assert json.loads((root/"reports/g2-summary.json").read_text())["decision"] == "FAIL_ECONOMICS"
    if args.worker_output:
        assert args.worker_output.resolve().is_relative_to(root/"probes")
        from qwen38_mtp_verify import worker
        worker(cfg, args.worker_output, "near-full-chat-code", 771, operator_probe=operator_probe)
        return
    evidence = Evidence(cfg)
    evidence.source_identity()
    protected_status = (root/"status.json").read_bytes()
    processes = evidence.command(["ps", "-eo", "pid,args"])
    if any(marker in processes for marker in ("freetoken.cli serve", "--worker-output", "--multiprocessing-fork", "llama-server")):
        raise RuntimeError("another model worker is active")
    python = Path(json.loads((root/"environment/experiment-venv.json").read_text())["python"])
    env = evidence.env(cfg.experiment, cfg.target_uuid)
    env["PATH"] = str(python.parent)+":"+env["PATH"]
    argv = [str(python), "-B", __file__, "--manifest", str(args.manifest), "--worker-output", str(evidence.run_dir)]
    state = {"stage":"G2R-A","decision":"IN_PROGRESS","run_id":evidence.run_id,"commands":[argv],
             "G2_disposition":"FAIL_ECONOMICS unchanged","full_context_feature_stream_authorized":False}
    write_json(root/"g2r-status.json",state)
    print(f"G2R-A evidence: {evidence.run_dir}",flush=True)
    try:
        with (evidence.run_dir/"worker.log").open("wb") as log:
            child = subprocess.Popen(argv,cwd=cfg.experiment,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            write_json(evidence.run_dir/"owned-process.json",{"pid":child.pid,"pgid":child.pid,"argv":argv})
            try:
                code = child.wait(timeout=1200)
                if code:
                    raise RuntimeError(f"G2R worker exited {code}; see worker.log")
                state["decision"] = "A_COMPONENTS_COMPLETED; REVIEW_REQUIRED_BEFORE_B"
            finally:
                if child.poll() is None:
                    os.killpg(child.pid,signal.SIGTERM)
                    try:
                        child.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid,signal.SIGKILL)
                        child.wait(timeout=10)
                write_json(evidence.run_dir/"process-exit.json",{"pid":child.pid,"returncode":child.returncode})
    except Exception:
        state["decision"] = "FAILED_PROBE"
        (evidence.run_dir/"failure.txt").write_text(traceback.format_exc())
        raise
    finally:
        evidence.source_identity()
        assert (root/"status.json").read_bytes() == protected_status, "G2 status must remain unchanged"
        write_json(root/"g2r-status.json",state)
        write_json(evidence.run_dir/"g2r-status.json",state)


if __name__ == "__main__":
    main()
