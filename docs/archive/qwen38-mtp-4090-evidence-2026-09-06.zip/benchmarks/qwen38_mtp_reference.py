#!/usr/bin/env python3
"""Protected target repeatability with matched prefix conditions and raw IDs.

Offline scheduler I/O supplies the frozen prompt and records replies. There
are no model, sampler, state, hidden-feature, or numerical-setting hooks.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, replace
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

from qwen38_mtp_probe import CorrectnessFailure, Evidence, Manifest, digest, write_json


class Finished(Exception):
    pass


def run_worker(cfg, case, output):
    import torch
    import freetoken
    from freetoken.core import SamplingParams
    from freetoken.gpu_select import set_assigned_gpu
    from freetoken.message import DetokenizeMsg, ErrorReplyMsg, PromptAdmittedMsg, UserMsg
    from freetoken.scheduler import Scheduler
    from freetoken.server.args import parse_args
    from freetoken.utils import load_tokenizer

    assert Path(freetoken.__file__).resolve() == cfg.baseline / "python/freetoken/__init__.py"
    set_assigned_gpu(cfg.target_uuid)
    path = Path(case["input_ids"])
    assert digest(path.read_bytes()) == case["input_ids_sha256"]
    ids = json.loads(path.read_text())
    assert len(ids) == case["prompt_tokens"]
    assert len(ids) + case["max_new_tokens"] <= case["sequence_capacity"]
    args, _ = parse_args(cfg.baseline_argv[5:])
    args = replace(args, offline_mode=True)
    results = {uid: {"uid": uid, "tokens": [], "arrival_seconds": []} for uid in range(3)}

    class ReferenceScheduler(Scheduler):
        def __init__(self, config):
            self.next_uid = 0
            super().__init__(config)

        def offline_receive_msg(self, blocking=False):
            # Blocking means the preceding overlapped forward has drained.
            if not blocking:
                return []
            if self.next_uid == 3:
                raise Finished
            uid = self.next_uid
            self.next_uid += 1
            results[uid]["started_monotonic"] = time.monotonic()
            print(f"request {uid}: {len(ids)} prompt tokens", flush=True)
            return [UserMsg(uid=uid, input_ids=torch.tensor(ids, dtype=torch.int32),
                            sampling_params=SamplingParams(temperature=0, top_k=1, top_p=1,
                                ignore_eos=False, max_tokens=case["max_new_tokens"]))]

        def offline_send_result(self, replies):
            for reply in replies:
                if isinstance(reply, ErrorReplyMsg):
                    raise RuntimeError(reply.error)
                row = results[reply.uid]
                if isinstance(reply, PromptAdmittedMsg):
                    row["admission"] = asdict(reply)
                if isinstance(reply, DetokenizeMsg):
                    row["tokens"].append(reply.next_token)
                    row["arrival_seconds"].append(time.monotonic() - row["started_monotonic"])
                    if reply.finished:
                        row["finished"] = True
                        row["finish_reason"] = reply.finish_reason
                        row["request_seconds"] = time.monotonic() - row["started_monotonic"]
                        write_json(output / f"request-{reply.uid}.json", row)
                        print(f"request {reply.uid}: finished with {len(row['tokens'])} output IDs; "
                              f"admission={row['admission']}", flush=True)

    scheduler = None
    with torch.inference_mode():
        try:
            scheduler = ReferenceScheduler(args)
            uuid = "GPU-" + str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-")
            assert uuid == cfg.target_uuid
            assert scheduler.engine.cpu_moe_executor is None
            assert scheduler.engine.config.moe_backend == "offload"
            runtime = {"config": json.loads(json.dumps(asdict(scheduler.engine.config), default=str)),
                       "freetoken_path": freetoken.__file__, "gpu_uuid": uuid,
                       "bf16_reduced_precision_reduction": torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
                       "baseline_argv": cfg.baseline_argv, "case": case,
                       "sampling": {"temperature": 0, "top_k": 1, "top_p": 1, "ignore_eos": False},
                       "hidden_feature_rows_exported": 0, "model_hooks": 0,
                       "timing_scope": "offline scheduler reply arrival; not client end-to-end acceptance"}
            write_json(output / "resolved-runtime.json", runtime)
            try:
                scheduler.run_forever()
            except Finished:
                pass
            tokenizer = load_tokenizer(str(cfg.model))
            for row in results.values():
                assert row.get("finished") and row["admission"]["prompt_tokens"] == len(ids)
                row["text"] = tokenizer.decode(row["tokens"])
                row["text_sha256"] = digest(row["text"].encode())
                n, times = len(row["tokens"]), row["arrival_seconds"]
                row["decode_tps_scheduler_reply"] = (n - 1) / (times[-1] - times[0]) if n >= 2 else None
                write_json(output / f"request-{row['uid']}.json", row)
            write_json(output / "results.json", list(results.values()))
        finally:
            if scheduler is not None:
                scheduler.shutdown()


def comparison(first, second):
    same = first["tokens"] == second["tokens"] and first.get("finish_reason") == second.get("finish_reason")
    mismatch = next((i for i, pair in enumerate(zip(first["tokens"], second["tokens"]))
                     if pair[0] != pair[1]), min(len(first["tokens"]), len(second["tokens"])))
    return {"tokens_exact": same, "first_differing_output_row": None if same else mismatch,
            "output_lengths": [len(first["tokens"]), len(second["tokens"])]}


def compare_records(records, previous=None):
    rows = json.loads((records / "results.json").read_text())
    cached = [row["admission"]["cached_tokens"] for row in rows]
    if cached[0] != 0 or not cached[1] or cached[1] != cached[2]:
        raise ValueError(f"unmatched actual prefix conditions: {cached}")
    report = {"cached_tokens": cached, "warm_repeat": comparison(rows[1], rows[2]),
              "cross_condition_diagnostic": comparison(rows[0], rows[1]),
              "cold_repeat": "NOT_RUN: requires another fresh process"}
    if previous:
        prior = json.loads((previous / "results.json").read_text())
        a = json.loads((records / "resolved-runtime.json").read_text())
        b = json.loads((previous / "resolved-runtime.json").read_text())
        for key in ("case", "sampling", "baseline_argv", "gpu_uuid", "bf16_reduced_precision_reduction"):
            if a[key] != b[key]:
                raise ValueError(f"unmatched reference identity: {key}")
        if prior[0]["admission"]["cached_tokens"] != 0:
            raise ValueError("previous cold reference was not a prefix miss")
        report["cold_repeat"] = comparison(prior[0], rows[0])
        report["previous_records"] = str(previous)
    report["decision"] = "PASS_MATCHED_TOKENS" if previous else "PASS_WARM_ONLY"
    if not report["warm_repeat"]["tokens_exact"] or (previous and not report["cold_repeat"]["tokens_exact"]):
        report["decision"] = "FAIL_CORRECTNESS"
    write_json(records / "matched-repeatability.json", report)
    if report["decision"] == "FAIL_CORRECTNESS":
        raise CorrectnessFailure("raw output IDs differ under matched prefix conditions")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--case", choices=["small-code", "retained-retrieval", "near-full-code", "near-full-chat-code"], required=True)
    parser.add_argument("--compare-with", type=Path)
    parser.add_argument("--worker-output", type=Path)
    args = parser.parse_args()
    cfg = Manifest.read(args.manifest)
    root = cfg.experiment / ".mtp-exp"
    case = next(x for x in json.loads((root / "corpus/manifest.json").read_text())["cases"] if x["name"] == args.case)
    if args.worker_output:
        assert args.worker_output.resolve().is_relative_to(root / "probes")
        run_worker(cfg, case, args.worker_output)
        return
    if args.compare_with:
        args.compare_with = args.compare_with.resolve()
        assert args.compare_with.is_relative_to(root / "probes")
    evidence = Evidence(cfg)
    evidence.source_identity()
    env = evidence.env(cfg.baseline, cfg.target_uuid)
    processes = evidence.command(["ps", "-eo", "pid,args"], name="preflight-processes")
    if any(marker in processes for marker in ("freetoken.cli serve", "ft serve", "llama-server", "--worker-output", "--multiprocessing-fork")):
        raise RuntimeError("another model worker is active; leave it untouched")
    print(f"reference evidence: {evidence.run_dir}", flush=True)
    evidence.status("IN_PROGRESS", next_action="Complete matched short/near-full baseline repeatability")
    argv = [str(cfg.baseline_python), "-B", __file__, "--manifest", str(args.manifest),
            "--case", args.case, "--worker-output", str(evidence.run_dir)]
    try:
        with (evidence.run_dir / "worker.log").open("wb") as log:
            child = subprocess.Popen(argv, cwd=cfg.experiment, env=env, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            record = {"run_id": evidence.run_id, "argv": argv, "pid": child.pid, "pgid": child.pid,
                      "stdout_stderr": str(evidence.run_dir / "worker.log")}
            write_json(evidence.run_dir / "owned-process.json", record)
            evidence.commands.append(record)
            with (root / "commands.jsonl").open("a") as handle:
                handle.write(json.dumps(record) + "\n")
            try:
                result = child.wait(timeout=1800)
                if result:
                    raise RuntimeError(f"reference worker exited {result}; inspect worker.log")
            finally:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait(timeout=10)
                write_json(evidence.run_dir / "process-exit.json", {"pid": child.pid, "returncode": child.returncode})
        report = compare_records(evidence.run_dir, args.compare_with)
        evidence.status("IN_PROGRESS", measured=report, next_action="Audit G0 evidence; this subcommand alone does not pass G0")
        print(json.dumps(report), flush=True)
    except Exception as exc:
        (evidence.run_dir / "failure.txt").write_text(traceback.format_exc())
        evidence.status("FAIL_CORRECTNESS" if isinstance(exc, CorrectnessFailure) else "BLOCKED_ENVIRONMENT",
                        failures=[str(exc)], next_action="Diagnose the matched-condition failure before dependent work")
        raise
    finally:
        evidence.source_identity()


if __name__ == "__main__":
    main()
