#!/usr/bin/env python3
"""Bounded G0 prefix diagnosis through the protected scheduler and real weights.

The default mode replaces offline I/O and adds observation. Model math,
cache, overlap scheduling and graphs use the protected source unchanged.
Explicit numerics variants affect only the disposable diagnostic process.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, replace
import json
from pathlib import Path
import sys
import traceback

from qwen38_mtp_probe import Evidence, Manifest, write_json


class ProbeFinished(Exception):
    pass


def worker(cfg: Manifest, output: Path, disable_bf16_reduction=False):
    import torch
    import freetoken
    from freetoken.core import SamplingParams
    from freetoken.gpu_select import set_assigned_gpu
    from freetoken.message import DetokenizeMsg, ErrorReplyMsg, PromptAdmittedMsg, UserMsg
    from freetoken.scheduler import Scheduler
    from freetoken.server.args import parse_args
    from freetoken.models.qwen4_exp import gdn as gdn_module

    assert Path(freetoken.__file__).resolve() == cfg.baseline / "python/freetoken/__init__.py"
    set_assigned_gpu(cfg.target_uuid)
    if disable_bf16_reduction:
        torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
    args, _ = parse_args(cfg.baseline_argv[5:])
    args = replace(args, offline_mode=True)
    ids = json.loads((cfg.experiment / ".mtp-exp/corpus/small-code.json").read_text())
    assert len(ids) == 66 and len(ids) + 128 <= 4096

    class DiagnosticScheduler(Scheduler):
        def __init__(self, config):
            self.next_uid = 0
            self.tokens = {uid: [] for uid in range(3)}
            self.finished = set()
            self.admitted = []
            self.current_batch = None
            self.logits_trace = {uid: [] for uid in range(3)}
            self.tensors = {}
            super().__init__(config)

        def offline_receive_msg(self, blocking=False):
            # Wait for the preceding overlapped forward to drain before reuse.
            if not blocking:
                return []
            if self.next_uid == 3:
                raise ProbeFinished
            uid = self.next_uid
            self.next_uid += 1
            return [UserMsg(uid=uid, input_ids=torch.tensor(ids, dtype=torch.int32),
                            sampling_params=SamplingParams(temperature=0, top_k=1, top_p=1,
                                                           ignore_eos=False, max_tokens=128))]

        def offline_send_result(self, replies):
            for reply in replies:
                if isinstance(reply, ErrorReplyMsg):
                    raise RuntimeError(reply.error)
                if isinstance(reply, PromptAdmittedMsg):
                    self.admitted.append(asdict(reply))
                if isinstance(reply, DetokenizeMsg):
                    self.tokens[reply.uid].append(reply.next_token)
                    if reply.finished:
                        self.finished.add(reply.uid)
                        print(f"request {reply.uid}: {len(self.tokens[reply.uid])} raw output IDs", flush=True)

        def _forward(self, forward_input):
            self.current_batch = forward_input.batch
            return super()._forward(forward_input)

        def observe(self, name, tensor, tail=True):
            batch = self.current_batch
            if batch is not None and batch.is_prefill:
                uid = batch.reqs[0].uid
                self.tensors[f"{uid}/{name}"] = (tensor[-2:] if tail else tensor).detach().cpu().clone()

    scheduler = None
    with torch.inference_mode():
        try:
            scheduler = DiagnosticScheduler(args)
            assert scheduler.engine.cpu_moe_executor is None
            assert scheduler.engine.config.moe_backend == "offload"
            write_json(output / "resolved-runtime.json", {
                "config": json.loads(json.dumps(asdict(scheduler.engine.config), default=str)),
                "cpu_moe_executor": None, "freetoken_path": freetoken.__file__,
                "gpu_uuid": "GPU-" + str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-"),
                "bf16_reduced_precision_reduction": torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
                "modified_numerics_diagnostic": disable_bf16_reduction,
                "diagnostic_only": True, "timing_valid_for_performance": False})

            sample_original = scheduler.engine.sampler.sample
            def sample(logits, sampling_args):
                uid = scheduler.current_batch.reqs[0].uid
                if len(scheduler.logits_trace[uid]) < 129:
                    scheduler.logits_trace[uid].append(logits[0].detach().cpu().clone())
                return sample_original(logits, sampling_args)
            scheduler.engine.sampler.sample = sample

            # These wrappers run for eager prefill. Captured decode graphs remain intact.
            for index, layer in enumerate(scheduler.engine.model.model.layers.op_list):
                original = layer.forward
                def observe_layer(hidden, batch, original=original, index=index):
                    scheduler.observe(f"layer-{index:02}-input", hidden)
                    result = original(hidden, batch)
                    scheduler.observe(f"layer-{index:02}-output", result)
                    return result
                layer.forward = observe_layer
            first_gdn = scheduler.engine.model.model.layers.op_list[0].linear_attn
            proj_original = first_gdn.in_proj.forward
            def project(hidden):
                scheduler.observe("gdn0-projection-input", hidden, tail=False)
                result = proj_original(hidden)
                scheduler.observe("gdn0-projection", result)
                return result
            first_gdn.in_proj.forward = project
            conv_original = first_gdn._conv_prefill
            def convolve(*values):
                result = conv_original(*values)
                scheduler.observe("gdn0-convolved", result)
                return result
            first_gdn._conv_prefill = convolve
            gdn_original = first_gdn.forward
            active = False
            def first_forward(hidden):
                nonlocal active
                active = True
                try:
                    return gdn_original(hidden)
                finally:
                    active = False
            first_gdn.forward = first_forward
            chunk_original = gdn_module.gdn_prefill_chunk_fla
            def chunk(q, k, v, g, beta, **kwargs):
                if active:
                    for key, value in zip(("q", "k", "v", "g", "beta"), (q, k, v, g, beta)):
                        scheduler.observe(f"gdn0-{key}", value, tail=False)
                    index = int(kwargs["indices"][0])
                    scheduler.observe("gdn0-initial-state", kwargs["state_source"][index], tail=False)
                result = chunk_original(q, k, v, g, beta, **kwargs)
                if active:
                    scheduler.observe("gdn0-final-state", kwargs["state_source"][index], tail=False)
                    out = result[0] if kwargs.get("return_h") else result
                    scheduler.observe("gdn0-core-output", out)
                    if kwargs.get("return_h"):
                        scheduler.observe("gdn0-track64", result[1][0, 1], tail=False)
                return result
            gdn_module.gdn_prefill_chunk_fla = chunk

            try:
                scheduler.run_forever()
            except ProbeFinished:
                pass
            torch.cuda.synchronize()
            torch.save(scheduler.tensors, output / "prefill-tensors.pt")
            torch.save({uid: torch.stack(rows) for uid, rows in scheduler.logits_trace.items()}, output / "logits.pt")
            write_json(output / "tokens.json", scheduler.tokens)
            write_json(output / "admitted.json", scheduler.admitted)
            analyze(scheduler.tokens, scheduler.logits_trace, scheduler.tensors, output)
            recurrence_probe(scheduler.tensors, chunk_original, output)
            projection_probe(scheduler.tensors, first_gdn.in_proj, output)
        finally:
            if scheduler is not None:
                scheduler.shutdown()


def tensor_error(a, b):
    import torch
    a, b = a.float(), b.float()
    error = a - b
    return {"exact": torch.equal(a, b), "max_abs": error.abs().max().item(),
            "rms": error.square().mean().sqrt().item(),
            "relative_rms": (error.square().mean().sqrt() / a.square().mean().sqrt().clamp_min(1e-30)).item(),
            "finite": bool(torch.isfinite(a).all() and torch.isfinite(b).all())}


def analyze(tokens, logits, tensors, output):
    import torch

    first = next((i for i, (a, b) in enumerate(zip(tokens[0], tokens[1])) if a != b), None)
    differences = {}
    for name in sorted(k[2:] for k in tensors if k.startswith("0/")):
        a, b = tensors[f"0/{name}"], tensors.get(f"1/{name}")
        if b is not None and a.shape == b.shape:
            differences[name] = tensor_error(a, b)
    common = []
    for i in range((first + 1) if first is not None else min(len(logits[0]), len(logits[1]))):
        a, b = logits[0][i], logits[1][i]
        va, ia = a.topk(4); vb, ib = b.topk(4)
        common.append({"row": i, "errors": tensor_error(a, b),
                       "first_top_ids": ia.tolist(), "first_top_values": va.tolist(),
                       "second_top_ids": ib.tolist(), "second_top_values": vb.tolist()})
    report = {"tokens_exact": tokens[0] == tokens[1],
              "output_lengths": {uid: len(rows) for uid, rows in tokens.items()},
              "first_differing_output_row": first,
              "first_token": tokens[0][first] if first is not None else None,
              "second_token": tokens[1][first] if first is not None else None,
              "prefill_tail_comparisons": differences, "logits_through_first_difference": common}
    if 2 in tokens:
        report["warm_repeat"] = {
            "tokens_exact": tokens[1] == tokens[2],
            "logits": tensor_error(torch.stack(logits[1]), torch.stack(logits[2])),
            "prefill_tensors": {
                name[2:]: tensor_error(value, tensors[f"2/{name[2:]}"])
                for name, value in tensors.items() if name.startswith("1/")}}
    write_json(output / "analysis.json", report)
    print(json.dumps({"first_differing_output_row": first, "prefill_layer0": differences.get("layer-00-output")}), flush=True)


def recurrence_probe(tensors, chunk, output):
    import torch
    values = [tensors[f"0/gdn0-{key}"].cuda() for key in ("q", "k", "v", "g", "beta")]
    state_shape = tensors["0/gdn0-final-state"].shape
    state = torch.zeros((1, *state_shape), device="cuda", dtype=torch.float32)
    indices = torch.zeros(1, device="cuda", dtype=torch.int32)
    def run(parts, return_h=False):
        return chunk(*parts, state_source=state, indices=indices,
                     cu_seqlens=torch.tensor([0, parts[0].shape[1]], device="cuda", dtype=torch.int64),
                     scale=values[0].shape[-1] ** -0.5, return_h=return_h)
    full_out, h = run(values, True)
    full_state = state.clone()
    state.zero_()
    run([value[:, :64] for value in values])
    exact64 = state.clone()
    split_out = run([value[:, 64:] for value in values])
    split_state = state.clone()
    state.copy_(h[:, 1].float())
    rounded_out = run([value[:, 64:] for value in values])
    report = {"chunk_h_dtype": str(h.dtype), "live_state_dtype": str(state.dtype),
              "snapshot_vs_restored_state": tensor_error(tensors["0/gdn0-track64"],
                                                         tensors["1/gdn0-initial-state"]),
              "boundary64_snapshot_vs_fp32_final": tensor_error(h[:, 1], exact64),
              "full_vs_split_fp32_tail_output": tensor_error(full_out[-2:], split_out),
              "full_vs_split_fp32_final_state": tensor_error(full_state, split_state),
              "full_vs_split_rounded_tail_output": tensor_error(full_out[-2:], rounded_out),
              "full_vs_split_rounded_final_state": tensor_error(full_state, state)}
    write_json(output / "recurrence-probe.json", report)
    print(json.dumps(report), flush=True)


def projection_probe(tensors, projection, output):
    import torch
    from torch.nn.functional import linear

    cold = tensors["0/gdn0-projection-input"].cuda()
    warm = tensors["1/gdn0-projection-input"].cuda()
    full = projection.forward(cold)
    tail = projection.forward(cold[-2:])
    # The same BF16 weights/inputs, with FP32 accumulation/output as a reference.
    # This runs only after all serving observations have completed.
    previous_tf32 = torch.backends.cuda.matmul.allow_tf32
    try:
        torch.backends.cuda.matmul.allow_tf32 = False
        reference = linear(cold[-2:].float(), projection.weight.float())
    finally:
        torch.backends.cuda.matmul.allow_tf32 = previous_tf32
    report = {
        "input_tail_cold_vs_warm": tensor_error(cold[-2:], warm),
        "same_input_66_rows_vs_2_rows": tensor_error(full[-2:], tail),
        "full_vs_captured_cold": tensor_error(full[-2:].cpu(), tensors["0/gdn0-projection"]),
        "tail_vs_captured_warm": tensor_error(tail.cpu(), tensors["1/gdn0-projection"]),
        "full_vs_fp32_reference": tensor_error(reference, full[-2:]),
        "tail_vs_fp32_reference": tensor_error(reference, tail),
        "full_vs_rounded_fp32_reference": tensor_error(reference.bfloat16(), full[-2:]),
        "tail_vs_rounded_fp32_reference": tensor_error(reference.bfloat16(), tail),
        "timing_valid_for_performance": False}
    write_json(output / "projection-probe.json", report)
    print(json.dumps(report), flush=True)


def hc_replay(cfg, records, output):
    """Replay just layer zero's mixer with real weights and 66 embedding rows."""
    from types import SimpleNamespace
    import hashlib
    import torch
    from torch.nn.functional import linear
    from safetensors import safe_open
    from transformers import AutoTokenizer
    import freetoken
    from freetoken.models.qwen4_exp.hc import GatedResidual
    from freetoken.kernel.triton.hc import grouped_gemma_rmsnorm, hc_silu, hc_gate_mix

    assert Path(freetoken.__file__).resolve() == cfg.baseline / "python/freetoken/__init__.py"
    uuid = "GPU-" + str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-")
    assert uuid == cfg.target_uuid
    index = json.loads((cfg.model / "model.safetensors.index.json").read_text())["weight_map"]
    config = json.loads((cfg.model / "config.json").read_text())["text_config"]
    count, hidden, rank = (config[key] for key in ("hc_count", "hidden_size", "hc_lowrank"))
    loaded = []

    def read(key):
        with safe_open(cfg.model / index[key], framework="pt", device="cpu") as handle:
            value = handle.get_tensor(key).cuda()
        loaded.append({"key": key, "shape": list(value.shape), "dtype": str(value.dtype)})
        return value

    hc = GatedResidual(SimpleNamespace(
        qwen4_args=SimpleNamespace(hc_count=count, hidden_size=hidden,
                                  hc_lowrank=rank, ple_state_width=count * hidden),
        rms_norm_eps=config["rms_norm_eps"]))
    prefix = "model.language_model.layers.0.attn_hyper_connection."
    hc.hc_norm.weight = read(prefix + "hc_norm.weight")
    hc.input_mix_weight_down_block_inject.weight = torch.cat([
        read(prefix + "input_mix_weight_down.weight"),
        read(prefix + "block_inject_weight.weight"),
        torch.zeros(hc.pad_size, count * hidden, dtype=torch.bfloat16, device="cuda")])
    hc.input_mix_weight_up.weight = read(prefix + "input_mix_weight_up.weight")
    ids = json.loads((cfg.experiment / ".mtp-exp/corpus/small-code.json").read_text())
    assert len(ids) == 66
    key = "model.language_model.embed_tokens.weight"
    with safe_open(cfg.model / index[key], framework="pt", device="cpu") as handle:
        rows = handle.get_slice(key)
        inputs = torch.cat([rows[token:token + 1] for token in ids]).cuda().repeat(1, count)
    tensors = torch.load(records / "prefill-tensors.pt", map_location="cpu", weights_only=True)
    assert torch.equal(inputs[-2:].cpu(), tensors["0/layer-00-input"])

    def chain(x, fp32=False):
        rn = grouped_gemma_rmsnorm(x, hc.hc_norm.weight, hc.hc_norm.eps, count)
        if fp32:
            merged = linear(rn.float(), hc.input_mix_weight_down_block_inject.weight.float()).bfloat16()
            down, inject = merged[:, :rank], merged[:, rank:rank + count]
        else:
            down, inject = hc._down(rn)
        activated = hc_silu(down, count)
        gate = (linear(activated.float(), hc.input_mix_weight_up.weight.float()).bfloat16()
                if fp32 else hc.input_mix_weight_up.forward(activated))
        mixed = hc_gate_mix(rn, gate, count)
        return dict(norm=rn, down=down, inject=inject, activated=activated, gate=gate, mixed=mixed)

    original_reduce = torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction
    original_tf32 = torch.backends.cuda.matmul.allow_tf32
    report = {"gpu_uuid": uuid, "loaded_weights": loaded, "embedding_rows": len(ids),
              "baseline_bf16_reduced_precision_reduction": original_reduce,
              "baseline_tf32": original_tf32, "timing_valid_for_performance": False,
              "variants_are_component_diagnostics_only": True, "variants": {}}
    try:
        with torch.inference_mode():
            for mode in ("baseline", "no_bf16_reduced_reduction", "fp32_gemms"):
                torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = (
                    original_reduce if mode == "baseline" else False)
                torch.backends.cuda.matmul.allow_tf32 = original_tf32 if mode == "baseline" else False
                full, tail = chain(inputs, mode == "fp32_gemms"), chain(inputs[-2:], mode == "fp32_gemms")
                comparison = {key: tensor_error(value[-2:], tail[key]) for key, value in full.items()}
                comparison["vs_captured_cold_mixed"] = tensor_error(full["mixed"].cpu(), tensors["0/gdn0-projection-input"])
                comparison["vs_captured_warm_mixed"] = tensor_error(tail["mixed"].cpu(), tensors["1/gdn0-projection-input"])
                if mode == "baseline":
                    assert comparison["vs_captured_cold_mixed"]["exact"]
                    assert comparison["vs_captured_warm_mixed"]["exact"]
                    assert torch.equal(full["mixed"], hc.mix(inputs)[0])
                report["variants"][mode] = comparison
    finally:
        torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = original_reduce
        torch.backends.cuda.matmul.allow_tf32 = original_tf32

    tokenizer = AutoTokenizer.from_pretrained(cfg.model, local_files_only=True)
    tokens = json.loads((records / "tokens.json").read_text())
    report["decoded_output_sha256"] = {
        uid: hashlib.sha256(tokenizer.decode(values).encode()).hexdigest() for uid, values in tokens.items()}
    report["first_different_token_text"] = {str(t): tokenizer.decode([t]) for t in (6088, 83876)}
    write_json(output / "hc-replay.json", report)
    print(json.dumps(report), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--worker-output", type=Path)
    parser.add_argument("--hc-replay", type=Path, help="completed diagnostic records; load only the first mixer")
    parser.add_argument("--disable-bf16-reduction", action="store_true",
                        help="diagnostic numerics variant; never an unchanged baseline run")
    args = parser.parse_args()
    cfg = Manifest.read(args.manifest)
    if args.hc_replay:
        args.hc_replay = args.hc_replay.resolve()
        if not args.hc_replay.is_relative_to(cfg.experiment / ".mtp-exp/probes"):
            parser.error("replay records must be experiment evidence")
    if args.worker_output:
        if not args.worker_output.resolve().is_relative_to(cfg.experiment / ".mtp-exp"):
            parser.error("worker output must stay in experiment evidence")
        if args.hc_replay:
            hc_replay(cfg, args.hc_replay, args.worker_output)
        else:
            worker(cfg, args.worker_output, args.disable_bf16_reduction)
        return
    evidence = Evidence(cfg)
    evidence.source_identity()
    processes = evidence.command(["ps", "-eo", "pid,args"])
    if (any(x in processes for x in ("freetoken.cli serve", "ft serve", "llama-server", "--multiprocessing-fork"))
            or any("qwen38_mtp_diagnose.py" in line and "--worker-output" in line
                   for line in processes.splitlines())):
        raise RuntimeError("another model process is active")
    env = evidence.env(cfg.baseline, cfg.target_uuid)
    print(f"diagnostic evidence: {evidence.run_dir}", flush=True)
    try:
        argv = [cfg.baseline_python, "-B", __file__, "--manifest", args.manifest,
                "--worker-output", evidence.run_dir]
        if args.hc_replay:
            argv.extend(["--hc-replay", args.hc_replay])
        if args.disable_bf16_reduction:
            argv.append("--disable-bf16-reduction")
        evidence.command(argv, env=env, timeout=600, name="diagnostic")
    except Exception:
        (evidence.run_dir / "failure.txt").write_text(traceback.format_exc())
        raise
    finally:
        evidence.source_identity()
    print(f"diagnostic complete: {evidence.run_dir}", flush=True)


if __name__ == "__main__":
    main()
