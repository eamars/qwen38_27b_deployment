#!/usr/bin/env python3
"""Local, gate-ordered Qwen3.8 MTP experiments (plan 2.1).

Inventory reads checkpoint headers only. Unimplemented gates fail explicitly.
All evidence and subprocess caches stay inside the experiment checkout.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import datetime as dt
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import socket
import struct
import subprocess
import sys
import time
import traceback
import urllib.error
import urllib.request

EXPECTED_SHA = "af71ba43206e124f5ff6419b47ee36c6e9981078"
EXPECTED_BRANCH = "exp/qwen38-mtp-4090"


class CorrectnessFailure(RuntimeError):
    pass


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


@dataclass(frozen=True)
class Manifest:
    project: Path
    baseline: Path
    experiment: Path
    model: Path
    baseline_python: Path
    target_uuid: str
    draft_uuid: str
    baseline_argv: list[str]

    @classmethod
    def read(cls, path: Path):
        data = json.loads(path.read_text())
        if data.get("plan_version") != "2.1":
            raise ValueError("expected plan_version 2.1")
        if data.get("full_context_feature_stream_authorized") is not False:
            raise ValueError("full-context feature export is not authorized")
        obj = cls(**{key: Path(data[key]).absolute() if key in {
            "project", "baseline", "experiment", "model", "baseline_python"
        } else data[key] for key in cls.__dataclass_fields__})
        if obj.experiment.resolve() != Path(__file__).resolve().parents[1]:
            raise ValueError("runner must be in the declared experiment")
        if obj.experiment != obj.experiment.resolve():
            raise ValueError("experiment path must be canonical")
        if obj.baseline == obj.experiment or not obj.model.is_dir():
            raise ValueError("invalid baseline or missing local checkpoint")
        if obj.target_uuid == obj.draft_uuid:
            raise ValueError("GPU UUIDs must be distinct")
        if not all(isinstance(x, str) for x in obj.baseline_argv):
            raise ValueError("baseline_argv must be an argument array")
        if obj.baseline_argv[:5] != [str(obj.baseline_python), "-B", "-m", "freetoken.cli", "serve"]:
            raise ValueError("baseline argv must invoke the discovered FreeToken CLI")
        for folder in (".mtp-exp", ".mtp-exp/caches", ".mtp-exp/probes", ".mtp-exp/corpus"):
            if not (obj.experiment / folder).resolve().is_relative_to(obj.experiment):
                raise ValueError(f"evidence path escapes experiment: {folder}")
        return obj


class Evidence:
    def __init__(self, config: Manifest):
        self.config = config
        self.root = config.experiment / ".mtp-exp"
        self.run_id = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        self.run_dir = self.root / "probes" / self.run_id
        self.run_dir.mkdir(parents=True)
        self.commands = []
        self.source = None

    def command(self, argv, *, env=None, timeout=60, check=True, name=None):
        index = len(self.commands)
        stem = self.run_dir / (name or f"command-{index:03}")
        start = time.monotonic()
        result = subprocess.run([str(x) for x in argv], cwd=self.config.experiment,
                                env=env, capture_output=True, timeout=timeout)
        stem.with_suffix(".stdout").write_bytes(result.stdout)
        stem.with_suffix(".stderr").write_bytes(result.stderr)
        row = {"run_id": self.run_id, "argv": [str(x) for x in argv],
               "cwd": str(self.config.experiment), "returncode": result.returncode,
               "wall_seconds": time.monotonic() - start,
               "stdout": str(stem.with_suffix(".stdout")),
               "stderr": str(stem.with_suffix(".stderr"))}
        self.commands.append(row)
        with (self.root / "commands.jsonl").open("a") as handle:
            handle.write(json.dumps(row) + "\n")
        if check and result.returncode:
            raise RuntimeError(f"command failed ({result.returncode}): {argv}; see {stem}")
        return result.stdout.decode(errors="replace").strip()

    def git(self, path, *args):
        return self.command(["git", "--no-optional-locks", "-c", "core.autocrlf=true",
                             "-c", "core.filemode=false", "-C", path, *args])

    def source_identity(self):
        cfg = self.config
        identities = {}
        for label, path in (("baseline", cfg.baseline), ("experiment", cfg.experiment)):
            sha = self.git(path, "rev-parse", "HEAD")
            if sha != EXPECTED_SHA:
                raise ValueError(f"{label} SHA mismatch: {sha}")
            patch = self.git(path, "diff", "HEAD", "--binary")
            untracked = self.git(path, "ls-files", "--others", "--exclude-standard").splitlines()
            sources = {p: digest((path / p).read_bytes()) for p in untracked
                       if not p.startswith(".mtp-exp/") and (path / p).is_file()}
            snapshot = self.run_dir / ("source-final" if self.source else "source-initial") / label
            for relative in sources:
                destination = snapshot / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes((path / relative).read_bytes())
            if label == "baseline" and (patch or sources):
                raise ValueError("protected baseline has pre-existing changes")
            identities[label] = {"path": str(path), "sha": sha,
                                 "diff_sha256": digest(patch.encode()),
                                 "untracked_source_sha256": sources}
            (self.run_dir / f"{label}.patch").write_text(patch)
        branch = self.git(cfg.experiment, "branch", "--show-current")
        if branch != EXPECTED_BRANCH:
            raise ValueError(f"unexpected experiment branch: {branch}")
        identities["experiment"]["branch"] = branch
        name = "source-identity-final.json" if self.source else "source-identity.json"
        write_json(self.run_dir / name, identities)
        self.source = identities
        return identities

    def env(self, source: Path, gpu: str | None):
        cfg = self.config
        env = os.environ.copy()
        cache = self.root / "caches"
        env.update({"PYTHONPATH": str(source / "python"), "PYTHONDONTWRITEBYTECODE": "1",
                    "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                    "HF_DATASETS_OFFLINE": "1", "CUDA_HOME": "/usr/local/cuda-13.3",
                    "TVM_FFI_CUDA_ARCH_LIST": "12.0" if gpu == cfg.target_uuid else "8.9",
                    "PATH": f"{cfg.baseline_python.parent}:/usr/local/cuda-13.3/bin:" + env["PATH"],
                    "LD_LIBRARY_PATH": "/usr/local/cuda-13.3/targets/x86_64-linux/lib:" + env.get("LD_LIBRARY_PATH", "")})
        for key, folder in {"XDG_CACHE_HOME": "xdg", "TRITON_CACHE_DIR": "triton",
                            "TORCH_EXTENSIONS_DIR": "torch_extensions", "CUDA_CACHE_PATH": "cuda",
                            "HF_HOME": "huggingface", "FLASHINFER_WORKSPACE_BASE": "flashinfer",
                            "TVM_FFI_CACHE_DIR": "tvm_ffi", "TMPDIR": "tmp"}.items():
            directory = cache / folder
            directory.mkdir(parents=True, exist_ok=True)
            env[key] = str(directory)
        if gpu is not None:
            env["CUDA_VISIBLE_DEVICES"] = gpu
        else:
            env.pop("CUDA_VISIBLE_DEVICES", None)
        write_json(self.run_dir / "environment-overrides.json",
                   {key: value for key, value in env.items() if os.environ.get(key) != value})
        return env

    def status(self, decision, *, failures=(), measured=None, source=None, next_action="Complete G0 baseline repeatability"):
        value = {"plan_version": "2.1", "stage": "G0", "decision": decision,
                 "run_id": self.run_id, "source_identity": source or self.source,
                 "changed_files": ["benchmarks/qwen38_mtp_probe.py", ".mtp-exp/"],
                 "commands": self.commands, "evidence_paths": [str(self.run_dir)],
                 "measured": measured or {}, "failures": list(failures),
                 "correctness_comparison": "Baseline repeatability failure; see repeatability.json" if decision == "FAIL_CORRECTNESS" else "NOT_RUN",
                 "full_context_feature_stream_authorized": False,
                 "full_context_initialization_status": "BLOCKED_REQUIREMENT",
                 "short_context_feature_probe_max_rows": 4096,
                 "unverified_assumptions": ["Full target load/generation and near-full-context repeatability", "MTP alignment and performance"],
                 "next_authorized_action": next_action}
        write_json(self.run_dir / "status.json", value)
        write_json(self.root / "status.json", value)


def checkpoint_inventory(model: Path):
    index_path = model / "model.safetensors.index.json"
    index = json.loads(index_path.read_text())
    tensors = {}
    shards = {}
    # The baseline PLE reader also discovers unindexed model-plefp8 shards.
    files = sorted(set(index["weight_map"].values()) | {p.name for p in model.glob("*.safetensors")})
    for name in files:
        path = (model / name).resolve(strict=True)
        if not path.is_relative_to(model.resolve()):
            raise ValueError(f"shard escapes model directory: {name}")
        with path.open("rb") as handle:
            header_size = struct.unpack("<Q", handle.read(8))[0]
            if header_size > 64 * 1024 * 1024:
                raise ValueError(f"unbounded safetensors header: {name}")
            raw = handle.read(header_size)
            header = json.loads(raw)
        shards[name] = {"file_bytes": path.stat().st_size, "mtime_ns": path.stat().st_mtime_ns,
                        "header_sha256": digest(raw), "header_bytes": header_size}
        for key, item in header.items():
            if key == "__metadata__":
                continue
            begin, end = item["data_offsets"]
            if not 0 <= begin <= end <= path.stat().st_size - 8 - header_size:
                raise ValueError(f"invalid tensor offsets: {key}")
            if key in tensors:
                raise ValueError(f"duplicate tensor key: {key}")
            tensors[key] = {"shape": item["shape"], "dtype": item["dtype"],
                            "storage_bytes": end - begin, "shard": name,
                            "file_offset": 8 + header_size + begin,
                            "indexed": key in index["weight_map"]}
    for key, shard in index["weight_map"].items():
        if key not in tensors or tensors[key]["shard"] != shard:
            raise ValueError(f"index/header mismatch: {key}")
    allowlist = {key: value for key, value in tensors.items()
                 if key.startswith(("mtp.", "lm_head.", "model.embed_tokens.", "model.language_model.embed_tokens."))}
    config = json.loads((model / "config.json").read_text())
    metadata = {p.name: digest(p.read_bytes()) for p in model.iterdir()
                if p.is_file() and p.suffix in {".json", ".jinja", ".txt"}}
    return {"evidence": "LOCAL_MEASURED", "method": "headers only; no tensor data loaded",
            "model": str(model), "config": config, "metadata_sha256": metadata,
            "shards": shards, "tensor_count": len(tensors), "tensors": tensors,
            "draft_allowlist": allowlist,
            "draft_allowlist_storage_bytes": sum(t["storage_bytes"] for t in allowlist.values()),
            "mtp_storage_bytes": sum(t["storage_bytes"] for k, t in allowlist.items() if k.startswith("mtp.")),
            "alias_policy": "No materialized aliases assumed; config tie_word_embeddings recorded",
            "quantization_policy": "Raw checkpoint representations only; allocation requires G2"}


def runtime_inventory():
    import freetoken
    import torch
    result = {"python": sys.executable, "python_version": sys.version,
              "freetoken_path": freetoken.__file__, "torch_path": torch.__file__,
              "dependencies": {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()},
              "cuda_runtime": torch.version.cuda, "devices": []}
    for i in range(torch.cuda.device_count()):
        p = torch.cuda.get_device_properties(i)
        result["devices"].append({"index": i, "name": p.name, "uuid": "GPU-" + str(p.uuid).removeprefix("GPU-"),
                                  "total_memory": p.total_memory, "capability": [p.major, p.minor]})
    result["peer_access"] = {f"{i}->{j}": torch.cuda.can_device_access_peer(i, j)
                              for i in range(torch.cuda.device_count())
                              for j in range(torch.cuda.device_count()) if i != j}
    # Bounded real pinning probe; it does not establish expert-bank-scale capacity.
    pinned = torch.empty(1024 * 1024, dtype=torch.uint8, pin_memory=True)
    result["pinned_allocation"] = {"bytes": pinned.numel(), "is_pinned": pinned.is_pinned()}
    print(json.dumps(result))


def inventory(evidence: Evidence):
    cfg = evidence.config
    source = evidence.source_identity()
    metadata = checkpoint_inventory(cfg.model)
    write_json(evidence.root / "checkpoint-map.json", metadata)
    for name, argv in {
        "nvidia-smi": ["nvidia-smi", "-q", "-x"],
        "topology": ["nvidia-smi", "topo", "-m"],
        "p2p-read": ["nvidia-smi", "topo", "-p2p", "r"],
        "p2p-write": ["nvidia-smi", "topo", "-p2p", "w"],
        "memory": ["cat", "/proc/meminfo"], "swap": ["cat", "/proc/swaps"],
        "cpu": ["lscpu"], "processes": ["ps", "-eo", "pid,ppid,args"],
    }.items():
        evidence.command(argv, name=name, check=False)
    env = evidence.env(cfg.baseline, None)
    raw = evidence.command([cfg.baseline_python, "-B", __file__, "_runtime_inventory"],
                           env=env, timeout=120, name="runtime-inventory")
    runtime = json.loads(raw)
    if Path(runtime["freetoken_path"]).resolve() != cfg.baseline / "python/freetoken/__init__.py":
        raise ValueError("baseline imports wrong freetoken")
    if {x["uuid"] for x in runtime["devices"]} != {cfg.target_uuid, cfg.draft_uuid}:
        raise ValueError("installed CUDA GPU identity mismatch")
    discovery = {"source": source, "runtime": runtime, "paths": {k: str(v) for k, v in vars(cfg).items() if isinstance(v, Path)},
                 "baseline_argv": cfg.baseline_argv, "checkpoint_metadata_sha256": metadata["metadata_sha256"]}
    write_json(evidence.root / "discovery.json", discovery)
    hardware = {"reported": {"cpu": "9950X3D", "dimms": "2 x 64 GiB DDR5-6000", "board": "B850 AI TOP rev. 1.0"},
                "derived_estimates": {"ddr5_channel_GB_s": 96, "5090_Gen5_x8_GB_s_per_direction": 32e9*8*128/130/8/1e9,
                                      "4090_Gen4_x8_GB_s_per_direction": 16e9*8*128/130/8/1e9},
                "local_measured": runtime, "host_inventory": str(evidence.root / "host-inventory.json"),
                "raw_telemetry_directory": str(evidence.run_dir),
                "loaded_links": None, "loaded_links_reason": "NOT_RUN: no active transfer workload yet",
                "physical_dram_traffic": None, "physical_dram_traffic_reason": "No hardware DRAM counter collected"}
    write_json(evidence.root / "hardware.json", hardware)
    write_json(evidence.root / "memory-budget.json", {
        "mtp_checkpoint_bytes": metadata["mtp_storage_bytes"],
        "draft_allowlist_checkpoint_bytes": metadata["draft_allowlist_storage_bytes"],
        "runtime_peaks": None, "runtime_peaks_reason": "NOT_RUN: target/draft not constructed",
        "source_reported_target_host_experts_GiB": 63.46,
        "source_reported_target_PLE_disk_GiB": 47.7,
        "decode_slot_capacity_bytes": 102400, "slots_per_process": 2,
        "full_context_feature_stream_authorized": False})
    evidence.status("IN_PROGRESS", source=source, measured={"tensor_count": metadata["tensor_count"],
                    "mtp_bytes": metadata["mtp_storage_bytes"], "pinning": runtime["pinned_allocation"]})
    print(json.dumps({"inventory": "completed", "G0": "IN_PROGRESS", "run_id": evidence.run_id,
                      "tensor_count": metadata["tensor_count"], "mtp_bytes": metadata["mtp_storage_bytes"]}))


def prepare_baseline(config: Manifest):
    import freetoken
    import torch
    from freetoken.server.args import parse_args
    from freetoken.utils import load_tokenizer
    if Path(freetoken.__file__).resolve() != config.baseline / "python/freetoken/__init__.py":
        raise ValueError("wrong source imported for protected baseline")
    if torch.cuda.device_count() != 1:
        raise ValueError("baseline must expose exactly one GPU")
    device_uuid = "GPU-" + str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-")
    if device_uuid != config.target_uuid:
        raise ValueError("baseline cuda:0 is not the target UUID")
    args, _ = parse_args(config.baseline_argv[5:])
    if args.moe_backend != "offload" or str(args.moe_cpu_layers) != "0" or args.cache_type != "radix":
        raise ValueError("protected target policy changed")
    root = config.experiment / ".mtp-exp"
    write_json(root / "resolved-config.json", json.loads(json.dumps(asdict(args), default=str)))
    tokenizer = load_tokenizer(str(config.model))
    manifest_path = root / "corpus/manifest.json"
    if manifest_path.exists():
        frozen = json.loads(manifest_path.read_text())
        for case in frozen["cases"]:
            for field in ("input_ids", "prompt_text"):
                path = Path(case[field])
                if not path.resolve().is_relative_to(root / "corpus"):
                    raise ValueError(f"frozen corpus path escapes corpus directory: {path}")
                if digest(path.read_bytes()) != case[field + "_sha256"]:
                    raise ValueError(f"frozen corpus bytes changed: {path}")
            ids = json.loads(Path(case["input_ids"]).read_text())
            if len(ids) != case["prompt_tokens"] or tokenizer.encode(
                    Path(case["prompt_text"]).read_text(), add_special_tokens=True) != ids:
                raise ValueError(f"frozen corpus token identity changed: {case['name']}")
        print("baseline configuration and existing frozen corpus validated", flush=True)
        return
    retained = config.project / "benchmarks/qwen38_flash_next/2026-09-02/freetoken-4k-prompt.txt"
    text = retained.read_text()
    retained_ids = tokenizer.apply_chat_template([{"role": "user", "content": text}],
                                                  tokenize=True, add_generation_prompt=True, return_dict=False)
    small_ids = tokenizer.apply_chat_template([{"role": "user", "content": "Write a Python function that returns the factorial of a nonnegative integer."}],
                                               tokenize=True, add_generation_prompt=True, return_dict=False)
    # A reproducible local-source diagnostic. It is not the user's historical code benchmark.
    code_path = config.baseline / "python/freetoken/core.py"
    code_ids = tokenizer.encode(code_path.read_text(), add_special_tokens=False)
    suffix = tokenizer.encode("\nExplain how requests track cached tokens in this Python code.\n", add_special_tokens=False)
    prefix = tokenizer.encode("Python source for review:\n", add_special_tokens=False)
    remaining = 261120 - len(prefix) - len(suffix)
    full_ids = prefix + (code_ids * (remaining // len(code_ids) + 1))[:remaining] + suffix
    corpus = []
    for name, ids, count, provenance in [
        ("small-code", small_ids, 128, "SYNTHETIC_DEVELOPMENT"),
        ("retained-retrieval", retained_ids, 512, "RETAINED_PROMPT; radix cache enabled; natural EOS"),
        ("near-full-code", full_ids, 1024, "SYNTHETIC_LOCAL_SOURCE_DIAGNOSTIC; text with verified token round-trip; no chat template"),
    ]:
        prompt_text = tokenizer.decode(ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
        encoded = tokenizer.encode(prompt_text, add_special_tokens=True)
        if encoded != ids:
            raise ValueError(f"{name}: text transport does not round-trip frozen token IDs ({len(ids)} -> {len(encoded)})")
        path = root / "corpus" / f"{name}.json"
        write_json(path, ids)
        text_path = path.with_suffix(".txt")
        text_path.write_text(prompt_text)
        corpus.append({"name": name, "input_ids": str(path), "input_ids_sha256": digest(path.read_bytes()),
                       "prompt_text": str(text_path), "prompt_text_sha256": digest(text_path.read_bytes()),
                       "prompt_tokens": len(ids), "max_new_tokens": count, "sequence_capacity": 262144,
                       "position_interval": [0, len(ids) + count - 1], "provenance": provenance})
    write_json(root / "corpus/manifest.json", {"cases": corpus, "temperature": 0, "top_k": 1,
                "top_p": 1, "ignore_eos": False, "retained_prompt_sha256": digest(retained.read_bytes()),
                "synthetic_code_source_sha256": digest(code_path.read_bytes()),
                "primary_held_out_corpus": "NOT_RECOVERED; synthetic diagnostic cannot establish final acceptance"})
    print("baseline configuration and corpus prepared", flush=True)


def http_json(url, *, timeout=5):
    with urllib.request.urlopen(url, timeout=timeout) as response:
        return json.load(response)


def stream_completion(url: str, payload: dict, output: Path, timeout=1800):
    request = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"})
    start = time.monotonic()
    chunks, text, usage, reason = [], [], {}, None
    done = False
    try:
        response = urllib.request.urlopen(request, timeout=timeout)
    except urllib.error.HTTPError as exc:
        output.write_bytes(exc.read())
        raise RuntimeError(f"HTTP {exc.code}; response saved to {output}") from exc
    with output.open("w") as raw, response:
        for line in response:
            now = time.monotonic()
            if now - start > timeout:
                raise TimeoutError("request exceeded wall deadline")
            if not line.startswith(b"data: "):
                continue
            value = line[6:].strip()
            raw.write(json.dumps({"elapsed_seconds": now - start, "data": value.decode()}) + "\n")
            raw.flush()
            if value == b"[DONE]":
                done = True
                break
            event = json.loads(value)
            if "error" in event:
                raise RuntimeError(f"stream error: {event['error']}")
            if event.get("usage"):
                usage = event["usage"]
            for choice in event.get("choices", []):
                if choice.get("text"):
                    chunks.append(now - start)
                    text.append(choice["text"])
                if choice.get("finish_reason"):
                    reason = choice["finish_reason"]
    if not done or not chunks or not usage:
        raise RuntimeError("incomplete stream or missing output/usage")
    n = usage["completion_tokens"]
    return {"usage": usage, "finish_reason": reason, "text": "".join(text),
            "text_sha256": digest("".join(text).encode()), "ttft_seconds": chunks[0],
            "last_text_chunk_seconds": chunks[-1], "request_seconds": time.monotonic() - start,
            "decode_tps_text_chunk_proxy": (n - 1) / (chunks[-1] - chunks[0]) if n >= 2 and len(chunks) > 1 else None,
            "chunk_arrival_seconds": chunks, "output_token_ids": None,
            "output_token_ids_reason": "Baseline public endpoint does not expose raw generated IDs; text equality is a partial comparison"}


def compare_repeats(first: dict, second: dict):
    a, b = first["text"], second["text"]
    identical = a == b and first["usage"] == second["usage"] and first["finish_reason"] == second["finish_reason"]
    offset = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
    return {"decision": "PASS_TEXT_ONLY" if identical else "FAIL_CORRECTNESS",
            "first_differing_character": None if identical else offset,
            "first_excerpt": a[max(0, offset - 64):offset + 192] if not identical else None,
            "second_excerpt": b[max(0, offset - 64):offset + 192] if not identical else None,
            "first_text_sha256": digest(a.encode()), "second_text_sha256": digest(b.encode()),
            "raw_token_comparison": "NOT_RUN: endpoint does not expose generated token IDs"}


def baseline(evidence: Evidence, selected_case: str | None):
    cfg = evidence.config
    source = evidence.source_identity()
    evidence.status("IN_PROGRESS", source=source, next_action="Run protected-baseline generation; G1 remains gated")
    if not (evidence.root / "discovery.json").is_file():
        raise ValueError("inventory must complete before baseline")
    env = evidence.env(cfg.baseline, cfg.target_uuid)
    frozen_manifest = {key: str(value) if isinstance(value, Path) else value for key, value in asdict(cfg).items()}
    frozen_manifest.update(plan_version="2.1", full_context_feature_stream_authorized=False)
    write_json(evidence.run_dir / "execution.json", frozen_manifest)
    evidence.command([cfg.baseline_python, "-B", __file__, "_prepare_baseline", "--manifest", evidence.run_dir / "execution.json"],
                     env=env, timeout=180, name="prepare-baseline")
    # Reserve neither a second target nor another service's port/process.
    for port in (1929, 1930):
        with socket.socket() as probe:
            try:
                probe.bind(("127.0.0.1", port))
            except OSError as exc:
                raise RuntimeError(f"occupied experiment port {port}") from exc
    processes = evidence.command(["ps", "-eo", "pid,args"], name="preflight-processes")
    if any(("freetoken.cli serve" in row or "ft serve" in row or "llama-server" in row) for row in processes.splitlines()):
        raise RuntimeError("another target service is active; leave it untouched")
    run_log = evidence.run_dir / "server.log"
    results = []
    with run_log.open("wb") as log:
        child = subprocess.Popen(cfg.baseline_argv, cwd=cfg.experiment, env=env,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        write_json(evidence.run_dir / "owned-process.json", {"pid": child.pid, "pgid": child.pid,
                    "argv": cfg.baseline_argv, "start_time": dt.datetime.now(dt.timezone.utc).isoformat()})
        record = {"run_id": evidence.run_id, "argv": cfg.baseline_argv, "pid": child.pid,
                  "cwd": str(cfg.experiment), "stdout_stderr": str(run_log)}
        evidence.commands.append(record)
        with (evidence.root / "commands.jsonl").open("a") as handle:
            handle.write(json.dumps(record) + "\n")
        started = time.monotonic()
        print(f"baseline pid={child.pid} log={run_log}", flush=True)
        try:
            while True:
                if child.poll() is not None:
                    raise RuntimeError(f"baseline exited during load ({child.returncode}); see {run_log}")
                if time.monotonic() - started > 900:
                    raise TimeoutError("baseline startup exceeded 900 seconds")
                try:
                    health = http_json("http://127.0.0.1:1929/health")
                    if health.get("status") == "ok":
                        break
                    if health.get("status") == "error":
                        raise RuntimeError(f"baseline startup failed: {health}")
                except (urllib.error.URLError, TimeoutError):
                    pass
                time.sleep(1)
            write_json(evidence.run_dir / "health-ready.json", health)
            write_json(evidence.run_dir / "cache-ready.json", http_json("http://127.0.0.1:1929/v1/cache/status"))
            print(f"baseline ready after {time.monotonic() - started:.1f}s", flush=True)
            cases = json.loads((evidence.root / "corpus/manifest.json").read_text())["cases"]
            if selected_case:
                cases = [case for case in cases if case["name"] == selected_case]
            for case in cases:
                for repeat in range(2):
                    payload = {"model": "qwen38-next-freetoken", "prompt": Path(case["prompt_text"]).read_text(),
                               "max_tokens": case["max_new_tokens"], "temperature": 0, "top_k": 1, "top_p": 1,
                               "ignore_eos": False, "stream": True, "stream_options": {"include_usage": True}}
                    label = f"{case['name']}-{repeat}"
                    write_json(evidence.run_dir / f"{label}-request.json", payload)
                    print(f"running {label}: {case['prompt_tokens']} input tokens", flush=True)
                    result = stream_completion("http://127.0.0.1:1929/v1/completions", payload,
                                               evidence.run_dir / f"{label}-stream.jsonl")
                    if result["usage"]["prompt_tokens"] != case["prompt_tokens"]:
                        raise RuntimeError("baseline changed the frozen input token count")
                    result.update({"case": case["name"], "repeat": repeat, "prefix_state": "first occurrence" if repeat == 0 else "potential radix hit; inspect server cache evidence"})
                    write_json(evidence.run_dir / f"{label}-result.json", result)
                    results.append(result)
                    write_json(evidence.run_dir / "baseline-results.json", results)
                    print(json.dumps({k: result[k] for k in ("case", "repeat", "usage", "ttft_seconds", "request_seconds", "decode_tps_text_chunk_proxy")}), flush=True)
                    if repeat:
                        comparison = compare_repeats(results[-2], result)
                        write_json(evidence.run_dir / "repeatability.json", comparison)
                        if comparison["decision"] != "PASS_TEXT_ONLY":
                            raise CorrectnessFailure(f"identical greedy {case['name']} requests diverge at character {comparison['first_differing_character']}; dependent probes stopped")
            write_json(evidence.run_dir / "baseline-results.json", results)
        finally:
            # This session was created here. No caller-supplied PID is signalled.
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=10)
            write_json(evidence.run_dir / "process-exit.json", {"pid": child.pid, "returncode": child.returncode})
    evidence.source_identity()
    evidence.status("IN_PROGRESS", source=source, measured={"baseline_requests": len(results)},
                    next_action="Audit baseline state/token repeatability and loaded hardware; do not start G1 until G0 passes")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["inventory", "baseline", "compare", "offload", "bridge", "verify", "draft", "loop", "acceptance", "_runtime_inventory", "_prepare_baseline"])
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--depth", type=int, choices=[1, 2, 4], default=1)
    parser.add_argument("--case", choices=["small-code", "retained-retrieval", "near-full-code"])
    parser.add_argument("--records", type=Path, help="Existing evidence run directory for compare")
    args = parser.parse_args()
    if args.command == "_runtime_inventory":
        runtime_inventory()
        return 0
    if args.manifest is None:
        parser.error("--manifest is required")
    evidence = None
    try:
        evidence = Evidence(Manifest.read(args.manifest))
        if args.command == "_prepare_baseline":
            prepare_baseline(evidence.config)
            return 0
        if args.command == "inventory":
            inventory(evidence)
            return 0
        if args.command == "baseline":
            baseline(evidence, args.case)
            return 0
        if args.command == "compare":
            if args.records is None or not args.records.resolve().is_relative_to(evidence.root):
                raise ValueError("--records must name a run inside .mtp-exp")
            evidence.source_identity()
            name = args.case or "small-code"
            records = [json.loads((args.records / f"{name}-{i}-result.json").read_text()) for i in range(2)]
            requests = [json.loads((args.records / f"{name}-{i}-request.json").read_text()) for i in range(2)]
            if requests[0] != requests[1]:
                raise ValueError("cannot compare different requests as repeats")
            comparison = compare_repeats(*records)
            write_json(evidence.run_dir / "repeatability.json", comparison)
            print(json.dumps(comparison))
            if comparison["decision"] != "PASS_TEXT_ONLY":
                raise CorrectnessFailure(f"saved {name} baseline requests are not repeatable")
            return 0
        reason = f"NOT_RUN: {args.command} has no implemented adapter; G0 must pass first"
        write_json(evidence.run_dir / "not-run.json", {"decision": "NOT_RUN", "reason": reason})
        print(reason, file=sys.stderr)
        return 6
    except Exception as exc:
        if evidence:
            (evidence.run_dir / "failure.txt").write_text(traceback.format_exc())
            decision = "FAIL_CORRECTNESS" if isinstance(exc, CorrectnessFailure) else "BLOCKED_SETUP" if isinstance(exc, ValueError) else "BLOCKED_ENVIRONMENT"
            evidence.status(decision, failures=[str(exc)], next_action="Diagnose protected-baseline prefix miss/hit divergence in the experiment; G1-G6 remain NOT_RUN" if isinstance(exc, CorrectnessFailure) else "Resolve the recorded G0 failure and rerun")
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 3 if isinstance(exc, CorrectnessFailure) else 2 if isinstance(exc, ValueError) else 6


if __name__ == "__main__":
    raise SystemExit(main())
