#!/usr/bin/env python3
"""G1 real NVFP4 layer probe using a checked ordinary target continuation."""
from __future__ import annotations

import argparse
from dataclasses import asdict, replace
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
import traceback

from qwen38_mtp_probe import CorrectnessFailure, Evidence, Manifest, write_json
from qwen38_mtp_diagnose import tensor_error


class Finished(Exception):
    pass


TRACE_ROWS = 120


def worker(cfg, output, no_trace=False):
    import torch
    import freetoken
    from freetoken.core import SamplingParams
    from freetoken.gpu_select import set_assigned_gpu
    from freetoken.layers.moe import OffloadMoELayer
    from freetoken.message import DetokenizeMsg, ErrorReplyMsg, UserMsg
    from freetoken.scheduler import Scheduler
    from freetoken.server.args import parse_args

    assert Path(freetoken.__file__).resolve() == cfg.experiment / "python/freetoken/__init__.py"
    set_assigned_gpu(cfg.target_uuid)
    args, _ = parse_args(cfg.baseline_argv[5:])
    ids = json.loads((cfg.experiment / ".mtp-exp/corpus/small-code.json").read_text())
    reference = ".mtp-exp/probes/20260905T070632.107190Z/request-0.json"
    expected = json.loads((cfg.experiment / reference).read_text())["tokens"]

    class TraceScheduler(Scheduler):
        def __init__(self, config):
            self.sent = False
            self.tokens = []
            self.trace = {}
            self.initial_cache = None
            super().__init__(config)

        def offline_receive_msg(self, blocking=False):
            if not blocking:
                return []
            if self.sent:
                raise Finished
            self.sent = True
            return [UserMsg(uid=0, input_ids=torch.tensor(ids, dtype=torch.int32),
                            sampling_params=SamplingParams(temperature=0, top_k=1, top_p=1,
                                                           ignore_eos=False, max_tokens=128))]

        def offline_send_result(self, replies):
            for reply in replies:
                if isinstance(reply, ErrorReplyMsg):
                    raise RuntimeError(reply.error)
                if isinstance(reply, DetokenizeMsg):
                    self.tokens.append(reply.next_token)

    # Allocate on the engine's uncaptured warmup, then record through the real
    # graph. The final row is a sink that preserves the bounded trace window.
    buffers, snapshots = {}, {}
    trace_step = None
    original_decode = OffloadMoELayer._decode_routed
    def traced(layer, hidden_states, topk_weights, topk_ids):
        nonlocal trace_step
        cache = layer.offload_cache
        li = layer.layer_id
        assert hidden_states.shape[0] == 1
        if trace_step is None:
            trace_step = torch.zeros(1, dtype=torch.int64, device=hidden_states.device)
        if li not in buffers:
            values = {"input": hidden_states, "weights": topk_weights, "raw_ids": topk_ids,
                      "output": hidden_states, "missing_ids": cache.src_indices[:topk_ids.numel()].reshape(1, -1),
                      "missing_count": cache.num_indices.reshape(1, -1)}
            buffers[li] = {key: value.new_empty((TRACE_ROWS + 1, *value.shape[1:])) for key, value in values.items()}
            if li == 0:
                for key in ("slot_for_id", "id_of_slot", "usage", "step"):
                    value = getattr(cache, key)
                    snapshots[key] = value.new_empty((TRACE_ROWS + 1, *value.shape))
        index = trace_step.clamp(max=TRACE_ROWS)
        row = buffers[li]
        if li == 0:
            for key, value in snapshots.items():
                value.index_copy_(0, index, getattr(cache, key).unsqueeze(0))
        for key, value in (("input", hidden_states), ("weights", topk_weights), ("raw_ids", topk_ids)):
            row[key].index_copy_(0, index, value)
        result = original_decode(layer, hidden_states, topk_weights, topk_ids)
        row["output"].index_copy_(0, index, result)
        row["missing_ids"].index_copy_(0, index, cache.src_indices[:topk_ids.numel()].reshape(1, -1))
        row["missing_count"].index_copy_(0, index, cache.num_indices.reshape(1, -1))
        if li == 47:
            trace_step.add_(1)
        return result

    scheduler = None
    with torch.inference_mode():
        try:
            if not no_trace:
                OffloadMoELayer._decode_routed = traced
            scheduler = TraceScheduler(replace(args, offline_mode=True))
            cache = scheduler.engine.moe_offload_cache
            assert cache.quant_format == "nvfp4" and cache.decode_target == "gpu"
            assert not cache.cpu_layer_ids and scheduler.engine.cpu_moe_executor is None
            assert not cache._unpinned_layers
            uuid = "GPU-" + str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-")
            assert uuid == cfg.target_uuid
            layers = [layer.mlp.experts for layer in scheduler.engine.model.model.layers.op_list]
            originals = [original_decode.__get__(layer, OffloadMoELayer) for layer in layers]
            torch.cuda.synchronize()
            if trace_step is not None:
                trace_step.zero_()
            torch.cuda.synchronize()
            try:
                scheduler.run_forever()
            except Finished:
                pass
            torch.cuda.synchronize()
            OffloadMoELayer._decode_routed = original_decode
            if not no_trace:
                assert int(trace_step.item()) >= TRACE_ROWS
            for li, values in buffers.items():
                values = {key: value[:TRACE_ROWS].cpu() for key, value in values.items()}
                for step in range(TRACE_ROWS):
                    count = int(values["missing_count"][step].item())
                    assert 0 <= count <= values["missing_ids"].shape[1]
                    scheduler.trace[(step, li)] = {
                        **{key: values[key][step:step+1].clone() for key in ("input", "weights", "raw_ids", "output")},
                        "missing_ids": values["missing_ids"][step, :count].clone()}
            scheduler.initial_cache = {key: value[0].cpu().clone() for key, value in snapshots.items()}
            write_json(output / "tokens.json", scheduler.tokens)
            token_check = {"tokens_exact": scheduler.tokens == expected,
                           "observed_length": len(scheduler.tokens), "expected_length": len(expected),
                           "reference": reference,
                           "first_difference": next((i for i, (a, b) in enumerate(zip(scheduler.tokens, expected)) if a != b), None)}
            write_json(output / "trace-token-check.json", token_check)
            torch.save(scheduler.trace, output / "trace.pt")
            torch.save(scheduler.initial_cache, output / "initial-cache.pt")
            banks = {key: {"shape": list(t.shape), "dtype": str(t.dtype),
                            "slot_stride_bytes": t.stride(0) * t.element_size()}
                     for key, t in cache.bank_caches.items()}
            row_bytes = sum(x["slot_stride_bytes"] for x in banks.values())
            write_json(output / "resolved-runtime.json", {
                "freetoken_path": freetoken.__file__, "gpu_uuid": uuid,
                "config": json.loads(json.dumps(asdict(scheduler.engine.config), default=str)),
                "banks": banks, "bytes_per_expert": row_bytes, "cache_size": cache.cache_size,
                "num_layers": cache.num_layers, "num_experts": cache.num_experts,
                "graph_trace": not no_trace, "trace_rows_per_layer": 0 if no_trace else TRACE_ROWS,
                "bf16_reduced_precision_reduction": torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
                "trace_timing_valid_for_performance": False, "cpu_moe_executor": None})
            print(json.dumps(token_check), flush=True)
            if not token_check["tokens_exact"]:
                raise CorrectnessFailure("experiment continuation differs from the protected reference")
            if no_trace:
                return
            layer_probe(scheduler.trace, cache, originals, row_bytes, output)
            replay_cache(scheduler.trace, scheduler.initial_cache, cache, row_bytes, output)
            moe_stack_probe(scheduler.trace, scheduler.initial_cache, cache, originals, output)
            bridge_fetch_probe(cfg, scheduler.trace, cache, row_bytes, output)
        finally:
            OffloadMoELayer._decode_routed = original_decode
            if scheduler is not None:
                scheduler.shutdown()


def layer_probe(trace, cache, originals, row_bytes, output):
    import torch
    results = []
    # Predeclare exact output equality: the same native GEMV kernel and real inputs.
    for li in (0, 23, 47):
        for start in (0, 5, TRACE_ROWS // 2, TRACE_ROWS - 5):
            for width in (2, 3, 5):
                rows = [trace[(step, li)] for step in range(start, start + width)]
                x = torch.cat([r["input"] for r in rows]).cuda()
                weights = torch.cat([r["weights"] for r in rows]).cuda()
                raw = torch.cat([r["raw_ids"] for r in rows]).cuda()
                expected = torch.cat([r["output"] for r in rows]).cuda()
                cache.reset()
                block = originals[li](x, weights, raw.clone())
                fetched = int(cache.num_indices.item())
                actual_misses = cache.src_indices[:fetched].cpu().tolist()
                check = tensor_error(expected, block)
                row = {"layer": li, "start": start, "width": width,
                       "cold_unique_experts": len(set(raw.cpu().flatten().tolist())),
                       "cold_fetched_experts": fetched, "cold_fetched_bytes": fetched * row_bytes,
                       "missing_ids": actual_misses, "output_vs_recorded_rows": check}
                if not check["exact"] or fetched != row["cold_unique_experts"]:
                    results.append(row)
                    write_json(output / "layers.json", results)
                    raise CorrectnessFailure("multi-row offload output or transfer deduplication differs")
                # Matched cold initial state; route clones are included in both timings.
                for mode in ("block", "rows"):
                    samples = []
                    for _ in range(5):
                        cache.reset()
                        begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                        begin.record()
                        if mode == "block":
                            originals[li](x, weights, raw.clone())
                        else:
                            for index in range(width):
                                originals[li](x[index:index + 1], weights[index:index + 1], raw[index:index + 1].clone())
                        end.record()
                        end.synchronize()
                        samples.append(begin.elapsed_time(end))
                    row[f"{mode}_cold_ms"] = samples
                cache.reset()
                originals[li](x, weights, raw.clone())
                originals[li](x, weights, raw.clone())
                row["warm_fetched_experts"] = int(cache.num_indices.item())
                assert row["warm_fetched_experts"] == 0
                results.append(row)
                write_json(output / "layers.json", results)
    print(f"exact multi-row output and transfer checks: {len(results)} cases", flush=True)


def replay_cache(trace, initial, cache, row_bytes, output):
    import torch
    reports = []
    trace_rows = len(trace) // cache.num_layers
    for width in (1, 2, 3, 5):
        for key, value in initial.items():
            getattr(cache, key).copy_(value)
        calls = []
        for start in range(0, trace_rows, width):
            stop = min(start + width, trace_rows)
            for li in range(48):
                raw = torch.cat([trace[(step, li)]["raw_ids"] for step in range(start, stop)]).cuda()
                cache.ensure_experts(li, raw)
                count = int(cache.num_indices.item())
                misses = cache.src_indices[:count].cpu().tolist()
                if width == 1 and sorted(misses) != sorted(trace[(start, li)]["missing_ids"].tolist()):
                    raise CorrectnessFailure(f"global cache replay disagrees with actual trace at {start}/{li}")
                calls.append({"start": start, "rows": stop - start, "layer": li,
                              "missing_ids": misses, "bytes": count * row_bytes})
        report = {"block_width": width, "rows": trace_rows, "layer_calls": len(calls),
                  "fetched_experts": sum(len(x["missing_ids"]) for x in calls),
                  "fetched_bytes": sum(x["bytes"] for x in calls), "calls": calls,
                  "method": "real GPU cache-metadata replay from captured initial global state; no expert compute or copies",
                  "ordinary_order_validated_against_trace": width == 1}
        reports.append(report)
        write_json(output / "cache-replay.json", reports)
    cache.reset()
    print(json.dumps([{k: v for k, v in r.items() if k != "calls"} for r in reports]), flush=True)


def moe_stack_probe(trace, initial, cache, originals, output):
    import torch
    # Restore both weight contents and metadata. Restoring just the maps would
    # claim hits against stale slots after the preceding independent layer probe.
    initial_ids = initial["id_of_slot"]
    resident = []
    for li in range(cache.num_layers):
        slots = ((initial_ids >= li * cache.num_experts) &
                 (initial_ids < (li + 1) * cache.num_experts)).nonzero().flatten()
        if slots.numel():
            resident.append((li, slots.cuda().to(cache.evict_slots.dtype),
                (initial_ids[slots] % cache.num_experts).cuda().to(cache.src_indices.dtype)))
    initial_gpu = {key: value.cuda() for key, value in initial.items()}
    def restore():
        for li, slots, experts in resident:
            n = slots.numel()
            cache.evict_slots[:n].copy_(slots)
            cache.src_indices[:n].copy_(experts)
            cache.num_indices.fill_(n)
            cache._pending_src_layer = li
            cache._pending_whole_layer = False
            cache.copy_missing()
        for key, value in initial_gpu.items():
            getattr(cache, key).copy_(value)
    inputs = {li: {key: torch.cat([trace[(i, li)][key] for i in range(TRACE_ROWS)]).cuda()
                    for key in ("input", "weights", "raw_ids")}
              for li in range(cache.num_layers)}
    reports = []
    for width in (1, 2, 3, 5):
        def execute():
            outputs = []
            for start in range(0, TRACE_ROWS, width):
                for li in range(cache.num_layers):
                    values = inputs[li]
                    value = originals[li](values["input"][start:start+width],
                        values["weights"][start:start+width], values["raw_ids"][start:start+width].clone())
                    outputs.append(value)
            return outputs
        torch.cuda.synchronize()
        stream = torch.cuda.Stream()
        with torch.cuda.stream(stream):
            restore()
            execute()
        stream.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph, stream=stream):
            outputs = execute()
        samples = []
        for repeat in range(4):
            with torch.cuda.stream(stream):
                restore()
                begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                begin.record()
                graph.replay()
                end.record()
            end.synchronize()
            samples.append(begin.elapsed_time(end))
        expected = torch.cat([trace[(step, li)]["output"]
            for start in range(0, TRACE_ROWS, width) for li in range(cache.num_layers)
            for step in range(start, start + width)])
        actual = torch.cat([value.cpu() for value in outputs])
        check = tensor_error(expected, actual)
        report = {"width": width, "rows": TRACE_ROWS, "layers": cache.num_layers,
                  "moe_only_graph_ms": samples, "moe_only_ms_per_input_row": [x/TRACE_ROWS for x in samples],
                  "all_outputs_vs_recorded": check,
                  "initial_resident_experts_restored": sum(x[1].numel() for x in resident),
                  "restore_cost_in_timing": False,
                  "timing_scope": "all recorded MoE inputs/routes, real global cache and expert kernels; no router, attention, dense, head, draft, or catch-up",
                  "oracle_routes": True, "greedy_acceptance_assumed_for_budget_only": True}
        reports.append(report)
        write_json(output / "moe-stack.json", reports)
        print(f"MoE stack width {width}: {report['moe_only_ms_per_input_row']}; exact={check['exact']}", flush=True)
        if not check["exact"]:
            raise CorrectnessFailure("whole-trace MoE output differs from recorded ordinary rows")
        del graph, outputs
    cache.reset()


def bridge_fetch_probe(cfg, trace, cache, row_bytes, output):
    import torch
    from qwen38_mtp_bridge import Bridge
    bridge = Bridge(cfg, output)
    records = []
    try:
        for width in (1, 2, 3, 5):
            for _ in range(8):
                bridge.exchange(width, "warmup")
            for _ in range(40):
                bridge.exchange(width, "target_resident_idle")
            li = 23
            raw = torch.cat([trace[(60 + step, li)]["raw_ids"] for step in range(width)]).cuda()
            routed = raw.clone()
            misses = len(set(raw.cpu().flatten().tolist()))
            copy_samples = []
            for _ in range(12):
                cache.reset()
                routed.copy_(raw)
                cache.ensure_experts(li, routed)
                begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                begin.record()
                cache.copy_missing()
                end.record()
                end.synchronize()
                assert int(cache.num_indices.item()) == misses
                copy_samples.append(begin.elapsed_time(end))
            stream = torch.cuda.Stream()
            def fetch():
                cache.reset()
                routed.copy_(raw)
                cache.ensure_experts(li, routed)
                cache.copy_missing()
            torch.cuda.synchronize()
            with torch.cuda.stream(stream):
                fetch()
            stream.synchronize()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph, stream=stream):
                fetch()
            stream.synchronize()
            for mode in ("alone", "with_bridge", "alone_after"):
                stop, active = threading.Event(), threading.Event()
                errors = []
                def sender():
                    try:
                        with torch.inference_mode():
                            bridge.exchange(width, "contention_warmup")
                            active.set()
                            while not stop.is_set():
                                bridge.exchange(width, "with_expert_fetch")
                    except BaseException as error:
                        errors.append(error)
                        active.set()
                thread = None
                if mode == "with_bridge":
                    thread = threading.Thread(target=sender)
                    thread.start()
                    if not active.wait(timeout=60):
                        raise RuntimeError("bridge thread failed to become ready")
                samples = []
                started = time.monotonic_ns()
                try:
                    for _ in range(3):
                        begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                        with torch.cuda.stream(stream):
                            begin.record()
                            for _ in range(80):
                                graph.replay()
                            end.record()
                        end.synchronize()
                        samples.append(begin.elapsed_time(end) / 80)
                finally:
                    finished = time.monotonic_ns()
                    stop.set()
                    if thread:
                        thread.join(timeout=65)
                        if thread.is_alive():
                            raise RuntimeError("bridge thread did not drain")
                if errors:
                    raise errors[0]
                records.append({"width": width, "layer": li, "mode": mode,
                    "fetched_experts_per_call": misses, "fetched_bytes_per_call": misses * row_bytes,
                    "copy_only_cuda_ms": copy_samples, "reset_plan_copy_graph_ms_per_call": samples,
                    "calls_per_sample": 80, "started_monotonic_ns": started, "finished_monotonic_ns": finished,
                    "target_compute_included": False, "cache_reset_each_call": True,
                    "bridge_synthetic_source_fill_concurrent": mode == "with_bridge"})
                write_json(output / "expert-fetch-interference.json", records)
            del graph
        print("two-process bridge and expert-fetch interference completed", flush=True)
    finally:
        bridge.close()
        cache.reset()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--worker-output", type=Path)
    parser.add_argument("--no-trace", action="store_true", help="Experiment target-only identity diagnosis")
    parser.add_argument("--prefill-only", action="store_true", help="Bounded prompt transport interference")
    parser.add_argument("--verify-only", action="store_true", help="G2 initial target block oracle")
    parser.add_argument("--verify-case", choices=("small-code", "near-full-chat-code"), default="small-code")
    parser.add_argument("--verify-start", type=int, default=35, help="Ordinary decode index of the selected oracle block")
    args = parser.parse_args()
    cfg = Manifest.read(args.manifest)
    root = cfg.experiment / ".mtp-exp"
    if json.loads((root / "reports/g0-summary.json").read_text())["decision"] != "PASS":
        raise RuntimeError("G0 must pass before offload execution")
    if args.verify_only and json.loads((root / "reports/g1-summary.json").read_text())["decision"] != "PASS":
        raise RuntimeError("G1 must pass before target verification")
    if args.worker_output:
        assert args.worker_output.resolve().is_relative_to(root / "probes")
        if args.verify_only:
            from qwen38_mtp_verify import worker as verify_worker
            verify_worker(cfg, args.worker_output, args.verify_case, args.verify_start)
        elif args.prefill_only:
            from qwen38_mtp_prefill_bridge import worker as prefill_worker
            prefill_worker(cfg, args.worker_output)
        else:
            worker(cfg, args.worker_output, args.no_trace)
        return
    evidence = Evidence(cfg)
    evidence.source_identity()
    processes = evidence.command(["ps", "-eo", "pid,args"])
    if any(x in processes for x in ("freetoken.cli serve", "ft serve", "llama-server", "--worker-output", "--multiprocessing-fork")):
        raise RuntimeError("another model worker is active")
    python = Path(json.loads((root / "environment/experiment-venv.json").read_text())["python"])
    env = evidence.env(cfg.experiment, cfg.target_uuid)
    env["PATH"] = str(python.parent) + ":" + env["PATH"]
    argv = [str(python), "-B", __file__, "--manifest", str(args.manifest), "--worker-output", str(evidence.run_dir)]
    if args.no_trace:
        argv.append("--no-trace")
    if args.prefill_only:
        argv.append("--prefill-only")
    if args.verify_only:
        argv.extend(("--verify-only", "--verify-case", args.verify_case, "--verify-start", str(args.verify_start)))
    stage = "G2" if args.verify_only else "G1"
    state = {"plan_version": "2.1", "stage": stage, "decision": "IN_PROGRESS", "run_id": evidence.run_id,
             "source_identity": evidence.source, "commands": [argv], "evidence_paths": [str(evidence.run_dir)],
             "full_context_feature_stream_authorized": False,
             "next_authorized_action": ("Compare the initial target block against ordinary rows and state; remaining G2 checks follow only after correctness"
                                        if args.verify_only else "Inspect the requested G1 component; consult the gate report before proceeding")}
    write_json(root / "status.json", state)
    print(f"{stage} probe evidence: {evidence.run_dir}", flush=True)
    try:
        with (evidence.run_dir / "worker.log").open("wb") as log:
            child = subprocess.Popen(argv, cwd=cfg.experiment, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            record = {"run_id": evidence.run_id, "argv": argv, "pid": child.pid, "pgid": child.pid,
                      "stdout_stderr": str(evidence.run_dir / "worker.log")}
            write_json(evidence.run_dir / "owned-process.json", record)
            with (root / "commands.jsonl").open("a") as handle:
                handle.write(json.dumps(record) + "\n")
            try:
                result = child.wait(timeout=900)
                if result:
                    raise RuntimeError(f"offload worker exited {result}; inspect worker.log")
            finally:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait(timeout=10)
                write_json(evidence.run_dir / "process-exit.json", {"pid": child.pid, "returncode": child.returncode})
        state["component_result"] = f"COMPLETED; inspect measured comparisons; not a complete {stage} pass"
    except Exception:
        (evidence.run_dir / "failure.txt").write_text(traceback.format_exc())
        state["decision"] = "FAILED_PROBE"
        raise
    finally:
        evidence.source_identity()
        write_json(evidence.run_dir / "status.json", state)
        write_json(root / "status.json", state)


if __name__ == "__main__":
    main()
