#!/usr/bin/env python3
"""Bounded G1 socket transport probe; payloads are synthetic, not MTP state."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import sys
import time

from qwen38_mtp_probe import Manifest, write_json

ROW_BYTES = 20480
CAPACITY = 5 * ROW_BYTES
# Length, generation, request, round, slot, slot sequence, payload, start time.
HEADER = struct.Struct("!8Q")
ACK = struct.Struct("!7Q")


def receive(sock, view):
    while view:
        count = sock.recv_into(view)
        if not count:
            raise EOFError("bridge peer closed before completing frame")
        view = view[count:]


def percentiles(values):
    ordered = sorted(values)
    def at(p):
        return ordered[round((len(ordered) - 1) * p)]
    return {"count": len(values), "p50": at(.50), "p95": at(.95), "p99": at(.99),
            "min": ordered[0], "max": ordered[-1]}


def local_buffers(capacity=CAPACITY):
    import torch
    host = [torch.empty(capacity, dtype=torch.uint8, pin_memory=True) for _ in range(2)]
    device = [torch.empty(capacity, dtype=torch.uint8, device="cuda") for _ in range(2)]
    views = [memoryview(value.numpy()) for value in host]
    return host, device, views


def consumer(cfg, fd, output, capacity_rows=5):
    import torch
    assert os.environ["CUDA_VISIBLE_DEVICES"] == cfg.draft_uuid
    assert torch.cuda.device_count() == 1
    uuid = "GPU-" + str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-")
    assert uuid == cfg.draft_uuid
    capacity = capacity_rows * ROW_BYTES
    host, device, views = local_buffers(capacity)
    stream = torch.cuda.Stream()
    begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    incoming = bytearray(HEADER.size)
    sock = socket.socket(fileno=fd)
    sock.settimeout(60)
    sequences, last, samples, validated = [0, 0], {}, [], []
    expected_round = 0
    try:
        sock.sendall(b"READY")
        while True:
            receive(sock, memoryview(incoming))
            frame, generation, request, round_id, slot, sequence, count, started = HEADER.unpack(incoming)
            if count == 0:
                break
            assert frame == HEADER.size + count
            assert generation == 1 and request == 1 and round_id == expected_round
            assert slot == round_id % 2 and sequence == sequences[slot] + 1
            assert count <= capacity and count // ROW_BYTES in (1, 2, 3, 5, 256)
            assert count % ROW_BYTES == 0
            receive(sock, views[slot][:count])
            with torch.cuda.stream(stream):
                begin.record()
                device[slot][:count].copy_(host[slot][:count], non_blocking=True)
                end.record()
            end.synchronize()
            ready = time.monotonic_ns()
            # Validate the first eight transfers of each payload size on the GPU.
            # Record this diagnostic time separately from consumer-ready latency.
            do_validate = sum(x["bytes"] == count for x in samples) < 8
            if do_validate:
                assert bool((device[slot][:count] == round_id % 251).all().item())
                validated.append(round_id)
            validation_done = time.monotonic_ns()
            # ACK releases staging only after H2D completion. No compute consumer
            # exists in this transport-only probe; the last two slots are checked.
            sock.sendall(ACK.pack(generation, request, round_id, slot, sequence, ready, count))
            samples.append({"round": round_id, "bytes": count, "h2d_ms": begin.elapsed_time(end),
                            "consumer_ready_ms": (ready - started) / 1e6,
                            "validation_ms": (validation_done - ready) / 1e6,
                            "gpu_payload_validated": do_validate})
            sequences[slot] = sequence
            last[slot] = (round_id, count)
            expected_round += 1
        for slot, (round_id, count) in last.items():
            assert bool((device[slot][:count] == round_id % 251).all().item())
        write_json(output / "bridge-consumer.json", {
            "gpu_uuid": uuid, "pid": os.getpid(), "rounds": samples, "last_slots_exact": True,
            "gpu_validated_rounds": validated,
            "pinned_allocations": 2, "pinned_bytes": 2 * capacity, "device_bytes": 2 * capacity,
            "max_inflight": 1, "slot_sequences": sequences})
        sock.sendall(b"CLEAN")
    finally:
        sock.close()


class Bridge:
    def __init__(self, cfg, output, capacity_rows=5):
        import torch
        assert os.environ["CUDA_VISIBLE_DEVICES"] == cfg.target_uuid
        uuid = "GPU-" + str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-")
        assert uuid == cfg.target_uuid and torch.cuda.device_count() == 1
        self.cfg, self.output = cfg, output
        assert capacity_rows in (5, 256)
        self.capacity = capacity_rows * ROW_BYTES
        self.host, self.device, self.views = local_buffers(self.capacity)
        self.stream = torch.cuda.Stream()
        self.begin, self.end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        self.sock, peer = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(60)
        self.log = (output / "bridge-consumer.log").open("wb")
        env = os.environ.copy()
        env.update(CUDA_VISIBLE_DEVICES=cfg.draft_uuid, TVM_FFI_CUDA_ARCH_LIST="8.9")
        argv = [sys.executable, "-B", __file__, "--manifest", str(cfg.experiment / ".mtp-exp/execution.json"),
                "--consumer-fd", str(peer.fileno()), "--output", str(output),
                "--capacity-rows", str(capacity_rows)]
        self.child = subprocess.Popen(argv, env=env, pass_fds=(peer.fileno(),), stdout=self.log,
                                      stderr=subprocess.STDOUT, cwd=cfg.experiment)
        peer.close()
        write_json(output / "bridge-process.json", {"argv": argv, "pid": self.child.pid,
                   "gpu_uuid": cfg.draft_uuid, "owns_full_target": False})
        ready = bytearray(5)
        receive(self.sock, memoryview(ready))
        assert ready == b"READY"
        self.round = 0
        self.sequences = [0, 0]
        self.states = ["FREE", "FREE"]
        self.samples = []

    def exchange(self, rows, label):
        import torch
        count = rows * ROW_BYTES
        assert rows in (1, 2, 3, 5, 256) and count <= self.capacity
        round_id, slot = self.round, self.round % 2
        assert self.states[slot] in ("FREE", "REUSABLE")
        self.sequences[slot] += 1
        sequence = self.sequences[slot]
        with torch.cuda.stream(self.stream):
            self.device[slot][:count].fill_(round_id % 251)
            self.end.record()
        self.end.synchronize()
        started = time.monotonic_ns()
        self.states[slot] = "PRODUCER_COPY"
        with torch.cuda.stream(self.stream):
            self.begin.record()
            self.host[slot][:count].copy_(self.device[slot][:count], non_blocking=True)
            self.end.record()
        self.end.synchronize()
        producer_done = time.monotonic_ns()
        self.states[slot] = "HOST_READY"
        self.sock.sendall(HEADER.pack(HEADER.size + count, 1, 1, round_id, slot, sequence, count, started))
        self.sock.sendall(self.views[slot][:count])
        self.states[slot] = "CONSUMER_COPY"
        reply = bytearray(ACK.size)
        receive(self.sock, memoryview(reply))
        generation, request, ack_round, ack_slot, ack_sequence, ready, ack_count = ACK.unpack(reply)
        assert (generation, request, ack_round, ack_slot, ack_sequence, ack_count) == (1, 1, round_id, slot, sequence, count)
        finished = time.monotonic_ns()
        self.states[slot] = "REUSABLE"
        self.samples.append({"label": label, "round": round_id, "rows": rows, "bytes": count,
                             "started_monotonic_ns": started, "consumer_ready_monotonic_ns": ready,
                             "ack_monotonic_ns": finished,
                             "d2h_ms": self.begin.elapsed_time(self.end),
                             "producer_ready_ms": (producer_done - started) / 1e6,
                             "consumer_ready_ms": (ready - started) / 1e6,
                             "ack_ms": (finished - started) / 1e6})
        self.round += 1

    def close(self):
        try:
            if self.child.poll() is None:
                self.sock.sendall(HEADER.pack(HEADER.size, 1, 1, self.round, 0, 0, 0, 0))
                result = bytearray(5)
                receive(self.sock, memoryview(result))
                assert result == b"CLEAN"
                assert self.child.wait(timeout=20) == 0
            else:
                raise RuntimeError(f"bridge consumer exited {self.child.returncode}")
            summaries = []
            for label, rows in sorted({(x["label"], x["rows"]) for x in self.samples}):
                group = [x for x in self.samples if x["label"] == label and x["rows"] == rows]
                summaries.append({"label": label, "rows": rows,
                    **{key: percentiles([x[key] for x in group]) for key in
                       ("d2h_ms", "producer_ready_ms", "consumer_ready_ms", "ack_ms")}})
            payload = sum(x["bytes"] for x in self.samples)
            write_json(self.output / "bridge-producer.json", {
                "rounds": self.samples, "summaries": summaries, "synthetic_payload": True,
                "feature_rows_exported": 0, "payload_bytes": payload,
                "d2h_bytes": payload, "h2d_bytes": payload,
                "socket_payload_bytes": payload, "socket_full_host_copies_per_payload": 2,
                "socket_logical_host_read_write_bytes": 4 * payload,
                "explicit_cpu_tensor_copy_bytes": 0,
                "metadata_bytes": self.round * (HEADER.size + ACK.size),
                "kernel_socket_internal_extra_copies": "not observed",
                "pinned_allocations_per_process": 2, "pinned_bytes_per_process": 2 * self.capacity,
                "device_bytes_per_process": 2 * self.capacity, "pin_unpin_per_round": 0,
                "allocated_slots": 2, "max_inflight": 1,
                "valid_rows": sum(x["rows"] for x in self.samples),
                "discarded_rows": 0, "retransmitted_rows": 0,
                "request_generation_slot_checks": True,
                "consumer_compute": "none; transport probe only"})
        finally:
            self.sock.close()
            if self.child.poll() is None:
                self.child.terminate()
                try:
                    self.child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    self.child.kill()
                    self.child.wait(timeout=10)
            self.log.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--consumer-fd", type=int)
    parser.add_argument("--capacity-rows", type=int, choices=(5, 256), default=5)
    args = parser.parse_args()
    cfg = Manifest.read(args.manifest)
    assert args.output.resolve().is_relative_to(cfg.experiment / ".mtp-exp/probes")
    if args.consumer_fd is not None:
        consumer(cfg, args.consumer_fd, args.output, args.capacity_rows)
    else:
        bridge = Bridge(cfg, args.output)
        try:
            for rows in (1, 2, 3, 5):
                for _ in range(8):
                    bridge.exchange(rows, "warmup")
                for _ in range(100):
                    bridge.exchange(rows, "idle")
        finally:
            bridge.close()


if __name__ == "__main__":
    main()
