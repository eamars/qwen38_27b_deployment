// G1 diagnostic only: native CPU memory operations, never expert computation.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <sys/resource.h>
#include <vector>
#include <omp.h>

using Clock = std::chrono::steady_clock;
constexpr size_t row_bytes = 2772480;
constexpr size_t experts = 512;

uint64_t checksum(const std::vector<uint64_t>& data) {
    uint64_t result = 0;
    #pragma omp parallel for reduction(+:result) schedule(static)
    for (size_t i = 0; i < data.size(); ++i) result += data[i];
    return result;
}

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    std::ifstream input(argv[1]);
    std::vector<int> routes;
    for (int value; input >> value;) {
        if (value < 0 || value >= int(experts)) return 3;
        routes.push_back(value);
    }
    if (routes.empty() || routes.size() > 1200) return 4;
    std::vector<uint64_t> source(experts * row_bytes / 8), destination(source.size());
    for (size_t i = 0; i < source.size(); ++i) source[i] = i % 251;
    std::fill(destination.begin(), destination.end(), 0);
    omp_set_num_threads(1);
    const uint64_t expected = checksum(source);
    for (int threads : {1, 16}) {
        omp_set_num_threads(threads);
        for (const char* mode : {"stream_read", "stream_copy", "indexed_gather"}) {
            for (int repeat = 0; repeat < 3; ++repeat) {
                rusage before{}, after{};
                getrusage(RUSAGE_SELF, &before);
                const auto begin = Clock::now();
                uint64_t check = 0;
                uint64_t read_bytes = 0, write_bytes = 0;
                if (std::strcmp(mode, "stream_read") == 0) {
                    check = checksum(source);
                    read_bytes = source.size() * 8;
                } else if (std::strcmp(mode, "stream_copy") == 0) {
                    #pragma omp parallel for schedule(static)
                    for (size_t i = 0; i < experts; ++i)
                        std::memcpy(destination.data() + i * row_bytes / 8,
                                    source.data() + i * row_bytes / 8, row_bytes);
                    read_bytes = write_bytes = source.size() * 8;
                } else {
                    // Keep a bounded output and preserve the captured route order.
                    for (size_t start = 0; start < routes.size(); start += 10) {
                        const size_t count = std::min(size_t(10), routes.size() - start);
                        #pragma omp parallel for schedule(static)
                        for (size_t j = 0; j < count; ++j)
                            std::memcpy(destination.data() + j * row_bytes / 8,
                                source.data() + routes[start + j] * row_bytes / 8, row_bytes);
                    }
                    read_bytes = write_bytes = routes.size() * row_bytes;
                }
                const double seconds = std::chrono::duration<double>(Clock::now() - begin).count();
                getrusage(RUSAGE_SELF, &after);
                if (std::strcmp(mode, "stream_copy") == 0) check = checksum(destination);
                if (std::strcmp(mode, "indexed_gather") != 0 && check != expected) return 5;
                if (std::strcmp(mode, "indexed_gather") == 0) {
                    const size_t start = (routes.size() - 1) / 10 * 10;
                    for (size_t j = 0; j < routes.size() - start; ++j)
                        if (std::memcmp(destination.data() + j * row_bytes / 8,
                            source.data() + routes[start+j] * row_bytes / 8, row_bytes)) return 6;
                    check = checksum(destination);
                }
                std::cout << "{\"mode\":\"" << mode << "\",\"threads\":" << threads
                    << ",\"repeat\":" << repeat << ",\"seconds\":" << seconds
                    << ",\"read_bytes\":" << read_bytes << ",\"write_bytes\":" << write_bytes
                    << ",\"logical_GB_s\":" << (read_bytes + write_bytes) / seconds / 1e9
                    << ",\"checksum\":" << check << ",\"minor_faults\":" << after.ru_minflt - before.ru_minflt
                    << ",\"major_faults\":" << after.ru_majflt - before.ru_majflt
                    << ",\"allocated_bytes\":" << (source.size()+destination.size())*8 << "}\n";
            }
        }
    }
}
