# Qwen3.8 MTP experiment probes (plan 2.1)

G0 and G1 passed their scoped gates. G2 is stopped with `FAIL_ECONOMICS`
for the implemented row-ordered, block-MoE verification path. The tested
math/state comparisons pass, but captured near-full target verification
alone exceeds the cycle budget at perfect acceptance. Read
`.mtp-exp/reports/g2-report.md`, `g2-summary.json`, and `.mtp-exp/status.json`.
G3 and later stages have not started; a revised approach needs user review.

The separately authorized directive 2.2 G2R rescue screen is now closed as
`HARD_STOP_SCOPE`. Real dense batching fails the exact operator/route
contract, and the exact-site subset has insufficient measured opportunity.
Read `.mtp-exp/reports/g2r-decision.md` and `.mtp-exp/g2r-status.json`.
The original G2 failure remains unchanged. G2R-B was not integrated.
`qwen38_mtp_dense.py --manifest .mtp-exp/execution.json` reproduces the
bounded G2R-A operator probe when explicitly requested.

Run the actual G1 and initial G2 probes from this checkout inside Ubuntu WSL:

```bash
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_offload.py --manifest .mtp-exp/execution.json
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_offload.py --manifest .mtp-exp/execution.json --prefill-only
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_offload.py --manifest .mtp-exp/execution.json --verify-only
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_offload.py --manifest .mtp-exp/execution.json --verify-only --verify-case near-full-chat-code --verify-start 771
```

The parent records source identity and starts the experiment's separate
interpreter with UUID isolation and experiment-local caches. The environment
reuses existing dependency files read-only and processes their installed
startup hooks; omitting those hooks caused a measured token mismatch.
No packages or model weights are downloaded or changed.

G1 records real NVFP4 layers, global-cache replay, full MoE component timing,
and a two-process socket bridge. `--prefill-only` checks bounded synthetic
prompt transport. `--verify-only` runs the G2 math/state, future-row,
independent restore/replay, and fixed-oracle CUDA capture probes. It requires
the saved G1 pass. Select the frozen prompt with `--verify-case` and an
ordinary decode index with `--verify-start`. The current bounded snapshot
requires all eight reference rows to fit the existing tail page. Component
success is not a complete G2 pass, an MTP implementation, or a final speed claim.

Current G0 repeatability uses `qwen38_mtp_reference.py`. The earlier API
cold/hit comparison is retained as a numerical diagnostic; it does not
compare matching prefix conditions. Read
`.mtp-exp/reports/g0-matched-protocol.md` for the frozen comparison policy.

```bash
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_reference.py --manifest .mtp-exp/execution.json --case near-full-chat-code
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_reference.py --manifest .mtp-exp/execution.json --case near-full-chat-code --compare-with .mtp-exp/probes/FIRST_REFERENCE_RUN
```

Each command creates one target process, runs a prefix miss and two hits,
records raw output IDs and actual admitted cache counts, and shuts it down.
The second command compares cold outputs across fresh processes as well as
hits within its process. No hidden features or numerical overrides are used.
`PASS_MATCHED_TOKENS` applies only to these repeats, not the full G0/G6 gate.
Offline reply timestamps are not client end-to-end acceptance measurements.

The remaining commands below retain the original API and component
diagnostics and their historical interpretation; use the current status and
matched protocol for gate decisions.

Run from this experiment checkout inside Ubuntu WSL. The execution manifest
was resolved from the existing project launcher and local checkpoint.

```bash
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_probe.py inventory --manifest .mtp-exp/execution.json
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_probe.py baseline --manifest .mtp-exp/execution.json --case small-code
```

`baseline` uses the protected checkout, a UUID-isolated target process,
experiment-local caches/logs, and port 1929. It verifies the imported source
and parsed launch policy before loading. Corpus text must round-trip to the
frozen input IDs. Two identical greedy requests run in order with radix
caching enabled. A text/usage/finish mismatch stops immediately with exit 3,
saves `repeatability.json`, and prevents subsequent cases from starting.
Omitting `--case` selects small code, retained retrieval, then the separately
labeled near-full synthetic diagnostic, each with two requests.

The original API cold/hit mismatch is retained as a cross-condition
diagnostic. Matched-condition comparisons subsequently passed G0; consult
the current reports for interpretation. Full-context MTP initialization
remains `BLOCKED_REQUIREMENT`; no complete feature stream is authorized.

Replay the saved comparison without loading a model:

```bash
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_probe.py compare --manifest .mtp-exp/execution.json --records .mtp-exp/probes/20260905T053229.762772Z --case small-code
```

Exit meanings: 0 = requested inventory/comparison/probe completed (not a
G0 pass); 2 = invalid setup; 3 = correctness failure; 6 = unavailable adapter
or blocked environment. The legacy subcommands `offload`, `bridge`, `verify`,
`draft`, `loop`, and `acceptance` in `qwen38_mtp_probe.py` still return
`NOT_RUN`/6. Use the actual G1/G2 runner commands above.

The baseline API does not expose generated IDs. Equal text is only a partial
check; unequal text conclusively fails repeatability. Reported throughput is
a text-chunk timing proxy and is not an acceptance benchmark. Both initial
compilation and prefix-state differences are retained in the raw results.

No model tensor data is copied by inventory, no FTW is written, and no
protected source or project launcher is edited. Process cleanup signals only
the new session created by this runner. Read `reports/g0-report.md` and
`reports/g1-report.md` under `.mtp-exp` for results and verification limits.

The bounded diagnostic captures raw output IDs, full logits, prefill layer
tails, and the first GDN's inputs/state through the protected scheduler:

```bash
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_diagnose.py --manifest .mtp-exp/execution.json
```

It runs one cold and two cache-hit requests with the frozen 66-token prompt.
Observation hooks synchronize the GPU, so the results establish numerical
behavior only. `--disable-bf16-reduction` selects a separately labeled
numerics diagnostic; it is never an unchanged-baseline or performance run.
Exit 0 means the diagnostic completed, including when it found differences.
Inspect `analysis.json` and the component reports for the actual comparisons.

To replay just the first hyper-connection mixer with real checkpoint weights
and 66 embedding rows, without loading the target expert bank:

```bash
/home/rba90/.freetoken-qwen38/venv/bin/python -B benchmarks/qwen38_mtp_diagnose.py --manifest .mtp-exp/execution.json --hc-replay .mtp-exp/probes/20260905T055655.984880Z
```

The historical numerical findings and exact run IDs are in
`.mtp-exp/reports/g0-diagnosis.md`. The current G0 report records stable
matched-condition repeats and retains cold/hit differences as diagnostics.
