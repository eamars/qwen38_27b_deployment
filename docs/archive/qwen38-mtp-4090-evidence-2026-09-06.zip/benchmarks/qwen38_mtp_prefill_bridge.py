"""G1 bounded synthetic prompt payload during matched target-prefix-hit prefill."""
from dataclasses import asdict, replace
import json
from pathlib import Path
import threading
import time

from qwen38_mtp_probe import CorrectnessFailure, digest, write_json
from qwen38_mtp_bridge import Bridge


def worker(cfg, output):
    import torch
    import freetoken
    from freetoken.core import SamplingParams
    from freetoken.gpu_select import set_assigned_gpu
    from freetoken.message import DetokenizeMsg, ErrorReplyMsg, PromptAdmittedMsg, UserMsg
    from freetoken.scheduler import Scheduler
    from freetoken.server.args import parse_args

    assert Path(freetoken.__file__).resolve() == cfg.experiment / "python/freetoken/__init__.py"
    set_assigned_gpu(cfg.target_uuid)
    args, _ = parse_args(cfg.baseline_argv[5:])
    small = json.loads((cfg.experiment / ".mtp-exp/corpus/small-code.json").read_text())
    ids = (small * 16)[:1024]
    write_json(output / "prefill-input-ids.json", ids)
    modes = ("warmup", "alone", "with_bridge", "with_bridge", "alone", "alone", "with_bridge")
    results = {uid: {"uid": uid, "mode": mode, "tokens": []} for uid, mode in enumerate(modes)}

    class Finished(Exception):
        pass

    class PrefillScheduler(Scheduler):
        def __init__(self, config):
            self.next_uid = 0
            self.prefill_gate = None
            self.bridge = None
            super().__init__(config)

        def offline_receive_msg(self, blocking=False):
            if not blocking:
                return []
            if self.next_uid == len(modes):
                raise Finished
            uid = self.next_uid
            self.next_uid += 1
            results[uid]["started_monotonic_ns"] = time.monotonic_ns()
            return [UserMsg(uid=uid, input_ids=torch.tensor(ids, dtype=torch.int32),
                sampling_params=SamplingParams(temperature=0, top_k=1, top_p=1,
                                               ignore_eos=False, max_tokens=2))]

        def offline_send_result(self, replies):
            for reply in replies:
                if isinstance(reply, ErrorReplyMsg):
                    raise RuntimeError(reply.error)
                row = results[reply.uid]
                if isinstance(reply, PromptAdmittedMsg):
                    row["admission"] = asdict(reply)
                if isinstance(reply, DetokenizeMsg):
                    row["tokens"].append(reply.next_token)
                    if reply.finished:
                        row["finish_reason"] = reply.finish_reason
                        row["request_ms"] = (time.monotonic_ns() - row["started_monotonic_ns"]) / 1e6
                        print(f"prefill {reply.uid} {row['mode']}: {row['request_ms']:.3f} ms; {row['admission']}", flush=True)
                        write_json(output / "prefill-results.json", list(results.values()))

        def _forward(self, value):
            if not value.batch.is_prefill:
                return super()._forward(value)
            uid = value.batch.reqs[0].uid
            row = results[uid]
            gate, errors = threading.Event(), []
            thread = None
            self.prefill_gate = gate
            def send_chunks():
                try:
                    if not gate.wait(timeout=60):
                        raise RuntimeError("target did not reach its first prefill MoE layer")
                    with torch.inference_mode():
                        # Four row-aligned chunks equal the bounded 1024-row prompt.
                        for _ in range(4):
                            self.bridge.exchange(256, f"prefill-{uid}")
                except BaseException as error:
                    errors.append(error)
            if row["mode"] == "with_bridge":
                thread = threading.Thread(target=send_chunks)
                thread.start()
            begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            started = time.monotonic_ns()
            try:
                begin.record()
                result = super()._forward(value)
                end.record()
                end.synchronize()
                row["target_prefill_cuda_ms"] = begin.elapsed_time(end)
                row["target_forward_wall_ms"] = (time.monotonic_ns() - started) / 1e6
                return result
            finally:
                if thread:
                    thread.join(timeout=65)
                    if thread.is_alive():
                        raise RuntimeError("prompt bridge did not drain")
                self.prefill_gate = None
                row["joined_forward_ms"] = (time.monotonic_ns() - started) / 1e6
                row["synthetic_payload_rows"] = 1024 if thread else 0
                row["target_features_exported"] = 0
                if errors:
                    raise errors[0]

    scheduler = bridge = None
    with torch.inference_mode():
        try:
            scheduler = PrefillScheduler(replace(args, offline_mode=True))
            assert scheduler.engine.cpu_moe_executor is None
            bridge = Bridge(cfg, output, capacity_rows=256)
            scheduler.bridge = bridge
            for _ in range(8):
                bridge.exchange(256, "warmup")
            layer = scheduler.engine.model.model.layers.op_list[0].mlp.experts
            original = layer._prefill_routed
            def prefill(*values, **kwargs):
                if scheduler.prefill_gate is not None:
                    scheduler.prefill_gate.set()
                return original(*values, **kwargs)
            layer._prefill_routed = prefill
            try:
                scheduler.run_forever()
            except Finished:
                pass
            warm = list(results.values())[1:]
            exact = all(row["tokens"] == warm[0]["tokens"] and
                        row["finish_reason"] == warm[0]["finish_reason"] for row in warm)
            cached = [row["admission"]["cached_tokens"] for row in warm]
            check = {"warm_tokens_and_finish_exact": exact, "warm_cached_tokens": cached,
                     "identical_input_ids_sha256": digest((output / "prefill-input-ids.json").read_bytes()),
                     "model_feature_rows_exported": 0, "synthetic_rows_per_loaded_request": 1024,
                     "full_context_feature_stream_authorized": False,
                     "limitations": "matched prefix-hit residual prefill; synthetic transport, no MTP math or feature tap"}
            write_json(output / "prefill-comparison.json", check)
            write_json(output / "prefill-runtime.json", {"config": json.loads(json.dumps(asdict(scheduler.engine.config), default=str)),
                       "freetoken_path": freetoken.__file__, "target_uuid": cfg.target_uuid, "draft_uuid": cfg.draft_uuid})
            if not exact or not cached[0] or any(x != cached[0] for x in cached):
                raise CorrectnessFailure("prefill bridge changed matched target output or prefix conditions")
        finally:
            if bridge is not None:
                bridge.close()
            if scheduler is not None:
                scheduler.shutdown()
