"""G2 first two-row oracle through the real target and an explicit verify entry."""
import copy
import hashlib
from dataclasses import asdict
import json
from pathlib import Path
import time

from qwen38_mtp_probe import CorrectnessFailure, digest, write_json

START_DECODE = 35
WIDTH = 2
REFERENCE_ROWS = 8


class Snapshot:
    def __init__(self, scheduler, req, layout=None):
        import torch
        engine = scheduler.engine
        pool, kv = engine.linear_state_pool, engine.kv_cache
        if layout is None:
            slots = [x for x in range(pool._num_slots) if x not in pool._free_slots]
            page_size = engine.ctx.page_size
            cmp_page_size = page_size // kv.index_ratio
            first = req.cached_len // page_size * page_size
            tokens = ((req.device_len + REFERENCE_ROWS + page_size-1) // page_size) * page_size
            assert tokens <= ((req.device_len + page_size-1) // page_size) * page_size, "this probe requires an already allocated tail page"
            pages = (engine.page_table[req.table_idx, first:tokens:page_size] // page_size).unique().long()
            cmp_rows = (pages[:, None] * cmp_page_size + torch.arange(cmp_page_size, device=pages.device)).flatten()
            scratch = torch.arange(kv.cmp_scratch_base, kv._cmp_k_buffer.shape[1], device=pages.device)
            self.layout = (torch.tensor(slots, device=engine.device), pages, torch.cat((cmp_rows, scratch)))
        else:
            self.layout = layout
        slots, pages, cmp_rows = self.layout
        self.data = {
            "gdn_recurrent": pool.recurrent_states.index_select(1, slots).cpu(),
            "gdn_conv": pool.conv_states.index_select(1, slots).cpu(),
            "qsa_kv_pages": kv._kv_buffer.index_select(2, pages).cpu(),
            "qsa_compressed": kv._cmp_k_buffer.index_select(1, cmp_rows).cpu(),
            "qsa_ring": kv._pending_ring.cpu().clone(),
            **{f"slot/{key}": value.index_select(1, slots).cpu() for key, value in pool.slot_states.items()},
        }
        self.page_table = engine.page_table.cpu().clone()
        self.free_pages = scheduler.cache_manager.free_slots.cpu().clone()
        self.free_linear = list(pool._free_slots)
        self.request = {key: value for key, value in vars(req).items()
                        if isinstance(value, (int, bool, str, tuple, type(None)))}
        self.ids_buf = req._ids_buf.clone()
        self.host_ids_len = len(req.input_ids)
        self.token_pool = scheduler.token_pool.cpu().clone()
        self.req = req
        self.expert_metadata = {key: getattr(engine.moe_offload_cache, key).cpu().clone()
                                for key in ("slot_for_id", "id_of_slot", "usage", "step")}

    def restore_expert_conditions(self, scheduler):
        import torch
        cache = scheduler.engine.moe_offload_cache
        ids = self.expert_metadata["id_of_slot"]
        for li in range(cache.num_layers):
            slots = ((ids >= li*cache.num_experts) & (ids < (li+1)*cache.num_experts)).nonzero().flatten()
            n = slots.numel()
            if n:
                cache.evict_slots[:n].copy_(slots.to(cache.evict_slots.dtype))
                cache.src_indices[:n].copy_((ids[slots] % cache.num_experts).to(cache.src_indices.dtype))
                cache.num_indices.fill_(n)
                cache._pending_src_layer, cache._pending_whole_layer = li, False
                cache.copy_missing()
        for key, value in self.expert_metadata.items():
            getattr(cache, key).copy_(value)

    def restore(self, scheduler):
        import torch
        engine = scheduler.engine
        pool, kv = engine.linear_state_pool, engine.kv_cache
        slots, pages, cmp_rows = self.layout
        for name, destination, axis, indices in (
            ("gdn_recurrent", pool.recurrent_states, 1, slots),
            ("gdn_conv", pool.conv_states, 1, slots),
            ("qsa_kv_pages", kv._kv_buffer, 2, pages),
            ("qsa_compressed", kv._cmp_k_buffer, 1, cmp_rows),
        ):
            destination.index_copy_(axis, indices, self.data[name].to(engine.device))
        kv._pending_ring.copy_(self.data["qsa_ring"])
        for key, value in pool.slot_states.items():
            value.index_copy_(1, slots, self.data[f"slot/{key}"].to(engine.device))
        engine.page_table.copy_(self.page_table)
        scheduler.cache_manager.free_slots = self.free_pages.to(engine.device)
        pool._free_slots = list(self.free_linear)
        scheduler.token_pool.copy_(self.token_pool)
        for key, value in self.request.items():
            setattr(self.req, key, value)
        self.req._ids_buf.copy_(self.ids_buf)
        self.req.input_ids = self.req._ids_buf[:self.host_ids_len]

    def describe(self):
        return {"tensors": {key: {"shape": list(value.shape), "dtype": str(value.dtype),
                                 "bytes": value.numel()*value.element_size()}
                            for key, value in self.data.items()},
                "linear_slots": self.layout[0].cpu().tolist(),
                "kv_pages": self.layout[1].cpu().tolist(), "request": self.request,
                "free_linear_slots": self.free_linear, "free_pages": len(self.free_pages)}


def comparison(a, b):
    import torch
    from qwen38_mtp_diagnose import tensor_error
    if a.shape != b.shape or a.dtype != b.dtype:
        return {"exact": False, "shape_or_dtype_mismatch": True}
    exact = torch.equal(a, b)
    result = {"exact": exact, "finite": not a.is_floating_point() or
              bool(torch.isfinite(a).all() and torch.isfinite(b).all())}
    if not exact:
        # Keep a mismatch report bounded even for the recurrent-state slab.
        af, bf = a.flatten(), b.flatten()
        for start in range(0, af.numel(), 262144):
            aa, bb = af[start:start+262144], bf[start:start+262144]
            if not torch.equal(aa, bb):
                result["first_differing_flat_chunk"] = start
                result["chunk_errors"] = tensor_error(aa, bb)
                break
    return result


def immutable_prefix_digest(scheduler):
    """Bounded read-only checksum of pages excluded from the tail snapshots."""
    import torch
    seed, engine = scheduler.seed, scheduler.engine
    page_size = engine.ctx.page_size
    stop = seed.request["cached_len"] // page_size * page_size
    pages = (seed.page_table[seed.req.table_idx, :stop:page_size] // page_size).unique().long()
    kv = engine.kv_cache
    ratio = page_size // kv.index_ratio
    result = hashlib.sha256()
    for chunk in pages.split(16):
        indices = chunk.to(engine.device)
        value = kv._kv_buffer.index_select(2, indices).cpu().contiguous()
        result.update(value.view(torch.uint8).numpy())
        cmp_rows = (indices[:, None] * ratio + torch.arange(ratio, device=engine.device)).flatten()
        value = kv._cmp_k_buffer.index_select(1, cmp_rows).cpu().contiguous()
        result.update(value.view(torch.uint8).numpy())
    return {"sha256": result.hexdigest(), "pages": pages.numel(), "chunk_pages": 16}


def worker(cfg, output, case_name="small-code", start_decode=35, operator_probe=None):
    global START_DECODE
    START_DECODE = start_decode
    import torch
    import freetoken
    from dataclasses import replace
    from freetoken.core import Batch, SamplingParams
    from freetoken.gpu_select import set_assigned_gpu
    from freetoken.message import UserMsg
    from freetoken.scheduler import Scheduler
    from freetoken.scheduler.prefill import ChunkedReq
    from freetoken.server.args import parse_args
    from freetoken.models.qwen4_exp.hc import GatedResidual
    from freetoken.models.qwen4_exp.verify import VerifyRows, forward_verify

    assert Path(freetoken.__file__).resolve() == cfg.experiment / "python/freetoken/__init__.py"
    set_assigned_gpu(cfg.target_uuid)
    args, _ = parse_args(cfg.baseline_argv[5:])
    case = next(x for x in json.loads((cfg.experiment / ".mtp-exp/corpus/manifest.json").read_text())["cases"] if x["name"] == case_name)
    prompt_path = Path(case["input_ids"])
    assert digest(prompt_path.read_bytes()) == case["input_ids_sha256"]
    prompt = json.loads(prompt_path.read_text())
    reference_run = "20260905T070632.107190Z" if case_name == "small-code" else "20260905T064122.954190Z"
    expected = json.loads((cfg.experiment / f".mtp-exp/probes/{reference_run}/request-0.json").read_text())["tokens"]
    assert 0 <= START_DECODE and START_DECODE + REFERENCE_ROWS < len(expected)

    original_mix = GatedResidual.mix
    def observe_mix(mixer, residual):
        if not mixer.use_combine:
            if not hasattr(mixer, "_verify_probe_wide"):
                mixer._verify_probe_wide = torch.empty_like(residual[-1:])
            mixer._verify_probe_wide.copy_(residual[-1:])
        return original_mix(mixer, residual)

    class Finished(Exception):
        pass

    class OracleScheduler(Scheduler):
        def __init__(self, config):
            self.sent = False
            self.decode_index = 0
            self.seed = None
            self.rows, self.reference = [], []
            super().__init__(config)

        def offline_receive_msg(self, blocking=False):
            if not blocking:
                return []
            if self.sent:
                raise RuntimeError("oracle request ended before its selected frontier")
            self.sent = True
            return [UserMsg(uid=0, input_ids=torch.tensor(prompt, dtype=torch.int32),
                sampling_params=SamplingParams(temperature=0, top_k=1, top_p=1,
                                               ignore_eos=False, max_tokens=case["max_new_tokens"]))]

        def offline_send_result(self, replies):
            pass

        def _forward(self, value):
            batch = value.batch
            if isinstance(batch.reqs[0], ChunkedReq):
                return super()._forward(value)
            active = batch.is_decode and self.decode_index >= START_DECODE
            if active:
                if self.seed is None:
                    available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                                         if x.startswith('MemAvailable:'))) * 1024
                    assert available > 6 * 1024**3
                    self.seed = Snapshot(self, batch.reqs[0])
                    self.seed_wide = self.engine.model.model.hyper_connection_mixer._verify_probe_wide.cpu().clone()
                    self.prefix_digest = immutable_prefix_digest(self)
                req = copy.copy(batch.reqs[0])
                req.input_ids = torch.tensor(prompt + expected[:self.decode_index+1], dtype=torch.int32)
                assert len(req.input_ids) == req.device_len
                req._ids_buf = req.input_ids.clone()
                row = Batch(reqs=[req], phase="decode")
                row.padded_reqs = row.reqs
                row.input_ids = self.token_pool[value.input_tuple].clone()
                row.positions = batch.positions.clone()
                row.out_loc = batch.out_loc.clone()
                row.active_table_idx = batch.active_table_idx.clone()
                row.linear_table_idx = batch.linear_table_idx.clone()
                row.fla_metadata = None
                self.engine.attn_backend.prepare_metadata(row)
                self.rows.append(row)
            result = super()._forward(value)
            result.copy_done_event.synchronize()
            token = int(result.next_tokens_gpu[0].item())
            expected_index = self.decode_index + 1 if batch.is_decode else 0
            if token != expected[expected_index]:
                write_json(output / "ordinary-token-mismatch.json", {
                    "output_index": expected_index, "actual": token,
                    "expected": expected[expected_index], "phase": batch.phase,
                    "cached_len_after_forward": batch.reqs[0].cached_len})
                raise CorrectnessFailure(f"feature observer changes ordinary token {expected_index}")
            if active:
                mixer = self.engine.model.model.hyper_connection_mixer
                self.reference.append({
                    "wide": mixer._verify_probe_wide.cpu().clone(),
                    "logits": self.engine.graph_runner.buffer.logits[:1].cpu().clone(),
                    "token": token,
                    "state": (Snapshot(self, batch.reqs[0], self.seed.layout)
                              if len(self.rows) in (1, WIDTH, REFERENCE_ROWS) else None),
                })
            if batch.is_decode:
                self.decode_index += 1
            if len(self.rows) == REFERENCE_ROWS:
                raise Finished
            return result

    scheduler = None
    with torch.inference_mode():
        try:
            GatedResidual.mix = observe_mix
            scheduler = OracleScheduler(replace(args, offline_mode=True))
            assert scheduler.engine.cpu_moe_executor is None
            uuid = "GPU-" + str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-")
            assert uuid == cfg.target_uuid and torch.cuda.device_count() == 1
            write_json(output / "resolved-runtime.json", {
                "config": json.loads(json.dumps(asdict(scheduler.engine.config), default=str)),
                "freetoken_path": freetoken.__file__, "gpu_uuid": uuid,
                "bf16_reduced_precision_reduction": torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
                "baseline_argv": cfg.baseline_argv, "CPU_expert_compute": False,
                "case": case, "protected_reference_run": reference_run,
                "oracle_feature_rows_exported": REFERENCE_ROWS + 1,
                "verify_feature_rows_per_call": WIDTH,
                "complete_prompt_features_exported": False})
            try:
                scheduler.run_forever()
            except Finished:
                pass
            GatedResidual.mix = original_mix
            seed = scheduler.seed
            write_json(output / "oracle-seed.json", seed.describe())
            write_json(output / "oracle-row-frontiers.json", [x["state"].describe() for x in scheduler.reference if x["state"]])
            torch.save({"wide": torch.cat([x["wide"] for x in scheduler.reference]),
                        "h_prev": scheduler.seed_wide,
                        "logits": torch.cat([x["logits"] for x in scheduler.reference])}, output / "oracle-outputs.pt")
            if operator_probe is not None:
                operator_probe(scheduler, output)
                return
            with torch.cuda.stream(scheduler.engine.stream):
                seed.restore(scheduler)
                torch.cuda.current_stream().synchronize()
                started = time.monotonic_ns()
                wide, logits, counters = forward_verify(scheduler.engine.model, VerifyRows(tuple(scheduler.rows[:WIDTH])))
                done = torch.cuda.Event()
                done.record()
                done.synchronize()
                elapsed = (time.monotonic_ns() - started) / 1e6
                state = Snapshot(scheduler, seed.req, seed.layout)
            wide_cpu, logits_cpu = wide.cpu(), logits.cpu()
            ref_wide = torch.cat([x["wide"] for x in scheduler.reference[:WIDTH]])
            ref_logits = torch.cat([x["logits"] for x in scheduler.reference[:WIDTH]])
            ref_state = scheduler.reference[WIDTH-1]["state"]
            report = {
                "width": WIDTH, "start_decode_index": START_DECODE,
                "input_positions": [int(x.positions[0]) for x in scheduler.rows[:WIDTH]],
                "input_ids": [int(x.input_ids[0]) for x in scheduler.rows[:WIDTH]],
                "reference_next_tokens": [x["token"] for x in scheduler.reference[:WIDTH]],
                "verify_next_tokens": logits_cpu.argmax(-1).tolist(),
                "wide": comparison(ref_wide, wide_cpu), "logits": comparison(ref_logits, logits_cpu),
                "state": {key: comparison(ref_state.data[key], value) for key, value in state.data.items()},
                "page_table_unchanged": torch.equal(seed.page_table, state.page_table),
                "free_pages_unchanged": torch.equal(seed.free_pages, state.free_pages),
                "free_linear_unchanged": seed.free_linear == state.free_linear,
                "request_frontier_not_committed": seed.request == state.request,
                "counters": counters, "eager_wall_ms": elapsed,
                "timing_limit": "first eager shape and cache warmed by ordinary oracle; diagnostic only",
                "numerical_policy": "exact for first per-row arithmetic slice",
                "full_context_feature_stream_authorized": False,
            }
            report["decision"] = "PASS_INITIAL_MATH" if (
                report["reference_next_tokens"] == report["verify_next_tokens"] and
                all(report[key]["exact"] and report[key]["finite"] for key in ("wide", "logits")) and
                all(x["exact"] and x["finite"] for x in report["state"].values()) and
                all(report[key] for key in ("page_table_unchanged", "free_pages_unchanged", "free_linear_unchanged", "request_frontier_not_committed"))
            ) else "FAIL_CORRECTNESS"
            write_json(output / "verify-comparison.json", report)
            torch.save({"wide": wide_cpu, "logits": logits_cpu}, output / "verify-outputs.pt")
            print(json.dumps(report), flush=True)
            if report["decision"] == "FAIL_CORRECTNESS":
                raise CorrectnessFailure("initial verify math or state differs from ordinary decode")
            boundary_probe(scheduler, output)
            capture_probe(scheduler, output)
            final_digest = immutable_prefix_digest(scheduler)
            prefix_check = {"before": scheduler.prefix_digest, "after": final_digest,
                            "exact": scheduler.prefix_digest == final_digest}
            write_json(output / "immutable-prefix-comparison.json", prefix_check)
            if not prefix_check["exact"]:
                raise CorrectnessFailure("verification or oracle replay overwrote an immutable prefix page")
        finally:
            GatedResidual.mix = original_mix
            if scheduler is not None:
                scheduler.shutdown()


def ordinary_rows(scheduler, rows):
    """Independent slow oracle: full ordinary graph traversal for each row."""
    import torch
    ctx = scheduler.engine.ctx
    values = []
    for original in rows:
        # prepare_for_replay binds metadata to shared graph buffers. Keep the
        # verification rows' independent causal metadata out of that mutation.
        row = copy.copy(original)
        scheduler.engine.attn_backend.prepare_metadata(row)
        with ctx.forward_batch(row), scheduler.engine.model.forward_host_ctx(row, True):
            logits = scheduler.engine.graph_runner.replay(row)
            values.append(logits.clone())
    return torch.cat(values)


def state_check(expected, actual):
    return {key: comparison(expected.data[key], value) for key, value in actual.data.items()}


def boundary_probe(scheduler, output):
    import torch
    from freetoken.models.qwen4_exp.verify import VerifyRows, forward_verify
    seed, rows, reference = scheduler.seed, scheduler.rows, scheduler.reference
    records = []
    with torch.cuda.stream(scheduler.engine.stream):
        seed.restore(scheduler)
        altered = copy.copy(rows[1])
        altered.reqs = [copy.copy(rows[1].reqs[0])]
        altered.padded_reqs = altered.reqs
        altered.reqs[0].input_ids = altered.reqs[0].input_ids.clone()
        alternative = (int(rows[1].input_ids[0]) + 1) % 248320
        altered.input_ids = torch.full_like(rows[1].input_ids, alternative)
        altered.reqs[0].input_ids[-1] = alternative
        scheduler.engine.attn_backend.prepare_metadata(altered)
        wide, logits, _ = forward_verify(scheduler.engine.model, VerifyRows((rows[0], altered)))
        torch.cuda.current_stream().synchronize()
        perturb = {"test": "future_candidate_perturbation", "replacement_candidate": alternative,
                   "earlier_wide": comparison(reference[0]["wide"], wide[:1].cpu()),
                   "earlier_logits": comparison(reference[0]["logits"], logits[:1].cpu())}
        records.append(perturb)
        write_json(output / "boundary-comparison.json", records)
        if not perturb["earlier_wide"]["exact"] or not perturb["earlier_logits"]["exact"]:
            raise CorrectnessFailure("future candidate affects an earlier verification row")

        for accepted in (0, 1):
            seed.restore(scheduler)
            # Force speculative work first; the slow oracle then discards it by
            # restoring semantic state and replaying only the committed prefix.
            forward_verify(scheduler.engine.model, VerifyRows((rows[0], altered if accepted == 0 else rows[1])))
            seed.restore(scheduler)
            committed = accepted + 1
            emitted_logits = ordinary_rows(scheduler, rows[:committed])
            boundary = Snapshot(scheduler, seed.req, seed.layout)
            expected_state = reference[committed-1]["state"]
            checks = state_check(expected_state, boundary)
            continuation = ordinary_rows(scheduler, rows[committed:])
            final = Snapshot(scheduler, seed.req, seed.layout)
            final_checks = state_check(reference[-1]["state"], final)
            expected_logits = torch.cat([x["logits"] for x in reference])
            outputs = comparison(expected_logits, torch.cat((emitted_logits, continuation)).cpu())
            record = {"test": "slow_commit_and_continuation", "forced_accepted_candidates": accepted,
                      "committed_input_rows": committed, "new_processed_length": seed.request["cached_len"]+committed,
                      "new_pending_position": seed.request["cached_len"]+committed,
                      "pending_token": reference[committed-1]["token"],
                      "boundary_state": checks, "continuation_rows": len(rows)-committed,
                      "all_logits": outputs, "final_state": final_checks,
                      "reference_full_target_replays": len(rows), "performance_evidence": False}
            records.append(record)
            write_json(output / "boundary-comparison.json", records)
            if not outputs["exact"] or not all(x["exact"] for x in (*checks.values(), *final_checks.values())):
                raise CorrectnessFailure("slow commit boundary or subsequent ordinary continuation differs")
    print("future-row isolation and both depth-one slow commit boundaries passed", flush=True)


def capture_probe(scheduler, output):
    import torch
    from freetoken.models.qwen4_exp.verify import VerifyRows, prepare_verify, forward_verify
    seed = scheduler.seed
    rows = scheduler.rows[:WIDTH]
    intent = VerifyRows(tuple(rows))
    model = scheduler.engine.model
    stream = scheduler.engine.stream
    ref_logits = torch.cat([x["logits"] for x in scheduler.reference[:WIDTH]])
    ref_wide = torch.cat([x["wide"] for x in scheduler.reference[:WIDTH]])
    ref_state = scheduler.reference[WIDTH-1]["state"]
    with torch.cuda.stream(stream):
        seed.restore(scheduler)
        seed.restore_expert_conditions(scheduler)
        stream.synchronize()
        prepared = prepare_verify(model, intent)
        started = time.monotonic_ns()
        forward_verify(model, intent, prepared)
        stream.synchronize()
        unprofiled_wall = (time.monotonic_ns() - started) / 1e6
        seed.restore(scheduler)
        seed.restore_expert_conditions(scheduler)
        stream.synchronize()
        started = time.monotonic_ns()
        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                               torch.profiler.ProfilerActivity.CUDA]) as profile:
            forward_verify(model, intent, prepared)
            stream.synchronize()
        profiled_wall = (time.monotonic_ns() - started) / 1e6
        profile.export_chrome_trace(str(output / "verify-eager-profile.json"))
        events = json.loads((output / "verify-eager-profile.json").read_text())["traceEvents"]
        kernels = [x for x in events if x.get("cat") == "kernel" and x.get("ph") == "X"]
        kernel_ms = sum(x.get("dur", 0) for x in kernels)/1000
        write_json(output / "capture-hypothesis.json", {
            "unprofiled_eager_wall_ms": unprofiled_wall,
            "profiled_wall_ms": profiled_wall, "GPU_kernel_duration_sum_ms": kernel_ms,
            "GPU_kernel_count": len(kernels), "profile_includes_instrumentation_overhead": True,
            "hypothesis": "A fixed-oracle CUDA capture can remove host launch gaps; PLE preparation remains timed separately",
            "scope": "one narrow capture experiment; fixed rows/positions, not a general serving graph"})
        if not kernels:
            raise RuntimeError("CUDA profile contains no kernel evidence; capture hypothesis is not verified")
        seed.restore(scheduler)
        seed.restore_expert_conditions(scheduler)
        stream.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph, stream=stream):
            captured_wide, captured_logits, counters = forward_verify(model, intent, prepared)
        samples = []
        for mode in ("ordinary_graph_rows", "verify_graph", "verify_graph", "ordinary_graph_rows", "ordinary_graph_rows", "verify_graph"):
            seed.restore(scheduler)
            seed.restore_expert_conditions(scheduler)
            stream.synchronize()
            prepare_ms = 0.0
            if mode == "verify_graph":
                started = time.monotonic_ns()
                fresh = prepare_verify(model, intent)
                for dst, src in zip(prepared.embeddings, fresh.embeddings):
                    dst.copy_(src)
                stream.synchronize()
                prepare_ms = (time.monotonic_ns()-started)/1e6
            begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            started = time.monotonic_ns()
            begin.record()
            if mode == "ordinary_graph_rows":
                logits = ordinary_rows(scheduler, rows)
            else:
                graph.replay()
                logits = captured_logits
            end.record()
            end.synchronize()
            wall = (time.monotonic_ns()-started)/1e6
            state = Snapshot(scheduler, seed.req, seed.layout)
            checks = state_check(ref_state, state)
            output_check = comparison(ref_logits, logits.cpu())
            wide_check = comparison(ref_wide, captured_wide.cpu()) if mode == "verify_graph" else None
            record = {"mode": mode, "width": WIDTH, "wall_ms": wall,
                      "prepare_ms": prepare_ms, "wall_plus_prepare_ms": wall+prepare_ms,
                      "CUDA_ms": begin.elapsed_time(end), "logits": output_check,
                      "wide": wide_check, "state": checks,
                      "matched_initial_expert_cache": True, "semantic_restore_in_timing": False,
                      "expert_restore_in_timing": False, "fixed_oracle_candidates": True,
                      "includes_sampler_commit_or_draft": False}
            samples.append(record)
            write_json(output / "verify-capture.json", samples)
            if not output_check["exact"] or (wide_check and not wide_check["exact"]) or not all(x["exact"] for x in checks.values()):
                raise CorrectnessFailure("captured target verification changes oracle outputs or state")
        print("matched-cache ordinary and captured verify timings: " +
              json.dumps([{k:x[k] for k in ("mode", "wall_plus_prepare_ms", "CUDA_ms")} for x in samples]), flush=True)
