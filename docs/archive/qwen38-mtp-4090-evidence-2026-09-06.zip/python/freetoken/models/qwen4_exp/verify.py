"""Explicit experimental verification entry; ordinary forwards never import it."""
from dataclasses import dataclass

import torch

from freetoken.core import Batch, get_global_ctx
from freetoken.moe.fused import fused_topk
from freetoken.kernel.triton.moe_shared_gate import shared_gate_mul_add, shared_gate_sigmoid

from .ple import build_ple_metadata, commit_ngram_context, PLE_NGRAM_STATE


@dataclass(frozen=True)
class VerifyRows:
    """One pending anchor and known candidate rows of the same request.

    Each Batch describes one ordinary decode row at its own causal frontier.
    This adapter uses their metadata inside one traversal, never full-model
    forwards per row. Request/page allocation and commit remain with the caller.
    """
    rows: tuple[Batch, ...]

    def validate(self):
        assert len(self.rows) in (2, 3, 5)
        first = self.rows[0].reqs[0]
        for index, batch in enumerate(self.rows):
            assert batch.is_decode and batch.size == batch.padded_size == 1
            req = batch.reqs[0]
            assert req.uid == first.uid and req.table_idx == first.table_idx
            assert req.linear_slot_idx == first.linear_slot_idx
            assert req.cached_len == first.cached_len + index and req.extend_len == 1
            assert batch.input_ids.shape == (1,)


@dataclass(frozen=True)
class PreparedPLE:
    intent: VerifyRows
    metadata: tuple
    embeddings: tuple[torch.Tensor, ...]


def prepare_verify(model, intent: VerifyRows) -> PreparedPLE:
    """Stage bounded disk PLE input before a fixed-oracle GPU traversal."""
    intent.validate()
    rows = intent.rows
    ctx = get_global_ctx()
    body = model.model
    assert len(body.ple_layers) == 1
    ple = body.ple_layers[0]
    disk = ple.ple_embedding.table
    assert hasattr(disk, "host_fill_batch")

    # Stage each real disk lookup without changing the authoritative n-gram
    # history. Completion protects the reused process-local eager pinned buffer.
    context = ctx.linear_state_pool.slot_state(PLE_NGRAM_STATE).clone()
    metadata, embeddings = [], []
    for batch in rows:
        with ctx.forward_batch(batch):
            meta = build_ple_metadata(batch, ple.args, batch.input_ids.device, context_pool=context)
            disk.host_fill_batch(batch, use_graph=False)
            value = disk.lookup(ple.ple_embedding.row_ids(meta)).clone()
            done = torch.cuda.Event()
            done.record()
            done.synchronize()
            metadata.append(meta)
            embeddings.append(value)
            commit_ngram_context(meta, batch.fla_metadata, context_pool=context)
    return PreparedPLE(intent, tuple(metadata), tuple(embeddings))


def forward_verify(model, intent: VerifyRows, prepared: PreparedPLE | None = None):
    """Return wide features and logits for every row; mutate model state only.

    This first probe keeps dense/recurrent arithmetic per row and batches only
    the native routed-expert path. It has no fast transaction or server hook.
    Prepared PLE is bound to one fixed oracle intent, not a serving-round cache.
    """
    intent.validate()
    rows = intent.rows
    ctx = get_global_ctx()
    cache = ctx.moe_offload_cache
    assert cache is not None and cache.quant_format == "nvfp4"
    assert cache.decode_target == "gpu" and not cache.cpu_layer_ids
    body = model.model
    ple = body.ple_layers[0]
    disk = ple.ple_embedding.table
    if prepared is None:
        prepared = prepare_verify(model, intent)
    assert prepared.intent is intent
    metadata, embeddings = prepared.metadata, prepared.embeddings

    class StagedTable:
        value = None
        def lookup(self, row_ids, out=None):
            assert self.value.shape[0] == row_ids.shape[0]
            if out is not None:
                out.copy_(self.value)
                return out
            return self.value

    staged = StagedTable()
    hidden = [body.embed_tokens.forward(batch.input_ids).repeat(1, body.hc_count) for batch in rows]
    counters = {"stack_traversals": 1, "decoder_layers": 0, "routed_expert_blocks": 0,
                "whole_target_replays": 0, "row_count": len(rows), "scheduler_commits": 0}
    try:
        ple.ple_embedding.attach_table(staged)
        for layer in body.layers.op_list:
            mixed, injections, shared, gates, weights, ids = [], [], [], [], [], []
            for index, batch in enumerate(rows):
                with ctx.forward_batch(batch):
                    value = hidden[index]
                    if layer.ple is not None:
                        staged.value = embeddings[index]
                        value = value + layer.ple.forward(value, batch, meta=metadata[index])
                        commit_ngram_context(metadata[index], batch.fla_metadata)
                    x, inject = layer.attn_hyper_connection.mix(value)
                    y = layer.linear_attn.forward(x) if layer._is_linear else layer.self_attn.forward(x, batch)
                    value = layer.attn_hyper_connection.combine(value, y, inject)
                    x, inject = layer.mlp_hyper_connection.mix(value)
                    hidden[index] = value
                    mixed.append(x)
                    injections.append(inject)
                    moe = layer.mlp
                    router = moe.gate.forward(x)
                    shared.append(moe.shared_expert.forward(x))
                    gates.append(shared_gate_sigmoid(x, moe.shared_expert_gate.weight.view(-1)))
                    weight, raw_id = fused_topk(hidden_states=x, gating_output=router,
                        topk=moe.experts.top_k, renormalize=moe.experts.renormalize)
                    weights.append(weight)
                    ids.append(raw_id)
            with ctx.forward_batch(rows[0]):
                routed = layer.mlp.experts.routed_forward(torch.cat(mixed), torch.cat(weights), torch.cat(ids))
            for index in range(len(rows)):
                y = shared_gate_mul_add(routed[index:index+1], shared[index], gates[index])
                hidden[index] = layer.mlp_hyper_connection.combine(hidden[index], y, injections[index])
            counters["decoder_layers"] += 1
            counters["routed_expert_blocks"] += 1
        logits = []
        for value, batch in zip(hidden, rows):
            with ctx.forward_batch(batch):
                logits.append(model.lm_head.forward(body.hyper_connection_mixer.mix(value)[0]))
        # Ordinary graph dispatch widens the BF16 head output into its FP32 buffer.
        return torch.cat(hidden), torch.cat(logits).float(), counters
    finally:
        ple.ple_embedding.attach_table(disk)
